﻿using adzu.connectorhub.contracts.Model;
using adzu.connectorhub.sdk;
using Adzu.GoogleConnector.DTO;
using Adzu.GoogleConnector.IntegrationTests.Models;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace Adzu.GoogleConnector.IntegrationTests.Specs
{
    [Binding]
    public sealed class GetAccountsSpec
    {
        private readonly ScenarioContext _scenarioContext;
        private List<AccountsResultDTO> _resultRequests = new List<AccountsResultDTO>();

        public GetAccountsSpec(ScenarioContext scenarioContext)
            => _scenarioContext = scenarioContext;

        private Dictionary<string, string> _customers = new Dictionary<string, string> {
            {"RootCustomer1", "8963272431"},
            {"RootChild1", "3941125176"},
            {"RootChild2", "1678744741"},
            {"RootChild3", "9064694994"}};
        [StepArgumentTransformation]
        public List<GetAccountsModel> TransformUserFieldsToCheck(Table table)
        {
            return table.Rows.Select(row =>
            {
                return new GetAccountsModel
                {
                    CustomerId = row["CustomerId"],
                    LoginCustomerId = row["LoginCustomerId"],
                    ExpectedResult = row["Expected Result"].Split(',')
                };
            }).ToList();
        }

        [When(@"Integration test requests Google Connector to Get Accounts through CHB")]
        public async Task GetAccountsThroughCHB(List<GetAccountsModel> model)
        {
            IConnectorHubClient client = (IConnectorHubClient)_scenarioContext[ConnectorModel.ConnectorHubClient];
            var connector = (ConnectorResponse)_scenarioContext[ConnectorModel.Connector];
            foreach (var data in model)
            {

                var input = _customers.TryGetValue(data.CustomerId, out string customerId)
                    && _customers.TryGetValue(data.LoginCustomerId, out string loginCustomerId)
                    ? new JObject
                    {
                        ["CustomerId"] = customerId,
                        ["LoginCustomerId"] = loginCustomerId,
                        ["ConnectionReference"] = _scenarioContext[ConnectorModel.ConnectionReference].ToString()
                    }
                    : new JObject
                    {
                        ["ConnectionReference"] = _scenarioContext[ConnectorModel.ConnectionReference].ToString()
                    };

                var requestResponse = await client.Requests.ProcessRequest(new Request
                {
                    Input = input,
                    ActionId = connector.Actions.First(a => a.Id == ConnectorActionIds.GetAccounts).Id,
                    ConnectorId = connector.ConnectorId,
                    Version = connector.Version,
                    CallbackUrl = _scenarioContext[ConnectorModel.TenantCallbackUrl].ToString()
                });

                Console.WriteLine($"Google connector response{ requestResponse.Output }");
                _resultRequests.Add(new AccountsResultDTO
                {
                    Response = requestResponse.Output,
                    ExpectedResult = data.ExpectedResult
                });
            }
        }
        [Then(@"Returned accounts is as expected result")]
        public void ThenReturnedAccountsIsAsExpectedResult()
        {
            _resultRequests.ForEach(r =>
            {
                var accounts = r.Response["accounts"].ToObject<List<CustomerAccountDTO>>().Select(a=>a.CustomerId);
                r.ExpectedResult.ToList().ForEach(a =>
                {
                    Assert.IsTrue(_customers.TryGetValue(a, out string customerId));
                    Assert.IsTrue(accounts.Contains(customerId));
                });
            });
        }
    }
}
