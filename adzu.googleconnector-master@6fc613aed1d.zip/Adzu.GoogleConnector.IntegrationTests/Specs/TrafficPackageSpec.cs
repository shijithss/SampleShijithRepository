﻿using adzu.connectorhub.contracts.Model;
using adzu.connectorhub.sdk;
using Adzu.GoogleConnector.DTO;
using Adzu.GoogleConnector.Helpers;
using Adzu.GoogleConnector.IntegrationTests.Models;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using System;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace Adzu.GoogleConnector.IntegrationTests.Specs
{
    [Binding]
    public sealed class TrafficPackageSpec
    {
        private readonly ScenarioContext _scenarioContext;
        private IOptionsMonitor<TestOptions> _testSettings;
        private HttpClient _httpClient = new HttpClient();
        private readonly string _requestId = Guid.NewGuid().ToString();
        private IGoogleConnectorClient _googleConnectorClient;
        private string createdCampaignId;
        public TrafficPackageSpec(ScenarioContext scenarioContext,
            IOptionsMonitor<TestOptions> testSettings,
            IGoogleConnectorClient googleConnectorClient) 
            => (_scenarioContext, _testSettings, _googleConnectorClient) = (scenarioContext, testSettings, googleConnectorClient);

        [When(@"Integration test requests Google Connector to Traffic Package through CHB")]
        public async Task RequestPackageToCHB()
        {
            IConnectorHubClient client = (IConnectorHubClient)_scenarioContext[ConnectorModel.ConnectorHubClient];

            var connector = (ConnectorResponse)_scenarioContext[ConnectorModel.Connector];

            var requestResponse = await client.Requests.ProcessRequest(new Request
            {
                Input = new JObject
                {
                    ["PackageUrl"] = _scenarioContext[ConnectorModel.S3PackageUrl].ToString(),
                    ["ConnectionReference"] = _scenarioContext[ConnectorModel.ConnectionReference].ToString()
                },
                ActionId = connector.Actions.First(a=>a.Id == ConnectorActionIds.TrafficPackage).Id,
                ConnectorId = connector.ConnectorId,
                Version = connector.Version,
                CallbackUrl = _scenarioContext[ConnectorModel.TenantCallbackUrl].ToString()
            });

            _scenarioContext[ConnectorModel.OutputKey] = requestResponse.Output;
            _scenarioContext[ConnectorModel.RequestId] = requestResponse.RequestId;

            Console.WriteLine($"RequestID: {requestResponse.RequestId}");
        }
        [Then("For TrafficPackage within (.*) seconds internal package status becomes '(.*)' or transited to next state")]
        [Then("For TrafficPackage within (.*) seconds internal package status becomes '(.*)'")]
        public async Task ReadInternalPackageStatus(int waitSeconds, PackageStatusEnum status)
        {
            var statuses = (PackageStatusEnum[])Enum.GetValues(typeof(PackageStatusEnum));
            var indexStatus = Array.IndexOf(statuses, status);
            Assert.IsTrue(indexStatus >= 0, $"Unknown status: {status}");

            var endpointUrl = $"api/InernalData/GetTrafficInternalStatus?folderName={_requestId.ToSHA256String()}";
            var url = $"{_testSettings.CurrentValue.BaseUrlGoogleConnector}/{endpointUrl}";
            TrafficPackageStatusDTO responseStatus = null;
            var indexWaitingStatus = -1;
            var timer = new Stopwatch();
            timer.Start();

            do
            {
                var response = await _httpClient.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    responseStatus = JsonConvert.DeserializeObject<TrafficPackageStatusDTO>(content);
                    indexWaitingStatus = Array.IndexOf(statuses, responseStatus.InternalStatus);
                    if (indexStatus <= indexWaitingStatus) 
                        break;
                }
                if (timer.Elapsed.TotalSeconds > waitSeconds) 
                    break;
                await Task.Delay(1000);
            } while (true);

            timer.Stop();
            var result = indexStatus <= indexWaitingStatus;
            Assert.IsTrue(result,$"Waited: {status.GetDescription()} but got: {responseStatus.InternalStatus.GetDescription()}");
        }
        [Then(@"Within (.*) seconds CHB gets notification with type TrafficPackageCompleted and status '(.*)' for the Traffic Package")]
        public async Task ReadPackageStatus(int waitSeconds, string status)
        {
            IConnectorHubClient client = (IConnectorHubClient)_scenarioContext[ConnectorModel.ConnectorHubClient];
            NotificationResponse[] notifications = null;
            var timer = new Stopwatch();
            timer.Start();

            do
            {
                await Task.Delay(2000);

                var actionResult = await client.Notifications.ListAll();
                notifications = actionResult.Items
                    .Where(i => i.RequestId == _scenarioContext[ConnectorModel.RequestId].ToString()
                        && i.TenantAccountId == _scenarioContext[ConnectorModel.TenantAccountId].ToString()).ToArray();

                if (notifications.Any())
                {
                    break;
                }

                if (timer.Elapsed.TotalSeconds > waitSeconds)
                    break;

            } while (true);

            timer.Stop();
            var result = notifications.Any();
            Assert.IsTrue(result);
            _scenarioContext[ConnectorModel.NotificationErrors] = notifications[0].Notification["errors"];

            var statusResult = (string)notifications[0].Notification.SelectToken("status");
            var reasonResult = (string)notifications[0].Notification.SelectToken("reason");
            createdCampaignId = (string)notifications[0].Notification.SelectToken("externalId");

            if (statusResult == "Success")
            {
                Console.WriteLine($"Google campaign ID: {createdCampaignId}");
                Assert.IsNotNull(createdCampaignId);
            }
            Assert.AreEqual(status, statusResult, reasonResult);
        }
        [When(@"Integration test on behalf of CHB requests Google Connector to Traffic Package")]
        public async Task RequestPackageToConnectorDirectly()
        {
            var response = await _googleConnectorClient.TrafficPackage(
                _requestId, 
                _scenarioContext[ConnectorModel.S3PackageUrl].ToString(), 
                _scenarioContext[ConnectorModel.ConnectionReference].ToString());

            Assert.IsNotNull(response, $"Request TrafficPackage was not successfull");
            Assert.IsTrue(response.IsSuccessStatusCode, $"Request TrafficPackage was not successfull");
        }
        [Then(@"Google Ads contains a new campaign corresponding to the Traffic Package")]
        public void ThenGoogleAdsContainsANewCampaignCorrespondingToTheTrafficPackage()
        {
            // TODO
        }

        [Then(@"Notification error has '(.*)' error code")]
        public async Task ThenNotificationErrorHasErrorCode(string expectedErorrCode)
        {
            var errorResponse = _scenarioContext[ConnectorModel.NotificationErrors];
            var actualErrorCode = ((JToken)errorResponse)[0].SelectToken("code").ToString();           
            Assert.AreEqual(expectedErorrCode, actualErrorCode);         
        }

        [Then(@"Notification error has non empty error message")]
        public async Task ThenNotificationErrorHasNonEmptyErrorMessage()
        {
            var errorResponse = _scenarioContext[ConnectorModel.NotificationErrors];            
            var actualErrorMesage = ((JToken)errorResponse)[0].SelectToken("message").ToString();
            Assert.IsNotNull(actualErrorMesage);
        }

        [Then(@"Notification error has TrafficPackage Url in parameter")]
        public void ThenNotificationErrorHasTrafficPackageUrlInParameter()
        {
            var errorResponse = _scenarioContext[ConnectorModel.NotificationErrors];
            var actualErrorParameters = ((JToken)errorResponse)[0].SelectToken("params")[0].ToString();
            Assert.AreEqual(_scenarioContext[ConnectorModel.S3PackageUrl], actualErrorParameters);
        }

    }



}

