﻿using Adzu.Sdk.IdentityServer;
using Adzu.Sdk.IoC;
using Adzu.Sdk.Security;
using Microsoft.Extensions.Options;
using NUnit.Framework;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace Adzu.GoogleConnector.IntegrationTests.Specs
{
    [Binding]
    public class AuthSpec
    {
        private readonly ScenarioContext _scenarioContext;
        private readonly IIdentityServerClient _identityServerClient;
        private readonly ClientConfigOptions _options;

        public AuthSpec(
           ScenarioContext scenarioContext,
           IIdentityServerClient identityServerClient,
           IOptionsMonitor<ClientConfigOptions> options)
        {
            _scenarioContext = scenarioContext;
            _identityServerClient = identityServerClient;
            _options = options.CurrentValue;
        }

        [Given(@"This integration test has access token for CHB & CNM API requests")]
        public async Task GivenIAmAbleToUseAccess()
        {
            var token = await _identityServerClient.GetAccessTokenByCredentials(
                new ClientCredentials(_options.ClientId, _options.ClientSecret, _options.ClientScope));

            Assert.IsNotNull(token);
            _scenarioContext["AccessToken"] = token;
        }
    }
}
