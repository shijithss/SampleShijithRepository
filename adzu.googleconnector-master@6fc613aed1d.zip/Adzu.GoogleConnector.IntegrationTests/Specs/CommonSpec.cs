﻿using adzu.connectorhub.contracts.Model;
using adzu.connectorhub.sdk;
using Adzu.ConnectionManager.Contracts.Models;
using Adzu.ConnectionManager.Contracts.Requests;
using Adzu.ConnectionManager.SDK;
using Adzu.GoogleConnector.DTO;
using Adzu.GoogleConnector.IntegrationTests.Models;
using Adzu.Sdk.IoC;
using Amazon;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Model;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace Adzu.GoogleConnector.IntegrationTests.Specs
{
    [Binding]
    public sealed class CommonSpec
    {
        private readonly ScenarioContext _scenarioContext;
        private readonly IConnectionManagerClient _connectionManagerClient;
        private readonly ClientConfigOptions _clientConfigOptions;
        private readonly TestOptions _testOptions;
        private readonly AuthenticationOptions _authenticationOptions;
        private readonly AwsS3Options _s3Options;
        private ConnectionModel _connectionModel;

        public CommonSpec(ScenarioContext scenarioContext,
            ISdkClientFactory<IConnectorHubClient> connectorHubClient,
            IOptionsMonitor<TestOptions> testOptions,
            IOptionsMonitor<AwsS3Options> s3Options,
            IOptionsMonitor<ClientConfigOptions> clientConfigOptions,
            IOptionsMonitor<AuthenticationOptions> authenticationOptions,
            ISdkClientFactory<IConnectionManagerClient> connectionManagerClient)
        {
            _scenarioContext = scenarioContext;
            _clientConfigOptions = clientConfigOptions.CurrentValue;
            _authenticationOptions = authenticationOptions.CurrentValue;
            _testOptions = testOptions.CurrentValue;
            _s3Options = s3Options.CurrentValue;

            if (_scenarioContext.ContainsKey("AccessToken"))
            {
                _scenarioContext[ConnectorModel.ConnectorHubClient] =
                    connectorHubClient.WithAccessToken(_scenarioContext["AccessToken"].ToString())
                        .CreateClient(new Adzu.Sdk.SdkClientConfigurationOptions
                        {
                            BaseUrl = new Uri(_testOptions.BaseUrlCHB),
                        });

                _connectionManagerClient = connectionManagerClient
                    .WithAccessToken(_scenarioContext["AccessToken"].ToString())
                    .CreateClient(new Adzu.Sdk.SdkClientConfigurationOptions
                    {
                        BaseUrl = new Uri(_testOptions.BaseUrlCNM),
                    });
            }
        }
        [Given("Ensure connector '(.*)' with action '(.*)' exist in CHB")]
        public async Task EnsureConnectorInCHB(string connectorName, string action)
        {
            IConnectorHubClient client = (IConnectorHubClient)_scenarioContext[ConnectorModel.ConnectorHubClient];
            var registeredConnectors = await client.Connectors.Find();
            var version = _testOptions.ConnectorHubVersion;
            var connector = registeredConnectors.Items
                .SingleOrDefault(i => i.Name == _testOptions.ConnectorName
                    && i.Actions.Any(a=>a.Name == action)
                    && i.Version == version);

            if (connector == null)
            {
                var credentials = $"{_authenticationOptions.ConnectorBasicAuthName}:{_authenticationOptions.ConnectorBasicAuthPassword}";
                var connectorRequestModel = new ConnectorRequest
                {
                    Actions = new[] { 
                        new ActionRequest
                        {
                            Id = ConnectorActionIds.TrafficPackage,
                            Authentication = ConnectorHubConstants.AuthenticationType.Basic,
                            Name = ConnectorActionIds.TrafficPackage,
                            Type = "async",
                            Url = $"{_testOptions.BaseUrlGoogleConnector}/api/traffic-package",
                            Credentials = credentials
                        },
                        new ActionRequest
                        {
                            Id = ConnectorActionIds.GetAccounts,
                            Authentication = ConnectorHubConstants.AuthenticationType.Basic,
                            Name = ConnectorActionIds.GetAccounts,
                            Type = "sync",
                            Url = $"{_testOptions.BaseUrlGoogleConnector}/api/get-accounts",
                            Credentials = credentials
                        },
                    },
                    ConnectorId = _testOptions.ConnectorName,
                    Authentication = ConnectorHubConstants.AuthenticationType.Basic,
                    Name = _testOptions.ConnectorName,
                    Version = version,
                    Credentials = credentials,
                };

                var connectorId = registeredConnectors.Items
                        .SingleOrDefault(i => i.Name == _testOptions.ConnectorName)?.Id;
                if (connectorId != null)
                {
                    await client.Connectors.Delete((Guid)connectorId);
                }
                connectorId = await client.Connectors.Create(connectorRequestModel);
                connector = await client.Connectors.FindOne((Guid)connectorId);
            }
            Assert.IsNotNull(connector);
            _scenarioContext[ConnectorModel.Connector] = connector;            
        }
        [Given(@"Ensure service provider '(.*)' exists in CNM")]
        public async Task FindServiceProvider(string providerId)
        {
            var parameters = new OAuth2Parameters
            {
                AuthenticationUrl = "https://accounts.google.com/o/oauth2/v2/auth?access_type=offline&prompt=consent",
                AccessTokenUrl = "https://oauth2.googleapis.com/token",
                ClientId = _authenticationOptions.GoogleOAuth2ClientId,                
                ClientSecret = _authenticationOptions.GoogleOAuth2ClientSecret,
                Scopes = new[] { "openid" }
            };
            try
            {
                var provider = await _connectionManagerClient.ServiceProvider.Get(providerId);

                if (provider.GetParameters<OAuth2Parameters>().ClientId != parameters.ClientId)
                {
                    provider = await _connectionManagerClient.ServiceProvider.Update(providerId,
                        new UpdateServiceProviderRequest
                        {
                            Name = providerId,
                            Parameters = parameters
                        });
                }
            }
            catch
            {
                var provider = await _connectionManagerClient.ServiceProvider.Create(
                    new CreateServiceProviderRequest
                    {
                        Id = providerId,
                        Name = providerId,
                        AuthenticationType = AuthenticationType.OAuth2,
                        Parameters = parameters
                    });
            }
        }
        [Given("Ensure tenant account '(.*)' exists in CNM")]
        public async Task FindClientCNM(string tenantName)
        {
            var result = await _connectionManagerClient.TenantAccount.List();
            var googleTestTenantCNM = result.Items
                    .FirstOrDefault(i => i.Name != null && i.Name.Contains(tenantName));

            if (googleTestTenantCNM == null)
            {
                googleTestTenantCNM = await _connectionManagerClient.TenantAccount.Create(
                    new CreateTenantAccountRequest
                    {
                        Name = tenantName,
                        AppClientIds = new[]
                        {
                            _clientConfigOptions.ClientId
                        }
                    });
            }

            Assert.IsTrue(googleTestTenantCNM.AppClientIds.Any(c => c == _clientConfigOptions.ClientId));
            Assert.AreEqual(tenantName, googleTestTenantCNM.Name);
        }
        [Given(@"Ensure connection '(.*)' exists in CNM")]
        public async Task FindConnectionCNM(string connectionName)
        {
            var parametersJson = 
@"{
    ""ClientId"": ""is required field"",
    ""ClientSecret"": ""is required field"",
    ""GrantType"": ""client_credentials"",
    ""TokenEndpoint"": ""https://is.required.field"",
    ""ApiBaseUrl"": ""https://is.required.field"",
    ""refresh_token"": ""1//0cTYc_gLiHvp0CgYIARAAGAwSNwF-L9IrN6iJ71MomthVKBmNsFS7g1wYlxNGQLZENjaqxF3xsUZtm6hTm7RqpjFRkzKc3xPv6bc"",
    ""serviceProviderId"": ""GoogleServiceProviderIntTest""
}";

            var result = await _connectionManagerClient
                .ConnectionV3.FindAll(new ListConnectionsRequest { Take = 1 });

            _connectionModel = result.Items.FirstOrDefault();

            if (null == _connectionModel)
            {
                _connectionModel = await _connectionManagerClient.ConnectionV3.Create(new CreateConnectionRequestV3
                {
                    ClientId = _testOptions.DedicatedIdForGoogleIntegrationTestOnly,
                    Name = connectionName,
                    Type = "OAuth2.0",
                    Parameters = parametersJson
                });
            }
            if (_connectionModel.Parameters != parametersJson)
            {
                _connectionModel = await _connectionManagerClient.ConnectionV3.Update(
                    _connectionModel.ConnectionId,
                    new UpdateConnectionRequestV3
                    {
                        ClientId = _clientConfigOptions.ClientId,
                        Name = connectionName,
                        Parameters = parametersJson
                    });
            }

            Assert.IsNotNull(_connectionModel);
        }
        [Given(@"Connection refs for connection '(.*)' is created and expires in (.*) seconds")]
        public async Task GivenICreateConnectionRefsWithExpiresIn(string connection, int expiresIn)
        {
            var response =
                await _connectionManagerClient.ConnectionV3.Refs(
                _connectionModel.ConnectionId,
                new ConnectionRefsRequest
                {
                    ClientId = RetrieveClientId(_connectionModel.ClientId),
                    ExpiresIn = expiresIn
                });

            _scenarioContext[ConnectorModel.ConnectionReference] = response.Token;
        }
        [Given("Traffic Package is uploaded to S3 AWS")]
        public async Task UploadPackageToS3()
        {
            var (fileName, filepath) = CreatePackageZipFile();

            await PutFileToS3(fileName, filepath, S3CannedACL.PublicRead);
        }

        [Given(@"Invalid Traffic Package is uploaded to S3 AWS")]
        public async Task GivenInvalidTrafficPackageIsUploadedToS3AWS()
        {
            var (fileName, filepath) = CreateCorruptedPackageZipFile();

            await PutFileToS3(fileName, filepath, S3CannedACL.PublicRead);
        }

        [Given(@"Traffic Package with  private access is uploaded to S3 AWS")]
        public async Task GivenTrafficPackageWithPrivateAccessIsUploadedToSAWS()
        {
            var (fileName, filepath) = CreatePackageZipFile();

            await PutFileToS3(fileName, filepath, S3CannedACL.Private);
        }


        [Given(@"Semantically wrong '(.*)' PackageUrl is provided")]
        public async Task GivenSemanticallyWrongPackageUrlIsProvided(string url)
        {
            _scenarioContext[ConnectorModel.S3PackageUrl] = url;
        }


        private (string, string) CreateCorruptedPackageZipFile()
        {
            string fileName = "CorruptedTrafficPackage.zip";
            string zipFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Data", fileName);
            return ($"{Guid.NewGuid()}{fileName}", zipFilePath);
        }

        private async Task PutFileToS3(string fileName, string filepath, S3CannedACL access)
        {
            IAmazonS3 s3Client = new AmazonS3Client(
                                  new BasicAWSCredentials(_s3Options.AccessKey, _s3Options.SecretKey),
                                  RegionEndpoint.GetBySystemName(_s3Options.Region));

            using (var fileStream = System.IO.File.OpenRead(filepath))
            {
                var s3Response = await s3Client.PutObjectAsync(
                new PutObjectRequest
                {
                    BucketName = _s3Options.Bucket,
                    Key = fileName,
                    CannedACL = S3CannedACL.NoACL,
                    InputStream = fileStream,
                    Headers =
                    {
                        ExpiresUtc = DateTime.UtcNow.AddHours(1),
                        ContentType = "application/zip",
                        ContentDisposition = "inline; filename=" + Uri.EscapeDataString(fileName)
                    }
                });
                await s3Client.PutACLAsync(new PutACLRequest
                {
                    BucketName = _s3Options.Bucket,
                    Key = fileName,
                    CannedACL = access
                });
            }
            var packageUrl = $"https://s3.{_s3Options.Region}.amazonaws.com/{_s3Options.Bucket}/{fileName}";
            _scenarioContext[ConnectorModel.S3PackageUrl] = packageUrl;
        }

        [Given("Ensure tenant account '(.*)' exists in CHB")]
        public async Task EnsureTenantAccountInCHB(string accountName)
        {
            IConnectorHubClient client = (IConnectorHubClient)_scenarioContext[ConnectorModel.ConnectorHubClient];
            var tenantResponse = await client.TenantAccounts.ListAll();
            var tenantAccount = tenantResponse.Items
                .FirstOrDefault(a => a.ClientIds != null && a.ClientIds.Contains(_clientConfigOptions.ClientId));

            Guid tenantAccountId = Guid.Empty;
            if (tenantAccount != null)
            {
                Guid.TryParse(tenantAccount.Id, out tenantAccountId);
                if (!tenantAccount.DomainNames.Contains(new Uri(_testOptions.BaseDEVUrlGoogleConnector).DnsSafeHost)
                 || !tenantAccount.DomainNames.Contains(new Uri(_testOptions.BaseQAUrlGoogleConnector).DnsSafeHost))
                { 
                    await client.TenantAccounts.Delete(tenantAccountId);
                    tenantAccount = null;
                }
            }
            if (tenantAccount == null)
            {
                var credentials = $"{_authenticationOptions.ConnectorBasicAuthName}:{_authenticationOptions.ConnectorBasicAuthPassword}";
                tenantAccountId = await client.TenantAccounts.Create(new TenantAccountRequest
                {
                    ClientIds = new[] { _clientConfigOptions.ClientId },
                    Name = accountName,
                    Authentication = "Basic",
                    Credentials = credentials,
                    DomainNames = new[] { new Uri(_testOptions.BaseDEVUrlGoogleConnector).DnsSafeHost,
                                          new Uri(_testOptions.BaseQAUrlGoogleConnector).DnsSafeHost}
                });
            }
            _scenarioContext[ConnectorModel.TenantCallbackUrl] = $"{_testOptions.BaseUrlGoogleConnector}/api/InernalData/mockTenantCallback";
            _scenarioContext[ConnectorModel.TenantAccountId] = tenantAccountId.ToString();

            Console.WriteLine($"tenantAccountId: {tenantAccountId}");
        }
        private string RetrieveClientId(string composedClientId)
        {
            var clientId = composedClientId;
            if (clientId.Contains("#"))
                return clientId[(clientId.LastIndexOf('#') + 1)..];

            return clientId;
        }
        private (string, string) CreatePackageZipFile()
        {
            var randomString = Guid.NewGuid().ToString();
            var manifest = GetManifest(randomString);
            Console.WriteLine($"Campaign code: {manifest.Code}");
            Console.WriteLine($"Campaign ProductionCost:{manifest.ProductionCost.Value}{manifest.ProductionCost.Code}; Campaign PlannedMediaCost:{manifest.PlannedMediaCost.Value}{manifest.PlannedMediaCost.Code}");
            Console.WriteLine($"Campaign StartDate:{manifest.StartDate}; EndDate:{manifest.EndDate}");
            var manifestString = SerializeManifest(manifest);

            var fileName = $"TrafficPackage{randomString}.zip";
            var zipFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Data", fileName);

            using (var stream = System.IO.File.OpenWrite(zipFilePath))
            using (ZipArchive archive = new ZipArchive(stream, ZipArchiveMode.Create))
            {
                var manifestFile = archive.CreateEntry("manifest.json");
                using (var entryStream = manifestFile.Open())
                {
                    using (var streamWriter = new StreamWriter(entryStream))
                    {
                        streamWriter.Write(manifestString);
                    }
                }

                manifest.Assets.ForEach(a =>
                {
                    var assetFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Data/Assets", a.Package);
                    archive.CreateEntryFromFile(assetFilePath, $"{a.Package}", CompressionLevel.NoCompression);
                });
            }
            return (fileName, zipFilePath);
        }
        private string SerializeManifest(PackageManifestDTO manifest)
        {
            var serializer = new JsonSerializer()
            {
                ContractResolver = new DefaultContractResolver
                {
                    NamingStrategy = new CamelCaseNamingStrategy()
                }
            };
            using StringWriter writer = new StringWriter();
            serializer.Serialize(writer, manifest);
            return writer.ToString();
        }
        private PackageManifestDTO GetManifest(string randomString)
        {
            return new PackageManifestDTO
            {
                Code = $"Guiness{randomString}",
                Campaign = new Campaign
                {
                    Id = "campaignId",
                    Name = $"Campaigh{randomString}"
                },
                StartDate = DateTime.Now.AddDays(4).ToString("o"),
                EndDate = DateTime.Now.AddDays(5).ToString("o"),
                ProductionCost = new Cost
                {
                    Code = "GBR",
                    Value = 50.25
                },
                PlannedMediaCost = new Cost
                {
                    Code = "GBR",
                    Value = 50
                },
                MediaEndpointData = new MediaEndpointData
                {
                    CustomerId = "3941125176",
                    LoginCustomerId = "8963272431",
                    ClickThroughUrl = "http://google.com"
                },
                Assets = new List<Asset>
                {
                    new Asset
                    {
                        Id = $"CustomisationId0",
                        Package = $"BTQA33100C0045306-EmptyGoogleAds.zip"
                    }
                }
            };
        }
       
    }
}