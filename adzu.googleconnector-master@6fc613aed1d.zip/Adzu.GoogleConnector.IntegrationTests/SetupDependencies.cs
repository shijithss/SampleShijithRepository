﻿using adzu.connectorhub.sdk;
using Adzu.ConnectionManager.SDK;
using Adzu.GoogleConnector.IntegrationTests.Models;
using Adzu.Sdk.Core;
using Adzu.Sdk.IdentityServer;
using Adzu.Sdk.IoC;
using BoDi;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Polly;
using System;
using System.IO;
using System.Net.Http;
using TechTalk.SpecFlow;

namespace Adzu.GoogleConnector.IntegrationTests
{
    [Binding]
    public class SetupDependencies
    {
        private readonly IObjectContainer _objectContainer;
        private readonly IServiceProvider _serviceProvider;

        public SetupDependencies(IObjectContainer objectContainer)
        {
            _objectContainer = objectContainer;
            var serviceCollection = new ServiceCollection();

            var configBuilder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .AddJsonFile("appsettings.Development.json", optional: true)
                .AddEnvironmentVariables();

            var config = configBuilder.Build();


            serviceCollection.Configure<ClientConfigOptions>(config.GetSection("IdentityServer"));
            serviceCollection.Configure<TestOptions>(config.GetSection("TestOptions"));
            serviceCollection.Configure<AwsS3Options>(config.GetSection("AwsS3Options"));
            serviceCollection.Configure<AuthenticationOptions>(config.GetSection("Authentication"));

            serviceCollection.AddTransient<IGoogleConnectorClient, GoogleConnectorClient>();

            static HttpMessageHandler ConfigureHandler() =>
               new UnitTestMessageHandler(skipBody: true, logDetailed: false)
               {
                   InnerHandler = new HttpClientHandler
                   {
                       ClientCertificateOptions = ClientCertificateOption.Manual,
                       ServerCertificateCustomValidationCallback = (httpRequestMessage,
                           cert,
                           cetChain,
                           policyErrors) => true,
                       AllowAutoRedirect = false
                   }
               };

            static IAsyncPolicy<HttpResponseMessage> ConfigurePolicy(PolicyBuilder<HttpResponseMessage> p) 
                => p.WaitAndRetryAsync(3, _ => TimeSpan.FromMilliseconds(600));

            serviceCollection.AddSdkClient<IConnectorHubClient, ConnectorHubClient>()
                .ConfigurePrimaryHttpMessageHandler(ConfigureHandler)
                .AddTransientHttpErrorPolicy(ConfigurePolicy);

            serviceCollection.AddSdkClient<IConnectionManagerClient, ConnectionManagerClient>()
                .ConfigurePrimaryHttpMessageHandler(ConfigureHandler)
                .AddTransientHttpErrorPolicy(ConfigurePolicy);

            serviceCollection.AddHttpClient();
            _serviceProvider = serviceCollection.BuildServiceProvider();
        }

        [BeforeScenario]
        public void InitializeWebDriver()
        {
            _objectContainer.RegisterInstanceAs(_serviceProvider.GetService<IIdentityServerClient>());
            _objectContainer.RegisterInstanceAs(_serviceProvider.GetService<ISdkClientFactory<IConnectorHubClient>>());
            _objectContainer.RegisterInstanceAs(_serviceProvider.GetService<ISdkClientFactory<IConnectionManagerClient>>());
            _objectContainer.RegisterInstanceAs(_serviceProvider.GetService<IOptionsMonitor<TestOptions>>());
            _objectContainer.RegisterInstanceAs(_serviceProvider.GetService<IOptionsMonitor<ClientConfigOptions>>());
            _objectContainer.RegisterInstanceAs(_serviceProvider.GetService<IOptionsMonitor<AwsS3Options>>());
            _objectContainer.RegisterInstanceAs(_serviceProvider.GetService<IOptionsMonitor<AuthenticationOptions>>());
            _objectContainer.RegisterInstanceAs(_serviceProvider.GetService<IGoogleConnectorClient>());
        }
    }
}
