﻿namespace Adzu.GoogleConnector.IntegrationTests.Models
{
    public class AwsS3Options
    {
        public string AccessKey { get; set; }
        public string SecretKey { get; set; }
        public string Region { get; set; }
        public string Bucket { get; set; }
        
    }
}
