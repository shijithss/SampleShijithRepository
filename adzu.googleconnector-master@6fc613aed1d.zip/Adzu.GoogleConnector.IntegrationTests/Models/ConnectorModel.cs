﻿using adzu.connectorhub.contracts.Model;

namespace Adzu.GoogleConnector.IntegrationTests.Models
{
    public static class ConnectorModel
    {
        public const string OutputKey = "OutputKey";
        public const string RequestId = "RequestId";      
        public const string TenantCallbackUrl = "TenantCallbackUrl";
        public const string TenantAccountId = "TenantAccountId";
        public const string S3PackageUrl = "S3PackageUrl";
        public const string ConnectionReference = "ConnectionReference";
        public const string ConnectorHubClient = "ConnectorHubClient";
        public const string Connector = "Connector";
        public const string NotificationErrors = "NotificationErrors";
    }
}
