﻿namespace Adzu.GoogleConnector.IntegrationTests.Models
{
    public class TestOptions
    {
        public string BaseUrlCHB { get; set; }
        public string ConnectorHubVersion { get; set; }
        public string BaseQAUrlGoogleConnector { get; set; }
        public string BaseDEVUrlGoogleConnector { get; set; }
        public string BaseUrlCNM { get; set; }
        public string DedicatedIdForGoogleIntegrationTestOnly { get; set; }     
        public string SufixActionName { get; set; }
        public string BaseUrlGoogleConnector => SufixActionName == "DEV" ? BaseDEVUrlGoogleConnector : BaseQAUrlGoogleConnector;
        public string ConnectorName => SufixActionName == "DEV" ? "GoogleConnectorDEV" : "GoogleConnector";
    }
}
