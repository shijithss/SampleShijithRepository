﻿namespace Adzu.GoogleConnector.IntegrationTests.Models
{
    public static class ConnectorActionIds
    {
        public static string TrafficPackage => "TrafficPackage";
        public static string GetTrafficDetails => "GetTrafficsDetails";
        public static string GetAccounts => "GetAccounts";        
    }
}
