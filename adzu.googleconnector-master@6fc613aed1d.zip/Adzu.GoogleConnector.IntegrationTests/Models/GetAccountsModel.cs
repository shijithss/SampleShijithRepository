﻿namespace Adzu.GoogleConnector.IntegrationTests.Models
{
    public class GetAccountsModel
    {
        public string CustomerId { get; set; }
        public string LoginCustomerId { get; set; }
        public string[] ExpectedResult { get; set; }
    }
}
