﻿namespace Adzu.GoogleConnector.IntegrationTests.Models
{
    public class AuthenticationOptions
    {
        public string ConnectorBasicAuthName { get; set; }
        public string ConnectorBasicAuthPassword { get; set; }
        public string GoogleOAuth2ClientId { get; set; }
        public string GoogleOAuth2ClientSecret { get; set; }
    }
}
