﻿using Newtonsoft.Json.Linq;

namespace Adzu.GoogleConnector.IntegrationTests.Models
{
    public class AccountsResultDTO
    {
        public JObject Response { get; set; }
        public string[] ExpectedResult { get; set; }
    }
}
