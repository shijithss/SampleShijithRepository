﻿using System.Net.Http;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.IntegrationTests
{
    public interface IGoogleConnectorClient
    {
        public Task<HttpResponseMessage> TrafficPackage(string requestId, string s3PackageUrl, string connectionReference);
    }
}
