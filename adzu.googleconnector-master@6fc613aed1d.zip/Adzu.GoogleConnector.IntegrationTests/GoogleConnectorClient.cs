﻿using Adzu.GoogleConnector.DTO;
using Adzu.GoogleConnector.IntegrationTests.Models;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.IntegrationTests
{
    public class GoogleConnectorClient : IGoogleConnectorClient
    {
        private AuthenticationOptions _authenticationOptions;
        private TestOptions _testSettings;
        private HttpClient _httpClient = new HttpClient();
        public GoogleConnectorClient(IOptionsMonitor<TestOptions> testSettings,
            IOptionsMonitor<AuthenticationOptions> authenticationOptions)
            => (_testSettings, _authenticationOptions) = (testSettings.CurrentValue, authenticationOptions.CurrentValue);
        
        public async Task<HttpResponseMessage> TrafficPackage(string requestId, string s3PackageUrl, string connectionReference)
        {
            var endpointUrl = "api/traffic-package";
            var url = $"{_testSettings.BaseUrlGoogleConnector}/{endpointUrl}";
            var body = new RequestTrafficPackageDTO
            {
                RequestToken = requestId,
                ActionId = ConnectorActionIds.TrafficPackage,
                Input = new Input
                {
                    PackageUrl = s3PackageUrl,
                    ConnectionReference = connectionReference,
                    WithoutNotify = true
                }
            };
            var json = JsonConvert.SerializeObject(body);
            var objectContent = new StringContent(json, UnicodeEncoding.UTF8, "application/json");

            var base64EncodedAuthenticationString = Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII
                .GetBytes($"{_authenticationOptions.ConnectorBasicAuthName}:{_authenticationOptions.ConnectorBasicAuthPassword}"));

            _httpClient.DefaultRequestHeaders.Authorization
                = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", base64EncodedAuthenticationString);

            var response = await _httpClient.PostAsync(url, objectContent);           
            return response;
        }
    }
}
