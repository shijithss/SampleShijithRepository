﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.IntegrationTests
{
    public class UnitTestMessageHandler : DelegatingHandler
    {
        private readonly bool _skipBody;
        private readonly bool _logDetailed;

        public UnitTestMessageHandler(bool skipBody = false, bool logDetailed = false)
        {
            _skipBody = skipBody;
            _logDetailed = logDetailed;
        }

        async protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            var req = request;
            var id = Guid.NewGuid().ToString();
            var msg = $"[{id} -   Request]";

            WriteLine($"{msg}========Start==========");
            WriteLine($"{msg} {req.Method} {req.RequestUri.Scheme}://{req.RequestUri.Host}:{req.RequestUri.Port}{req.RequestUri.PathAndQuery}");

            foreach (var header in req.Headers)
            {
                if (_logDetailed)
                {
                    WriteLine($"{msg} {header.Key}: {string.Join(", ", header.Value)}");
                }
                else
                {
                    if (header.Key == "Authorization")
                    {
                        WriteLine($"{msg} {header.Key}: {header.Value.FirstOrDefault()?.Split(' ').FirstOrDefault()}");
                    }
                }
            }

            if (!_skipBody && req.Content != null)
            {
                if (_logDetailed)
                {
                    foreach (var header in req.Content.Headers)
                    {
                        WriteLine($"{msg} {header.Key}: {string.Join(", ", header.Value)}");
                    }
                }

                if (req.Content is StringContent || IsTextBasedContentType(req.Headers) || IsTextBasedContentType(req.Content.Headers))
                {
                    var result = await req.Content.ReadAsStringAsync();

                    WriteLine($"{msg} Content:");
                    WriteLine($"{msg} {string.Join("", result.Cast<char>())}");
                }
            }

            var timer = new Stopwatch();
            timer.Start();

            var response = await base.SendAsync(request, cancellationToken).ConfigureAwait(false);
            timer.Stop();
            WriteLine($"{msg} Duration: {timer.Elapsed:m\\:ss\\.fff}");
            msg = $"[{id} - Response]";
            var resp = response;
            WriteLine($"{msg} {req.RequestUri.Scheme.ToUpper()}/{resp.Version} {(int)resp.StatusCode} {resp.ReasonPhrase}");

            if (_logDetailed)
            {
                foreach (var header in resp.Headers)
                {
                    WriteLine($"{msg} {header.Key}: {string.Join(", ", header.Value)}");
                }
            }

            if (!_skipBody && resp.Content != null)
            {
                if (_logDetailed)
                {
                    foreach (var header in resp.Content.Headers)
                    {
                        WriteLine($"{msg} {header.Key}: {string.Join(", ", header.Value)}");
                    }
                }

                if (resp.Content is StringContent || IsTextBasedContentType(resp.Headers) || IsTextBasedContentType(resp.Content.Headers))
                {
                    timer.Restart();
                    var result = await resp.Content.ReadAsStringAsync();
                    timer.Stop();

                    WriteLine($"{msg} Content:");
                    WriteLine($"{msg} {string.Join("", result.Cast<char>())}");
                    WriteLine($"{msg} Duration: {timer.Elapsed:m\\:ss\\.fff}");
                }
            }

            WriteLine($"{msg}==========End==========");

            if (response.StatusCode == HttpStatusCode.SeeOther)
            {
                return await SendAsync(CreateRedirectMessage(request, response), cancellationToken).ConfigureAwait(false);
            }

            return response;
        }

        private void WriteLine(string message)
        {
            TestContext.WriteLine(message);
        }

        private static HttpRequestMessage CreateRedirectMessage(HttpRequestMessage originalRequest, HttpResponseMessage message)
        {
            var location = message.Headers.Location;

            if (location == null)
                throw new InvalidOperationException("Redirect URL is not defined.");

            var request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri(new Uri(originalRequest.RequestUri.GetLeftPart(UriPartial.Authority)), location)
            };

            foreach (var (key, value) in originalRequest.Headers)
            {
                request.Headers.Add(key, value);
            }

            return request;
        }

        readonly string[] types = new[] { "html", "text", "xml", "json", "txt", "x-www-form-urlencoded" };

        bool IsTextBasedContentType(HttpHeaders headers)
        {
            IEnumerable<string> values;
            if (!headers.TryGetValues("Content-Type", out values))
            {
                return false;
            }
            var header = string.Join(" ", values).ToLowerInvariant();

            return types.Any(t => header.Contains(t));
        }
    }
}
