﻿using Adzu.ConnectionManager.SDK;
using Microsoft.Extensions.Logging;

namespace Adzu.GoogleConnector.Services
{
    public class GoogleServiceProvider : IGoogleServiceProvider
    {
        private IConnectionManagerClient _connectionManagerClient;
        private IGoogleGatewayService _googleService;
        private ILogger<GoogleGatewayService> _logger;

        public GoogleServiceProvider(IConnectionManagerClient connectionManagerClient,
            ILogger<GoogleGatewayService> logger,
            IGoogleGatewayService googleService)
                => (_connectionManagerClient, _googleService, _logger) = (connectionManagerClient, googleService, logger);

        public IGoogleGatewayService GetGatewayService(string connectionReference)
        {
            var accessTokenResponse = _connectionManagerClient.OAuth2
                .RetrieveAccessToken(new ConnectionManager.Contracts.Requests.AccessTokenRequest
                {
                    ConnectionRef = connectionReference
                });
            _logger.LogInformation($"connectionReference:{ connectionReference}, AccessToken:{accessTokenResponse.Result.AccessToken}");
            return _googleService.SetParameters(accessTokenResponse.Result.AccessToken);
        }
    }
}
