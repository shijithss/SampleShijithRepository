﻿using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Services
{
    public class HttpRequestService : IHttpRequestService
    {
        private HttpClient _httpClient = new HttpClient();
        public async Task PostRequest(string callbackUrl, string body)
        {

            var objectContent = new StringContent(body, UnicodeEncoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync(callbackUrl, objectContent);

            using var httpActivity = LambdaEntryPoint.LambdaActivitySource
                .StartActivity($"HTTP.PostAsync.StatusCode{response.StatusCode}")
                .SetTag("URL", callbackUrl)
                .AddTag("StatusCode",response.StatusCode)
                .AddTag("success", response.IsSuccessStatusCode);
        }
        public async Task<Stream> ReadFile(string fileUrl)
        {
            var response = await _httpClient.GetAsync(fileUrl);

            using var httpActivity = LambdaEntryPoint.LambdaActivitySource
                .StartActivity($"HTTP.ReadFile.StatusCode{response.StatusCode}")
                .SetTag("URL", fileUrl)
                .AddTag("StatusCode", response.StatusCode)
                .AddTag("success", response.IsSuccessStatusCode);
            
                return await response.EnsureSuccessStatusCode().Content.ReadAsStreamAsync();
           
        }
    }
}
