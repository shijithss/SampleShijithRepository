﻿namespace Adzu.GoogleConnector.Services
{
    public interface IGoogleServiceProvider
    {
        public IGoogleGatewayService GetGatewayService(string connectionReference);
    }
}
