﻿using Adzu.GoogleConnector.DTO;
using System.Collections.Generic;

namespace Adzu.GoogleConnector.Services
{
    public class GoogleCustomersService : IGoogleCustomersService
    {
        private IGoogleServiceProvider _serviceProvider;
        public GoogleCustomersService(IGoogleServiceProvider serviceProvider)
            => _serviceProvider = serviceProvider;

        IList<CustomerAccountDTO> IGoogleCustomersService.GetAccessibleCustomers(GetAccountsRequest dto)
        {
            var googleGatewayService = _serviceProvider.GetGatewayService(dto.Input.ConnectionReference);
            var isRequestForRootCustomers = string.IsNullOrEmpty(dto.Input.CustomerId) 
                || string.IsNullOrEmpty(dto.Input.LoginCustomerId);

            var accounts = isRequestForRootCustomers
                ? googleGatewayService.GetRootAccessibleCustomers()
                : googleGatewayService.GetNodeAccessibleCustomers(dto.Input.LoginCustomerId, dto.Input.CustomerId);

            return accounts;
        }
    }
}
