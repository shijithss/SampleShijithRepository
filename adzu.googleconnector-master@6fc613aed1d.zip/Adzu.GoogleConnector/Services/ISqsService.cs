﻿using Adzu.GoogleConnector.DTO;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Services
{
    public interface ISqsService
    {
        public Task SendMessage(EventDTO requestDTO, string messageQueueUrl);
    }
}
