﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Http;
using System.Threading;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Services.GoogleInheritors
{
    public class AccessTokenCredential : ICredential
    {
        private string _accessToken;
        public AccessTokenCredential(string accessToken)
        {
            _accessToken = accessToken;
        }
        public Task<string> GetAccessTokenForRequestAsync(string authUri = null, CancellationToken cancellationToken = default)
        {
            return Task.FromResult(_accessToken);
        }

        public void Initialize(ConfigurableHttpClient httpClient)
        {

        }
    }
}
