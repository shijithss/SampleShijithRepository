﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Adzu.GoogleConnector.DTO;
using Google.Ads.GoogleAds.Config;
using Google.Ads.GoogleAds.Lib;
using Google.Ads.GoogleAds.V9.Resources;
using Google.Ads.GoogleAds.V9.Services;
using Google.Api.Gax.Grpc;
using static Google.Ads.GoogleAds.V9.Enums.CampaignStatusEnum.Types;
using Asset = Google.Ads.GoogleAds.V9.Resources.Asset;

namespace Adzu.GoogleConnector.Services.GoogleInheritors
{
    public interface IGoogleAdsClient
    {
        GoogleAdsConfig Config { get; }

        EventHandler<object> OnResponseMetadataReceived { get; set; }


        TService GetService<TService, TServiceSetting>(ServiceTemplate<TService, TServiceSetting> serviceTemplate)
           where TService : GoogleAdsServiceClientBase
           where TServiceSetting : ServiceSettingsBase, new();

        List<CustomerAccountDTO> GetListAccessibleCustomers();
        List<CustomerAccountDTO> GetNodeAccessibleCustomers(string loginCustomerId, string customerId);
        string CreateBudget(PackageManifestDTO packageManifest);
        string CreateCampaign(PackageManifestDTO packageManifest, string budgetResourcesName);
        string UpdateCampaignStatus(long customerId, long campaignId, CampaignStatus status);
        string AddAdGroup(long campaignId, PackageManifestDTO packageManifest);
        List<string> CreateMediaBundleAsset(List<Asset> assets, string customerId);
        List<string> CreateDisplayUploadAdGroupAd(long adGroupId, List<string> assetIds, PackageManifestDTO packageManifest);
        CampaignCriterion BuildProximityCriterion(string campaignResourceName, PostCode geoData);
        List<string> SetGeoTargetingForCampaign(string customerId, List<CampaignCriterionOperation> operations);
    }
}
