﻿using Google.Ads.GoogleAds.Config;
using Google.Apis.Auth.OAuth2;
using System.Collections.Generic;

namespace Adzu.GoogleConnector.Services.GoogleInheritors
{
    public class CustomGoogleConfig : GoogleAdsConfig
    { 
        private AccessTokenCredential AccessTokenCredential { get; set; }       

        public CustomGoogleConfig(
            Dictionary<string, string> configData, 
            string accessToken) : base(configData)
        {
            AccessTokenCredential = new AccessTokenCredential(accessToken);
        }

        protected override ICredential CreateCredentials()
        {
            return AccessTokenCredential;
        }
    }
}
