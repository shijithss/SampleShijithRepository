﻿using Adzu.GoogleConnector.DTO;
using Google.Ads.GoogleAds.Config;
using Google.Ads.GoogleAds.Lib;
using Google.Ads.GoogleAds.V9.Common;
using Google.Ads.GoogleAds.V9.Enums;
using Google.Ads.GoogleAds.V9.Errors;
using Google.Ads.GoogleAds.V9.Resources;
using Google.Ads.GoogleAds.V9.Services;
using Google.Api.Gax;
using Google.Protobuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using static Google.Ads.GoogleAds.V9.Enums.AdvertisingChannelTypeEnum.Types;
using static Google.Ads.GoogleAds.V9.Enums.BudgetDeliveryMethodEnum.Types;
using static Google.Ads.GoogleAds.V9.Enums.CampaignStatusEnum.Types;
using static Google.Ads.GoogleAds.V9.Enums.DisplayUploadProductTypeEnum.Types;
using static Google.Ads.GoogleAds.V9.Resources.Campaign.Types;
using Campaign = Google.Ads.GoogleAds.V9.Resources.Campaign;
using GoogleAdsServices = Google.Ads.GoogleAds.Services;
using Asset = Google.Ads.GoogleAds.V9.Resources.Asset;
using Google.Ads.GoogleAds.Util;
using static Google.Ads.GoogleAds.V9.Enums.ProximityRadiusUnitsEnum.Types;

namespace Adzu.GoogleConnector.Services.GoogleInheritors
{
    public class CustomGoogleAdsClient : GoogleAdsClient, IGoogleAdsClient
    {
        public CustomGoogleAdsClient() : base() { }
        public CustomGoogleAdsClient(GoogleAdsConfig config) : base(config)
        {
        }

        public List<CustomerAccountDTO> GetListAccessibleCustomers()
        {
            var customerService = this.GetService(Google.Ads.GoogleAds.Services.V9.CustomerService);
            var customerResourceNames = customerService.ListAccessibleCustomers();
            var customers = new List<CustomerAccountDTO>();
            foreach (string customerResourceName in customerResourceNames)
            {
                this.Config.LoginCustomerId = GetCustomerFromResourceName(customerResourceName);

                var customer = customerService.GetCustomer(customerResourceName);
                customers.Add(new CustomerAccountDTO
                {
                    CurrencyCode = customer.CurrencyCode,
                    CustomerId = customer.Id.ToString(),
                    DescriptiveName = customer.DescriptiveName,
                    HasManager = customer.HasManager,
                    IsManager = customer.Manager,
                    IsTestAccount = customer.TestAccount,
                    TimeZone = customer.TimeZone,
                    LoginCustomerId = GetCustomerFromResourceName(customer.ResourceName)
                });
            }
            return customers;
        }

        public List<CustomerAccountDTO> GetNodeAccessibleCustomers(string loginCustomerId, string customerId)
        {
            var customers = new List<CustomerAccountDTO>();
            if (!string.IsNullOrEmpty(loginCustomerId))
            {
                this.Config.LoginCustomerId = loginCustomerId;
            }
            else
            {
                throw new Exception($"ErrorId:{Guid.NewGuid()} Message: No LoginCustomerId specified");
            }
            GoogleAdsServiceClient googleAdsServiceClient =
                this.GetService(GoogleAdsServices.V9.GoogleAdsService);

            const string query = @"SELECT
                                    customer_client.client_customer,
                                    customer_client.level,
                                    customer_client.manager,
                                    customer_client.descriptive_name,
                                    customer_client.currency_code,
                                    customer_client.time_zone,
                                    customer_client.id,
                                    customer_client.test_account
                                FROM customer_client
                                WHERE
                                    customer_client.level <= 1";

            CustomerClient rootCustomerClient = null;

            PagedEnumerable<SearchGoogleAdsResponse, GoogleAdsRow> response =
                googleAdsServiceClient.Search(
                    customerId,
                    query
                );

            foreach (GoogleAdsRow googleAdsRow in response)
            {
                CustomerClient customer = googleAdsRow.CustomerClient;

                if (customer.Level == 0)
                {
                    if (rootCustomerClient == null)
                    {
                        rootCustomerClient = customer;
                    }
                    continue;
                }

                customers.Add(new CustomerAccountDTO
                {
                    CurrencyCode = customer.CurrencyCode,
                    CustomerId = customer.Id.ToString(),
                    DescriptiveName = customer.DescriptiveName,
                    HasManager = customer.HasManager,
                    IsManager = customer.Manager,
                    IsTestAccount = customer.TestAccount,
                    TimeZone = customer.TimeZone,
                    LoginCustomerId = loginCustomerId
                });
            }
            return customers;
        }

        public string CreateCampaign(PackageManifestDTO packageManifest, string budgetResourcesName)
        {
            CampaignServiceClient campaignService = this.GetService(GoogleAdsServices.V9.CampaignService);

            List<CampaignOperation> operations = new List<CampaignOperation>();

            Campaign campaign = new Campaign()
            {

                Name = packageManifest.Code,
                AdvertisingChannelType = AdvertisingChannelType.Display,

                // Recommendation: Set the campaign to PAUSED when creating it to prevent
                // the ads from immediately serving. Set to ENABLED once you've added
                // targeting and the ads are ready to serve
                Status = CampaignStatus.Paused,
                ManualCpc = new ManualCpc(),
                CampaignBudget = budgetResourcesName,
                NetworkSettings = new NetworkSettings
                {
                    TargetGoogleSearch = false,
                    TargetSearchNetwork = false,
                    TargetContentNetwork = true,
                    TargetPartnerSearchNetwork = false
                },
                StartDate = packageManifest.StartDateForGoogle(),
                EndDate = packageManifest.EndDateForGoogle(),
            };
            operations.Add(new CampaignOperation() { Create = campaign });

            MutateCampaignsResponse retVal = campaignService.MutateCampaigns(
                   packageManifest.MediaEndpointData.CustomerId, operations);

            return retVal.Results.First().ResourceName;
        }

        public string UpdateCampaignStatus(long customerId, long campaignId, CampaignStatus status)
        {
            CampaignServiceClient campaignService = this.GetService(GoogleAdsServices.V9.CampaignService);
            Campaign campaignToUpdate = new Campaign()
            {
                ResourceName = ResourceNames.Campaign(customerId, campaignId),
                Status = status
            };

            CampaignOperation operation = new CampaignOperation()
            {
                Update = campaignToUpdate,
                UpdateMask = FieldMasks.AllSetFieldsOf(campaignToUpdate)
            };
            MutateCampaignsResponse response = campaignService.MutateCampaigns(
                    customerId.ToString(), new[] { operation });
            return response.Results.First().ResourceName;
        }

        public string CreateBudget(PackageManifestDTO packageManifest)
        {
            CampaignBudgetServiceClient budgetService = this.GetService(
                GoogleAdsServices.V9.CampaignBudgetService);

            CampaignBudget budget = new CampaignBudget()
            {
                Name = $"{packageManifest.Code} budget",
                DeliveryMethod = BudgetDeliveryMethod.Standard,
                AmountMicros = (long)(packageManifest.PlannedMediaCost.Value * 1000000)
            };

            CampaignBudgetOperation budgetOperation = new CampaignBudgetOperation()
            {
                Create = budget
            };

            MutateCampaignBudgetsResponse response = budgetService.MutateCampaignBudgets(
               packageManifest.MediaEndpointData.CustomerId, new CampaignBudgetOperation[] { budgetOperation });
            return response.Results.First().ResourceName;
        }

        public string AddAdGroup(long campaignId, PackageManifestDTO packageManifest)
        {
            AdGroupServiceClient adGroupService = this.GetService(GoogleAdsServices.V9.AdGroupService);

            List<AdGroupOperation> operations = new List<AdGroupOperation>();

            AdGroup adGroup = new AdGroup()
            {
                Name = $"{packageManifest.Code} Ad Group",
                Status = AdGroupStatusEnum.Types.AdGroupStatus.Enabled,
                Campaign = ResourceNames.Campaign(long.Parse(packageManifest.MediaEndpointData.CustomerId), campaignId),

                CpcBidMicros = (long)(packageManifest.PlannedMediaCost.Value * 1000000)
            };

            AdGroupOperation operation = new AdGroupOperation()
            {
                Create = adGroup
            };
            operations.Add(operation);
            MutateAdGroupsResponse response = adGroupService.MutateAdGroups(
                    packageManifest.MediaEndpointData.CustomerId, operations);
            return response.Results.First().ResourceName;
        }
        public List<string> CreateMediaBundleAsset(List<Asset> assets, string customerId)
        {
            AssetServiceClient assetServiceClient = this.GetService(GoogleAdsServices.V9.AssetService);
            var operations = new List<AssetOperation>();
            foreach (var asset in assets)
            {
                AssetOperation operation = new AssetOperation()
                {
                    Create = asset
                };
                operations.Add(operation);
            }
            MutateAssetsResponse response = assetServiceClient.MutateAssets(customerId,
                operations.ToArray());
            return response.Results.Select(x => x.ResourceName).ToList();
        }

        public List<string> CreateDisplayUploadAdGroupAd(long adGroupId, List<string> assetIds, PackageManifestDTO packageManifest)
        {
            AdGroupAdServiceClient adGroupAdServiceClient =
                this.GetService(GoogleAdsServices.V9.AdGroupAdService);
            var operations = new List<AdGroupAdOperation>();
            foreach (var assetId in assetIds)
            {
                Ad displayUploadAd = new Ad()
                {
                    Name = $"{packageManifest.Code} Ad",
                    FinalUrls = { packageManifest.MediaEndpointData.ClickThroughUrl },
                    DisplayUploadAd = new DisplayUploadAdInfo()
                    {
                        DisplayUploadProductType = DisplayUploadProductType.Html5UploadAd,
                        MediaBundle = new AdMediaBundleAsset()
                        {
                            Asset = assetId
                        }
                    }
                };
                AdGroupAd adGroupAd = new AdGroupAd()
                {
                    Ad = displayUploadAd,
                    Status = AdGroupAdStatusEnum.Types.AdGroupAdStatus.Paused,
                    AdGroup = ResourceNames.AdGroup(long.Parse(packageManifest.MediaEndpointData.CustomerId), adGroupId),
                };
                AdGroupAdOperation operation = new AdGroupAdOperation()
                {
                    Create = adGroupAd
                };
                operations.Add(operation);
            }

            MutateAdGroupAdsResponse response = adGroupAdServiceClient.MutateAdGroupAds(packageManifest.MediaEndpointData.CustomerId, operations.ToArray());
            return response.Results.Select(x => x.ResourceName).ToList();
        }

        public CampaignCriterion BuildProximityCriterion(string campaignResourceName, PostCode geoData)
        {
            var addressInfo = new AddressInfo()
            {
                PostalCode = geoData.PostalCode,
                CountryCode = geoData.CountryCode
            };
            if (!string.IsNullOrEmpty(geoData.CityName))
            {
                addressInfo.CityName = geoData.CityName;
            }
            ProximityInfo proximity = new ProximityInfo()
            {
                Address = addressInfo,
                Radius = double.Parse(geoData.Radius),
                RadiusUnits = !string.IsNullOrEmpty(geoData.RadiusUnits) && geoData.RadiusUnits.Contains(Miles, StringComparison.OrdinalIgnoreCase) ? ProximityRadiusUnits.Miles : ProximityRadiusUnits.Kilometers
            };

            return new CampaignCriterion()
            {
                Campaign = campaignResourceName,
                Proximity = proximity
            };
        }

        public List<string> SetGeoTargetingForCampaign(string customerId, List<CampaignCriterionOperation> operations)
        {
            CampaignCriterionServiceClient campaignCriterionService =
                        this.GetService(GoogleAdsServices.V9.CampaignCriterionService);

            MutateCampaignCriteriaResponse response =
                campaignCriterionService.MutateCampaignCriteria(customerId.ToString(),
                    operations);

            return response.Results.Select(x => x.ResourceName).ToList();
        }

        private const string Miles = "miles";
        private string GetCustomerFromResourceName(string resourceName)
        {
            string pattern = @"(?!rs/)[0-9]+(?<!/)";
            var match = Regex.Match(resourceName, pattern);
            if (match != null)
                return match.Value;
            return string.Empty;
        }
    }
}

