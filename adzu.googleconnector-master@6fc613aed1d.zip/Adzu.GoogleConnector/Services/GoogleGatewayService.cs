﻿using Adzu.GoogleConnector.DTO;
using Adzu.GoogleConnector.Helpers;
using Adzu.GoogleConnector.Services.GoogleInheritors;
using Google.Ads.GoogleAds.V9.Common;
using Google.Ads.GoogleAds.V9.Enums;
using Google.Ads.GoogleAds.V9.Errors;
using Google.Ads.GoogleAds.V9.Resources;
using Google.Ads.GoogleAds.V9.Services;
using Google.Api.Gax;
using Google.Protobuf;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using static Google.Ads.GoogleAds.V9.Enums.CampaignStatusEnum.Types;
using Asset = Google.Ads.GoogleAds.V9.Resources.Asset;

namespace Adzu.GoogleConnector.Services
{
    public class GoogleGatewayService : IGoogleGatewayService
    {
        private GoogleConfigDTO _googleConfig;
        private IGoogleAdsClient _client;
        private ILogger<GoogleGatewayService> _logger;
        public bool IsTestingMode = false;

        public GoogleGatewayService(IOptionsMonitor<GoogleConfigDTO> googleConfig, ILogger<GoogleGatewayService> logger, IGoogleAdsClient googleAdsClient)
            => (_googleConfig, _logger, _client) = (googleConfig.CurrentValue, logger, googleAdsClient);

        public IGoogleGatewayService SetParameters(string accessToken)
        {
            var configData = new Dictionary<string, string>();
            configData.Add("ProxyServer", "");
            configData.Add("ProxyUser", "");
            configData.Add("ProxyDomain", "");
            configData.Add("ProxyPassword", "");
            configData.Add("Timeout", "100000");
            configData.Add("EnableGzipCompression", "true");
            configData.Add("RetryCount", "1");
            configData.Add("UserAgent", _googleConfig.UserAgent);
            configData.Add("OAuth2Mode", _googleConfig.OAuth2Mode);
            configData.Add("DeveloperToken", _googleConfig.DeveloperToken);
            configData.Add("AuthorizationMethod", _googleConfig.AuthorizationMethod);

            var config = new CustomGoogleConfig(configData, accessToken);
            _client = new CustomGoogleAdsClient(config);

            return this;
        }
        public List<CustomerAccountDTO> GetRootAccessibleCustomers()
        {
            var customers = new List<CustomerAccountDTO>();
            using var activity = StartActivity("GoogleGatewayService.GetListAccessibleCustomers");
            try
            {
                customers = _client.GetListAccessibleCustomers();
            }
            catch (GoogleAdsException e)
            {
                throw new Exception($"ErrorId:{Guid.NewGuid()}, Request ID: {e.RequestId}, Failure: {e.Failure}  Message: {e.Message}", e);
            }
            catch (Exception e)
            {
                throw new Exception($"ErrorId:{Guid.NewGuid()}, Message: {e.Message}", e);
            }
            return customers;
        }

        public List<CustomerAccountDTO> GetNodeAccessibleCustomers(string loginCustomerId, string customerId)
        {
            var customers = new List<CustomerAccountDTO>();
            using var activity = StartActivity("GoogleGatewayService.GetNodeAccessibleCustomers");

            try
            {
                customers = _client.GetNodeAccessibleCustomers(loginCustomerId, customerId);
            }
            catch (GoogleAdsException e)
            {
                _logger.LogError($"ErrorId:{Guid.NewGuid()}, GoogleAdsException exception when trying get customer info. Request ID: {e.RequestId}, Failure: {e.Failure}  Message: {e.Message}");
            }
            catch (Exception e)
            {
                _logger.LogError($"Exception when trying get customer info with error: {e.Message}");
            }
            return customers;
        }

        public async Task<TrafficPackageCompletedNotificationDTO> SendAdToGoogle(
            PackageManifestDTO packageManifest, 
            string prefixDownloadPackageUrl, 
            Func<string, Task<byte[]>> downloadCallback)
        {
            using var activity = StartActivity("GoogleGatewayService.SendAdToGoogle");
            var customerId = long.Parse(packageManifest.MediaEndpointData.CustomerId.Replace("-", string.Empty));
            var loginCustomerId = string.Empty;
            if (!string.IsNullOrEmpty(packageManifest.MediaEndpointData.LoginCustomerId))
            {
                loginCustomerId = packageManifest.MediaEndpointData.LoginCustomerId;
                if (_client.Config != null)
                    _client.Config.LoginCustomerId = loginCustomerId;
            }
            var retval = new TrafficPackageCompletedNotificationDTO();
            var campaignId = CreateCampaign(packageManifest);
            if (campaignId > 0)
            {
                var adGroupId = AddAdGroup(campaignId, packageManifest);

                var mediaBundleUploadResult = await AddMediaBundleAsync(adGroupId, 
                    packageManifest, 
                    prefixDownloadPackageUrl, 
                    downloadCallback);
                retval.Assets = mediaBundleUploadResult.Item2;
                if (mediaBundleUploadResult.Item1 == true)
                {
                    SetGeoTargeting(campaignId, packageManifest);
                    if (!IsTestingMode)
                    {
                        StartCampaign(packageManifest, campaignId);
                    }

                    //return string should be campaign external ID, but we should give back extended version of campaign ID
                    //what should reflect customerId and loginCustomerId
                    //TODO: return format to be specified
                    var campaignIdentifier = $"{campaignId}//{customerId}//{loginCustomerId}";
                    _logger.LogInformation($"SendAdToGoogle is complete with campaignIdentifier: {campaignIdentifier}");
                    retval.ExternalId = campaignIdentifier;
                    retval.ExternalCampaignId = campaignId.ToString();

                }
                return retval;
            }
            else
            {
                throw new Exception($"ErrorId:{Guid.NewGuid()}, Message: Failed to process transaction, campaignId not found", null);
            }
        }

        private void SetGeoTargeting(long campaignId, PackageManifestDTO packageManifest)
        {
            string campaignResourceName = ResourceNames.Campaign(long.Parse(packageManifest.MediaEndpointData.CustomerId), campaignId);
            List<CampaignCriterionOperation> operations = new List<CampaignCriterionOperation>();
            if (packageManifest.BusinessUnits != null)
                foreach (var bu in packageManifest.BusinessUnits)
                {
                    if (bu.Geographic != null)
                        foreach (var item in bu.Geographic.PostCodes)
                        {
                            CampaignCriterion proximityCriterion = _client.BuildProximityCriterion(campaignResourceName, item);
                            CampaignCriterionOperation proximityCriterionOperation =
                                new CampaignCriterionOperation()
                                {
                                    Create = proximityCriterion
                                };
                            operations.Add(proximityCriterionOperation);
                        }
                }
            if (operations.Count > 0)
            {
                try
                {
                    var resourseNames = _client.SetGeoTargetingForCampaign(packageManifest.MediaEndpointData.CustomerId, operations);
                    foreach (var item in resourseNames)
                    {
                        _logger.LogInformation($"New campaign criterion with resource name = " +
                            $"'{item}' was added to campaign " +
                            $"ID {campaignId}.");
                    }
                }
                catch (GoogleAdsException e)
                {
                    throw new Exception($"ErrorId:{Guid.NewGuid()}, Request ID: {e.RequestId}, Failure: {e.Failure}  Message: {e.Message}", e);
                }
                catch (Exception e)
                {
                    throw new Exception($"ErrorId:{Guid.NewGuid()}, Message: {e.Message}", e);
                }
            }
        }

        private async Task<(bool, List<AssetUploadStatus>)> AddMediaBundleAsync(long adGroupId, 
            PackageManifestDTO packageManifest, 
            string prefixDownloadPackageUrl, 
            Func<string, Task<byte[]>> downloadCallback)
        {
            var activity = StartActivity("GoogleGatewayService.AddMediaBundleAsync");
            try
            {
                var adAssetUploadStatuses = await CreateMediaBundleAssetAsync(
                    packageManifest, 
                    prefixDownloadPackageUrl, 
                    downloadCallback);
                if (adAssetUploadStatuses.All(x => x.Status == PackageStatusEnum.Success.ToString()))
                {
                    CreateDisplayUploadAdGroupAd(adGroupId, adAssetUploadStatuses, packageManifest);
                    return (true, adAssetUploadStatuses);
                }
                else
                {
                    return (false, adAssetUploadStatuses);
                }
            }
            catch (GoogleAdsException e)
            {
                throw new Exception($"ErrorId:{Guid.NewGuid()}, Request ID: {e.RequestId}, Failure: {e.Failure}  Message: {e.Message}", e);
            }
            catch (Exception e)
            {
                throw new Exception($"ErrorId:{Guid.NewGuid()}, Message: {e.Message}", e);
            }
        }
        private long AddAdGroup(long campaignId, PackageManifestDTO packageManifest)
        {
            var activity = StartActivity("GoogleGatewayService.AddAdGroup");

            try
            {
                var adGroupResourceName = _client.AddAdGroup(campaignId, packageManifest);
                _logger.LogInformation($"Ad group with resource name {adGroupResourceName} was created.");

                return GetAdEntityId(adGroupResourceName);
            }
            catch (GoogleAdsException e)
            {
                throw new Exception($"ErrorId:{Guid.NewGuid()}, Request ID: {e.RequestId}, Failure: {e.Failure}  Message: {e.Message}", e);
            }
            catch (Exception e)
            {
                throw new Exception($"ErrorId:{Guid.NewGuid()}, Message: {e.Message}", e);
            }
        }

        private long CreateCampaign(PackageManifestDTO packageManifest)
        {
            var activity = StartActivity("GoogleGatewayService.CreateCampaign");

            string budgetResourceName = CreateBudget(packageManifest);

            try
            {
                var campaignResourceName = _client.CreateCampaign(packageManifest, budgetResourceName);

                _logger.LogInformation($"Campaign with resource ID {campaignResourceName} was added.");
                return GetAdEntityId(campaignResourceName);

            }
            catch (GoogleAdsException e)
            {
                throw new Exception($"ErrorId:{Guid.NewGuid()}, Request ID: {e.RequestId}, Failure: {e.Failure}  Message: {e.Message}", e);
            }
            catch (Exception e)
            {
                throw new Exception($"ErrorId:{Guid.NewGuid()}, Message: {e.Message}", e);
            }
        }

        private void StartCampaign(PackageManifestDTO packageManifest, long campagnId)
        {
            var activity = StartActivity("GoogleGatewayService.StartCampaign");
            try
            {
                var campaignResourceName = _client.UpdateCampaignStatus(long.Parse(packageManifest.MediaEndpointData.CustomerId), campagnId, CampaignStatus.Enabled);

                _logger.LogInformation($"Campaign with resource ID {campaignResourceName} was started.");

            }
            catch (GoogleAdsException e)
            {
                throw new Exception($"ErrorId:{Guid.NewGuid()}, Request ID: {e.RequestId}, Failure: {e.Failure}  Message: {e.Message}", e);
            }
            catch (Exception e)
            {
                throw new Exception($"ErrorId:{Guid.NewGuid()}, Message: {e.Message}", e);
            }
        }

        private string CreateBudget(PackageManifestDTO packageManifest)
        {
            var activity = StartActivity("GoogleGatewayService.CreateBudget");

            try
            {
                var budgetResourceName = _client.CreateBudget(packageManifest);
                _logger.LogInformation($"Campaign Budget with resource name {budgetResourceName} was added.");
                return budgetResourceName;
            }
            catch (GoogleAdsException e)
            {
                throw new Exception($"ErrorId:{Guid.NewGuid()}, Request ID: {e.RequestId}, Failure: {e.Failure}  Message: {e.Message}", e);
            }
            catch (Exception e)
            {
                throw new Exception($"ErrorId:{Guid.NewGuid()}, Message: {e.Message}", e);
            }

        }

        private async Task<List<AssetUploadStatus>> CreateMediaBundleAssetAsync(
            PackageManifestDTO packageManifest, 
            string prefixDownloadPackageUrl, 
            Func<string, Task<byte[]>> downloadCallback)
        {
            var assets = new List<Asset>();
            var retval = new List<AssetUploadStatus>();
            foreach (var asset in packageManifest.Assets)
            {
                if (downloadCallback != null)
                {
                    _logger.LogInformation($"Create asset used file: {prefixDownloadPackageUrl}{asset.Package}");
                    Asset mediaBundleAsset = new Asset()
                    {
                        Type = AssetTypeEnum.Types.AssetType.MediaBundle,
                        MediaBundleAsset = new MediaBundleAsset()
                        {
                            Data = ByteString.CopyFrom(await downloadCallback($"{prefixDownloadPackageUrl}{asset.Package}"))
                        }
                    };
                    assets.Add(mediaBundleAsset);
                }
                retval.Add(new AssetUploadStatus
                {
                    AssetId = asset.Id
                });
            }

            try
            {
                var uploadedAssetResourceNames = _client.CreateMediaBundleAsset(assets, packageManifest.MediaEndpointData.CustomerId);

                for (int i = 0; i < uploadedAssetResourceNames.Count; i++)
                {
                    _logger.LogInformation($"Asset with resource name {uploadedAssetResourceNames[i]} was added.");
                    retval[i].ExternalId = uploadedAssetResourceNames[i];
                    retval[i].Status = PackageStatusEnum.Success.ToString();
                }
                return retval;
            }
            catch (GoogleAdsException e)
            {
                foreach (var error in e.Failure.Errors)
                {
                    var assetIndex = GetIndex(error.CombinedFieldPath);
                    retval[assetIndex].Status = PackageStatusEnum.Fail.ToString();
                    retval[assetIndex].Reason = error.Message;
                    retval[assetIndex].Errors = $"CombinedFieldPath: {error.CombinedFieldPath}, ErrorCode: {error.ErrorCode}, Trigger: {error.Trigger}";
                }
            }
            return retval;
        }

        private void CreateDisplayUploadAdGroupAd(long adGroupId, List<AssetUploadStatus> adAssetUploadStatuses, PackageManifestDTO packageManifest)
        {
            var assetExternalIds = adAssetUploadStatuses.Select(x => x.ExternalId).ToList();
            var response = _client.CreateDisplayUploadAdGroupAd(adGroupId, assetExternalIds, packageManifest);

            foreach (var item in response)
            {
                _logger.LogInformation($"AdGroupAd with resource name {item} was added.");
            }
        }

        private long GetAdEntityId(string resourceName)
        {
            string pattern = @"[0-9]+$";
            var match = Regex.Match(resourceName, pattern);
            if (match != null)
                return long.Parse(match.Value);
            return 0;
        }
        private string GetCustomerFromResourceName(string resourceName)
        {
            string pattern = @"(?!rs/)[0-9]+(?<!/)";
            var match = Regex.Match(resourceName, pattern);
            if (match != null)
                return match.Value;
            return string.Empty;
        }
        private int GetIndex(string resourceName)
        {
            string pattern = @"(?<=\[)[0-9]*";
            var match = Regex.Match(resourceName, pattern);
            if (match != null && !string.IsNullOrEmpty(match.Value))
                return int.Parse(match.Value);
            return 0;
        }

        private Activity? StartActivity(string name = "", ActivityKind kind = ActivityKind.Internal)
             => IsTestingMode ? null : LambdaEntryPoint.LambdaActivitySource.StartActivity(name, kind);
        public void SetClient(IGoogleAdsClient client)
        {
            IsTestingMode = true;
            _client = client;
        }
    }
}
