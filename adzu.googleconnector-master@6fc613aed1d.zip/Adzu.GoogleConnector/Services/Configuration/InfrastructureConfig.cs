﻿namespace Adzu.GoogleConnector.Services.Configuration
{
    public class InfrastructureConfig 
    {
        public string PlatformManagerClientId { get; set; }
        public string PlatformManagerScope { get; set; }
        public string PlatformManagerClientSecret { get; set; }
        public string ConnectorHubBaseUrl { get; set; }
        public string ConnectionManagerBaseUrl { get; set; }
        public string PlatformManagerBaseUrl { get; set; }
    }
}
