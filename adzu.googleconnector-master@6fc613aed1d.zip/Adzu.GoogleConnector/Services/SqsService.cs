﻿using Adzu.GoogleConnector.DTO;
using Amazon.SQS;
using Amazon.SQS.Model;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Services
{
    public class SqsService : ISqsService
    {
        private IAmazonSQS _sqsClient;
        public SqsService(IAmazonSQS sqsClient) => _sqsClient = sqsClient;

        public async Task SendMessage(EventDTO requestDTO, string messageQueueUrl)
        {
            var messageBody = JsonConvert.SerializeObject(requestDTO);

            var sqsMessageRequest = new SendMessageRequest
            {
                QueueUrl = messageQueueUrl,
                MessageBody = messageBody,
                MessageAttributes = new Dictionary<string, MessageAttributeValue>
                {
                    {
                        "MessageType",
                        new MessageAttributeValue {
                            DataType = "String",
                            StringValue = requestDTO.GetType().FullName
                        }
                    },
                    {
                        "QueueUrl",
                        new MessageAttributeValue {
                            DataType = "String",
                            StringValue = messageQueueUrl
                        }
                    }
                }
            };
            
            await _sqsClient.SendMessageAsync(sqsMessageRequest);
        }
    }
}
