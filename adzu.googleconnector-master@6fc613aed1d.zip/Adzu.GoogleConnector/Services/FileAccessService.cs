﻿using Amazon.S3;
using Amazon.S3.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mime;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Services
{
    public class FileAccessService : IFileAccessService
    {
        private string _bucketName => Environment.GetEnvironmentVariable("S3BucketName");
        private IAmazonS3 _S3Client;
        public FileAccessService(IAmazonS3 S3Client) => _S3Client = S3Client;
        
        public async Task CreateFile(Stream data, string path)
        {
            var s3Response = await _S3Client.PutObjectAsync(
                new PutObjectRequest
                {
                    BucketName = _bucketName,
                    Key = path,
                    InputStream = data                    
                });
        }
        public async Task CreateFile(string data, string path)
        {
            var s3Response = await _S3Client.PutObjectAsync(
                new PutObjectRequest
                {
                    BucketName = _bucketName,
                    Key = path,
                    ContentType = MediaTypeNames.Text.Plain,
                    ContentBody = data
                });
        }
        public async Task RemoveObject(string key)
        {
            var s3ResponseDel = await _S3Client.DeleteObjectAsync(_bucketName, key);         
        }
        public async Task<Stream> GetObject(string key)
        {
            var s3ResponseGet = await _S3Client.GetObjectAsync(
                new GetObjectRequest
                {
                    BucketName = _bucketName,
                    Key = key
                });
            return s3ResponseGet.ResponseStream;
        }
        
        public async Task<IList<string>> GetFileNameList(string key)
        {
            var listResponse = await _S3Client.ListObjectsAsync(
                new ListObjectsRequest
                {
                    BucketName = _bucketName,
                    Prefix = key
                });

            var result = listResponse?.S3Objects.Select(x => x.Key).ToList();  
            
            return result;
        }
    }
}
