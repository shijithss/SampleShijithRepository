﻿using Adzu.GoogleConnector.DTO;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Services
{
    public interface IStatusService
    {
        public Task<TrafficPackageStatusDTO> GetStatus(string folderPackageName);
        public Task SetStatus(TrafficPackageStatusDTO status, string folderPackageName);
        public Task SetErrors(ErrorDetails[] errors, string folderPackageName);
        public Task<ErrorDetails[]> GetErrors(string folderPackageName);
    }
}
