﻿using adzu.connectorhub.contracts.Model;
using adzu.connectorhub.sdk;
using Adzu.GoogleConnector.DTO;
using Adzu.GoogleConnector.Helpers;
using FluentValidation;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;
using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Services
{
    public class TrafficPackageService : ITrafficPackageService
    {
        public string QueueDownloadUrl { get; }
        public string QueueNotificationUrl { get; }
        public string QueueProcessUrl { get; }

        public bool IsTestingMode
        {
            get { return _isTestingMode; }
            set
            {
                _isTestingMode = value;
                if (_statusService != null)
                    ((StatusService)_statusService).IsTestingMode = value;
            }
        }
        private bool _isTestingMode = false;

        private ISqsService _sqsService;
        private IFileAccessService _fileAccessService;
        private IHttpRequestService _httpService;
        private IConnectorHubClient _connectorHubClient;
        private IStatusService _statusService;
        private IValidator<RequestTrafficPackageDTO> _requestValidator;
        private IValidator<DownloadPackage> _downloadPackageValidator;
        private IGoogleServiceProvider _googleServiceProvider;

        public TrafficPackageService(ISqsService sqsService,
            IFileAccessService fileAccessService,
            IHttpRequestService httpService,
            IConnectorHubClient connectorHubClient,
            IStatusService statusService,
            IGoogleServiceProvider googleServiceProvider,
            IValidator<RequestTrafficPackageDTO> requestValidator,
            IValidator<DownloadPackage> downloadPackageValidator,
            IOptionsMonitor<QueueUrlsOptions> queueUrlsOptions)
        {
            (_sqsService, _fileAccessService, _httpService, _connectorHubClient, _statusService, _googleServiceProvider, _requestValidator, _downloadPackageValidator)
            = (sqsService, fileAccessService, httpService, connectorHubClient, statusService, googleServiceProvider, requestValidator, downloadPackageValidator);

            QueueDownloadUrl = queueUrlsOptions.CurrentValue.DownloadQueue;
            QueueNotificationUrl = queueUrlsOptions.CurrentValue.NotificationQueue;
            QueueProcessUrl = queueUrlsOptions.CurrentValue.ProcessQueue;
        }

        public async Task NotificationFailTraffic(EventMessage eventMessage)
        {
            var isFailNotificaitionFunction = eventMessage.Type == typeof(TrafficPackageCompletedNotificationDTO).FullName;

            var message = JsonConvert.DeserializeObject<EventDTO>(eventMessage.Body);
            await _statusService.SetStatus(new TrafficPackageStatusDTO
            {
                InternalStatus = PackageStatusEnum.Fail
            }, message.FolderPackageName);

            if (!message.WithoutNotify && !isFailNotificaitionFunction)
            {
                var errors = await _statusService.GetErrors(message.FolderPackageName);
                var internalStatus = await _statusService.GetStatus(message.FolderPackageName);
                using (var activity = StartActivity("Hub.NotifyTrafficPackageStatus"))
                {
                    NotificationRequest request = new NotificationRequest
                    {
                        Notifications = new JObject[] {
                            JObject.FromObject(
                                new {
                                    NotificationType = TrafficPackageConstants.NotificationType,
                                    Status = PackageStatusEnum.Fail.GetDescription(),
                                    Reason = internalStatus.Reason,
                                    Errors = errors
                                },
                                new JsonSerializer()
                                {
                                    ContractResolver = new CamelCasePropertyNamesContractResolver()
                                }
                            )
                        }
                    };
                    await _connectorHubClient.Notifications.Notify(message.RequestToken, request);
                }
            }
        }
        public async Task NotificationTraffic(EventMessage eventMessage)
        {
            var message = JsonConvert.DeserializeObject<TrafficPackageCompletedNotificationDTO>(eventMessage.Body);
            var internalStatus = await _statusService.GetStatus(message.FolderPackageName);
            internalStatus.InternalStatus = internalStatus.InternalStatus == PackageStatusEnum.Processed
                ? PackageStatusEnum.Success
                : PackageStatusEnum.Fail;
            await _statusService.SetStatus(internalStatus, message.FolderPackageName);

            if (!message.WithoutNotify)
            {
                var serializer = new JsonSerializer()
                {
                    ContractResolver = new CamelCasePropertyNamesContractResolver()
                };

                using (var activity = StartActivity("Hub.NotifyTrafficPackageStatus"))
                {
                    NotificationRequest request = new NotificationRequest
                    {
                        Notifications = new JObject[] {
                            JObject.FromObject(new {
                                NotificationType = TrafficPackageConstants.NotificationType,
                                Status = internalStatus.InternalStatus.GetDescription(),
                                Reason = internalStatus.Reason,
                                ExternalId = message.ExternalId,
                                Assets = message.Assets,
                                Errors = message.Errors
                            },serializer)
                        }
                    };
                    await _connectorHubClient.Notifications.Notify(message.RequestToken, request);
                }
            }
        }
        public async Task RequestTraffic(string folderPackageName, RequestTrafficPackageDTO dto)
        {
            _requestValidator.ValidateAndThrow(dto);
            using (var activity = StartActivity("SQS.DownloadEvent"))
            {
                await _sqsService.SendMessage(new DownloadPackage
                {
                    FolderPackageName = folderPackageName,
                    ActionId = dto.ActionId,
                    PackageUrl = dto.Input.PackageUrl,
                    ConnectionReference = dto.Input.ConnectionReference,
                    RequestToken = dto.RequestToken,
                    WithoutNotify = dto.Input.WithoutNotify
                }, QueueDownloadUrl);
            }
        }
        public async Task ProcessPackage(EventMessage eventMessage)
        {
            var message = JsonConvert.DeserializeObject<ProcessPackage>(eventMessage.Body);
            var createAdResult = new TrafficPackageCompletedNotificationDTO();
            using (var activity = StartActivity("S3.UpdateAdStatus")?
                        .AddTag("Status", "Accepted"))
            {
                await _statusService.SetStatus(new TrafficPackageStatusDTO
                {
                    InternalStatus = PackageStatusEnum.Processing
                }, message.FolderPackageName);
            }

            try
            {
                var manifest = await GetPackageManifest(message.ManifestFileLink);
                createAdResult = await _googleServiceProvider.GetGatewayService(message.ConnectionReference)
                   .SendAdToGoogle(manifest, $"{message.FolderPackageName}/", GetPackageZip);

                await _statusService.SetStatus(new TrafficPackageStatusDTO
                {
                    InternalStatus = PackageStatusEnum.Processed
                }, message.FolderPackageName);
            }
            catch (Exception ex)
            {
                throw new CustomException($"ErrorId:{Guid.NewGuid()} Message: {ex.Message}", ex, PackageStatusEnum.ProcessFailed);
            }
            finally
            {
                createAdResult.FolderPackageName = message.FolderPackageName;
                createAdResult.WithoutNotify = message.WithoutNotify;
                createAdResult.ActionId = message.ActionId;
                createAdResult.PackageUrl = message.PackageUrl;
                createAdResult.ConnectionReference = message.ConnectionReference;
                createAdResult.RequestToken = message.RequestToken;
                using (var activity = StartActivity("SQS.NotificationEvent"))
                {
                    await _sqsService.SendMessage(createAdResult, QueueNotificationUrl);
                }
            }
        }
        public async Task DownloadPackage(EventMessage eventMessage)
        {
            PackageUploadResponseDTO uploadResponse = null;
            ErrorDetails[] errors = null;
            var isFailed = false;

            var message = JsonConvert.DeserializeObject<DownloadPackage>(eventMessage.Body);
            await _statusService.SetStatus(new TrafficPackageStatusDTO
            {
                InternalStatus = PackageStatusEnum.Downloading,
            }, message.FolderPackageName);

            try
            {
                _downloadPackageValidator.ValidateAndThrow(message);
                using (var activity = StartActivity("HTTP.DownloadS3Package"))
                {
                    uploadResponse = await UploadAndUnzipPackage(message);
                }
            }
            catch (CustomException ex)
            {
                isFailed = true;
                errors = ex.InnerException.ToErrorDetails("PackageDownloadFunction", message.PackageUrl);
                throw;
            }
            catch (Exception ex)
            {
                isFailed = true;
                errors = ex.ToErrorDetails("PackageDownloadFunction", message.PackageUrl);
                throw new CustomException($"ErrorId:{Guid.NewGuid()} Message: {ex.Message}", ex, PackageStatusEnum.DownloadFailed);
            }
            finally
            {
                using (var activity = StartActivity("SQS.ProcessEvent"))
                {
                    if (isFailed)
                    {
                        await _sqsService.SendMessage(new TrafficPackageCompletedNotificationDTO
                        {
                            FolderPackageName = message.FolderPackageName,
                            WithoutNotify = message.WithoutNotify,
                            ActionId = message.ActionId,
                            PackageUrl = message.PackageUrl,
                            ConnectionReference = message.ConnectionReference,
                            RequestToken = message.RequestToken,
                            Errors = errors
                        }, QueueNotificationUrl);
                    }
                    else
                    {
                        await _sqsService.SendMessage(new ProcessPackage
                        {
                            FolderPackageName = message.FolderPackageName,
                            WithoutNotify = message.WithoutNotify,
                            ActionId = message.ActionId,
                            PackageUrl = message.PackageUrl,
                            ConnectionReference = message.ConnectionReference,
                            RequestToken = message.RequestToken,
                            ManifestFileLink = uploadResponse?.ManifestFileLink
                        }, QueueProcessUrl);
                    }

                    await _statusService.SetStatus(new TrafficPackageStatusDTO
                    {
                        InternalStatus = PackageStatusEnum.Extracted,
                    }, message.FolderPackageName);
                }
            }
        }
        private async Task<PackageUploadResponseDTO> UploadAndUnzipPackage(EventDTO sqsMessage)
        {
            var retval = new PackageUploadResponseDTO();
            using var stream = await _httpService.ReadFile(sqsMessage.PackageUrl);
            await _statusService.SetStatus(new TrafficPackageStatusDTO
            {
                InternalStatus = PackageStatusEnum.Downloaded,
            }, sqsMessage.FolderPackageName);
            try
            {
                using (var activity = StartActivity("UploadPackage.Unzip"))
                {
                    await _statusService.SetStatus(new TrafficPackageStatusDTO
                    {
                        InternalStatus = PackageStatusEnum.Extracting,
                    }, sqsMessage.FolderPackageName);

                    using var archive = new ZipArchive(stream, ZipArchiveMode.Read);
                    foreach (var entry in archive.Entries)
                    {
                        if (entry.Length == 0) continue;
                        var fileLink = $"{sqsMessage.FolderPackageName}/{entry.FullName}";

                        await SaveEntryAsFile(entry.Open(), fileLink);

                        if (entry.FullName.ToLower().Contains("manifest.json"))
                        {
                            retval.ManifestFileLink = fileLink;
                        }
                    }
                }
                return retval;
            }
            catch (Exception ex)
            {
                throw new CustomException($"ErrorId:{Guid.NewGuid()} Message: {ex.Message}", ex, PackageStatusEnum.ExtractionFailed);
            }
        }
        private async Task SaveEntryAsFile(Stream entry, string fileLink)
        {
            using (var memoryStream = new MemoryStream())
            {
                await entry.CopyToAsync(memoryStream);
                memoryStream.Position = 0;
                await _fileAccessService.CreateFile(memoryStream, fileLink);
            }
        }
        private Activity? StartActivity(string name = "", ActivityKind kind = ActivityKind.Internal)
            => IsTestingMode ? null : LambdaEntryPoint.LambdaActivitySource.StartActivity(name, kind);
        private async Task<PackageManifestDTO> GetPackageManifest(string manifestFileLink)
        {
            PackageManifestDTO manifest = new PackageManifestDTO();
            JsonSerializer serializer = new JsonSerializer();
            serializer.ContractResolver = new DefaultContractResolver
            {
                NamingStrategy = new CamelCaseNamingStrategy()
            };
            using (var manifestFileStream = await _fileAccessService.GetObject(manifestFileLink))
            using (StreamReader sr = new StreamReader(manifestFileStream))
            using (JsonReader reader = new JsonTextReader(sr))
                manifest = serializer.Deserialize<PackageManifestDTO>(reader);
            return manifest;
        }
        private async Task<byte[]> GetPackageZip(string packageFileLink)
        {
            using (var packageFileStream = await _fileAccessService.GetObject(packageFileLink))
            {
                var asset = GetAssetZip(packageFileStream);
                if (asset != null)
                {
                    return asset;
                }
            }
            using (var packageFileStream = await _fileAccessService.GetObject(packageFileLink))
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    packageFileStream.CopyTo(ms);
                    return ms.ToArray();
                }
            }
        }
        private byte[] GetAssetZip(Stream zipStream)
        {
            using (var archive = new ZipArchive(zipStream, ZipArchiveMode.Read))
            {
                var inneManifestFile = archive.GetEntry("manifest.json");
                var assetFileName = GetAssetName(inneManifestFile);
                if (!string.IsNullOrEmpty(assetFileName))
                {
                    var assetFileEntry = archive.GetEntry(assetFileName);
                    using (var ms = new MemoryStream())
                    {
                        assetFileEntry.Open().CopyTo(ms);
                        return ms.ToArray();
                    }
                }
            }
            return null;
        }
        private string GetAssetName(ZipArchiveEntry innerManifestEntity)
        {
            if (innerManifestEntity != null)
            {
                JsonSerializer serializer = new JsonSerializer
                {
                    ContractResolver = new DefaultContractResolver
                    {
                        NamingStrategy = new CamelCaseNamingStrategy()
                    }
                };
                using (var innerManifestFileStream = innerManifestEntity.Open())
                using (StreamReader sr = new StreamReader(innerManifestFileStream))
                using (var reader = new JsonTextReader(sr))
                {
                    var innerManifest = serializer.Deserialize<InnerManifestDTO>(reader);
                    var zipFile = innerManifest.Files.First(f => f.Type.ToLower() == "zipfile");
                    return zipFile?.Path ?? string.Empty;
                }
            }
            return string.Empty;
        }
    }
}
