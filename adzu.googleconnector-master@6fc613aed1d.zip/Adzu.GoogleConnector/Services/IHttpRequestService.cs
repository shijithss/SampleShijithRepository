﻿using System.IO;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Services
{
    public interface IHttpRequestService
    {
        public Task<Stream> ReadFile(string fileUrl);
        public Task PostRequest(string callbackUrl, string body);
    }
}
