﻿using Adzu.GoogleConnector.DTO;
using Amazon.Lambda.Core;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Services
{
    public interface ITrafficPackageService
    {
        public Task RequestTraffic(string folderPackageName, RequestTrafficPackageDTO dto);
        public Task DownloadPackage(EventMessage eventMessage);
        public Task ProcessPackage(EventMessage eventMessage);
        public Task NotificationTraffic(EventMessage eventMessage);
        public Task NotificationFailTraffic(EventMessage eventMessage);
    }
}
