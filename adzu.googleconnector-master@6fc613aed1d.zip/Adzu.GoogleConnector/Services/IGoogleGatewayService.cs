﻿using Adzu.GoogleConnector.DTO;
using Google.Ads.GoogleAds.Lib;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Services
{
    public interface IGoogleGatewayService
    {
        IGoogleGatewayService SetParameters(string accessToken);
        Task<TrafficPackageCompletedNotificationDTO> SendAdToGoogle(PackageManifestDTO packageManifest, string prefixDownloadPackageUrl, Func<string, Task<byte[]>> downloadCallback);
        List<CustomerAccountDTO> GetRootAccessibleCustomers();
        List<CustomerAccountDTO> GetNodeAccessibleCustomers(string loginCustomerId, string customerId);
    }
}
