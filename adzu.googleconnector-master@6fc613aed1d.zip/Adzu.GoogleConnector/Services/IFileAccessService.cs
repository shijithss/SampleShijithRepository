﻿using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Services
{
    public interface IFileAccessService
    {
        public Task CreateFile(Stream data, string path);
        public Task CreateFile(string data, string path);
        public Task RemoveObject(string key);
        public Task<Stream> GetObject(string key);
        public Task<IList<string>> GetFileNameList(string key);
    }
}
