﻿using Adzu.GoogleConnector.DTO;
using Amazon.Lambda.Core;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Services
{
    public interface IMessageHandler
    {
        public Task HandleMessage(EventMessage eventMessage, ILambdaContext lambdaContext);
    }
}
