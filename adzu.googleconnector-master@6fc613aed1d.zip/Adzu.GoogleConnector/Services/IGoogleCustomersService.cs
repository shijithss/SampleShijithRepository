﻿using Adzu.GoogleConnector.DTO;
using System.Collections.Generic;

namespace Adzu.GoogleConnector.Services
{
    public interface IGoogleCustomersService
    {
        public IList<CustomerAccountDTO> GetAccessibleCustomers(GetAccountsRequest dto);
    }
}
