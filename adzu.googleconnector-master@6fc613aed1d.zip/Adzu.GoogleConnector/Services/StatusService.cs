﻿using Adzu.GoogleConnector.DTO;
using Adzu.GoogleConnector.Functions;
using Adzu.GoogleConnector.Helpers;
using FluentValidation;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Services
{
    public class StatusService : IStatusService
    {
        public bool IsTestingMode = false;
        private IFileAccessService _fileAccessService;
        private string FileNameForErrors = "Errors";
        private IValidator<TrafficPackageStatusDTO> _validator;
        private ILogger<StatusService> _logger;
        public StatusService(IFileAccessService fileAccessService, IValidator<TrafficPackageStatusDTO> validator, ILogger<StatusService> logger)
            => (_fileAccessService, _validator, _logger) = (fileAccessService, validator, logger);
        public async Task SetStatus(TrafficPackageStatusDTO statusDTO, string folderPackageName)
        {
            using var activity = StartActivity($"Action:{TrafficPackageConstants.ActionName} set Status:{statusDTO.InternalStatus.GetDescription()}");
            _validator.ValidateAndThrow(statusDTO);
            var folderName = string.IsNullOrEmpty(folderPackageName) ? "FolderWithErrorStatuses" : folderPackageName;

            var files = await _fileAccessService.GetFileNameList($"{folderName}/{TrafficPackageConstants.ActionName}");
            var statusDTOs = new List<TrafficPackageStatusDTO>();
            if (files.Any())
            {
                using (var reader = new StreamReader(await _fileAccessService.GetObject($"{folderName}/{TrafficPackageConstants.ActionName}")))
                {
                    string result = await reader.ReadToEndAsync();
                    statusDTOs = JsonConvert.DeserializeObject<List<TrafficPackageStatusDTO>>(result);
                }
            }
            statusDTOs.Add(statusDTO);
            var data = JsonConvert.SerializeObject(statusDTOs);
            await _fileAccessService.CreateFile(data, $"{folderName}/{TrafficPackageConstants.ActionName}");
        }
        public async Task<TrafficPackageStatusDTO> GetStatus(string folderPackageName)
        {
            using var activity = StartActivity($"Action:{TrafficPackageConstants.ActionName} get status")?
                                .AddTag("Status", "Getting");

            var fileNameList = await _fileAccessService.GetFileNameList(folderPackageName);
            var fileName = string.Empty;

            _logger.LogInformation($"Status files read for: {TrafficPackageConstants.ActionName}. Files: {string.Join(',', fileNameList)}");

            if (fileNameList.Contains($"{folderPackageName}/{typeof(SqsHandlerFunction).Name}"))
            {
                fileName = typeof(SqsHandlerFunction).Name;
            }
            else if (fileNameList.Contains($"{folderPackageName}/{typeof(TrafficPackageFunction).Name}"))
            {
                fileName = typeof(TrafficPackageFunction).Name;
            }

            _logger.LogInformation($"Status service the last file {fileName} with status");

            if (string.IsNullOrEmpty(fileName))
            {
                return new TrafficPackageStatusDTO
                {
                    InternalStatus = PackageStatusEnum.Unknown
                };
            }
            List<TrafficPackageStatusDTO> statusDTOs;
            using (var reader = new StreamReader(await _fileAccessService.GetObject($"{folderPackageName}/{fileName}")))
            {
                var result = await reader.ReadToEndAsync();
                statusDTOs = JsonConvert.DeserializeObject<List<TrafficPackageStatusDTO>>(result);
            }
            activity?.AddTag("Status", $"Got {statusDTOs.Last().InternalStatus.GetDescription()}");
            return statusDTOs.Last();
        }
        private Activity? StartActivity(string name = "", ActivityKind kind = ActivityKind.Internal)
            => IsTestingMode ? null : LambdaEntryPoint.LambdaActivitySource.StartActivity(name, kind);

        public async Task SetErrors(ErrorDetails[] newErrors, string folderPackageName)
        {
            var folderName = string.IsNullOrEmpty(folderPackageName) ? "FolderWithErrorStatuses" : folderPackageName;

            var files = await _fileAccessService.GetFileNameList($"{folderName}/{FileNameForErrors}");
            var errors = new List<ErrorDetails>();
            if (files.Any())
            {
                using (var reader = new StreamReader(await _fileAccessService.GetObject($"{folderName}/{FileNameForErrors}")))
                {
                    string result = await reader.ReadToEndAsync();
                    errors = JsonConvert.DeserializeObject<List<ErrorDetails>>(result);
                }
            }
            errors.AddRange(newErrors);
            var data = JsonConvert.SerializeObject(errors);
            await _fileAccessService.CreateFile(data, $"{folderName}/{FileNameForErrors}");
        }

        public async Task<ErrorDetails[]> GetErrors(string folderPackageName)
        {
            using (var reader = new StreamReader(await _fileAccessService.GetObject($"{folderPackageName}/{FileNameForErrors}")))
            {
                var result = await reader.ReadToEndAsync();
                var errors = JsonConvert.DeserializeObject<ErrorDetails[]>(result);
                return errors;
            }
        }
    }
}
