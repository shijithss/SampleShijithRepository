﻿using Adzu.GoogleConnector.Helpers;
using Adzu.GoogleConnector.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.TrafficApi
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class InernalDataController : ControllerBase
    {
        private IStatusService _statusService;
        private ILogger<InernalDataController> _logger;
        public InernalDataController(IStatusService statusService, ILogger<InernalDataController> logger)
        {
            TrafficPackageConstants.ActionName = GetType().Name;
            _statusService = statusService;
            _logger = logger;
        }

        [AllowAnonymous]
        [HttpGet("GetTrafficInternalStatus")]
        public async Task<IActionResult> GetStatus(string folderName)
        {
            var status = await _statusService.GetStatus(folderName);
            return Ok(status);
        }
        [AllowAnonymous]
        [HttpPost("mockTenantCallback")]
        public IActionResult MockTenantCallback(dynamic dto)
        {
            _logger.LogInformation($"MockRequestCallback Request DTO: {dto}");
            return Ok("success");
        }
    }
}
