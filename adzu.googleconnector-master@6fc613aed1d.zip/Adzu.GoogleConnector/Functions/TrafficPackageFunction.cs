﻿using Adzu.GoogleConnector.DTO;
using Adzu.GoogleConnector.Helpers;
using Adzu.GoogleConnector.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Functions
{
    [Authorize]
    [ApiController]
    [Route("api")]
    public class TrafficPackageFunction : ControllerBase
    {
        private ITrafficPackageService _trafficPackageService;
        private IStatusService _statusService;
        private ILogger<TrafficPackageFunction> _logger;
        public TrafficPackageFunction(
            IStatusService statusService,
            ITrafficPackageService trafficPckageService,
            ILogger<TrafficPackageFunction> logger)
        {
            _trafficPackageService = trafficPckageService;
            _statusService = statusService;
            _logger = logger;
            TrafficPackageConstants.ActionName = GetType().Name;
        }

        [HttpPost("traffic-package")]
        public async Task<IActionResult> TrafficPackage(RequestTrafficPackageDTO dto)
        {
            var folderPackageName = string.Empty;
            try
            {
                folderPackageName = dto.RequestToken.ToSHA256String();
                using var activity = LambdaEntryPoint.LambdaActivitySource.StartActivity("TrafficPackageFunction.TrafficPackage.HttpPost")
                                 .AddTag("ActionId", dto.ActionId)
                                 .AddTag("TracingId", folderPackageName);

                await _trafficPackageService.RequestTraffic(folderPackageName, dto);

                await _statusService.SetStatus(new TrafficPackageStatusDTO
                {
                    InternalStatus = PackageStatusEnum.Created
                }, folderPackageName);
               
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Error while traffic-package api call:");
                await _statusService.SetStatus(new TrafficPackageStatusDTO
                {
                    InternalStatus = PackageStatusEnum.Fail,
                    Message = e.Message,
                    Reason = e.GetType().Name
                }, folderPackageName);
                
            }
            
            return Accepted();
        }
    }
}
