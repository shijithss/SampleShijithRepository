﻿using Adzu.GoogleConnector.Helpers;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace Adzu.GoogleConnector.Functions
{
    public class BaseLambdaFunction
    {
        protected IServiceProvider ServiceProvider { get; set; }
        public BaseLambdaFunction()
        {
            var serviceCollection = new ServiceCollection();
            new Startup().ConfigureServices(serviceCollection);
            ServiceProvider = serviceCollection.BuildServiceProvider();
            TrafficPackageConstants.ActionName = GetType().Name;
        }
    }
}
