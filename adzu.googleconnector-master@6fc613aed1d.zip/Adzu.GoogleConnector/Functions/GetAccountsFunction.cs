﻿using Adzu.GoogleConnector.DTO;
using Adzu.GoogleConnector.Helpers;
using Adzu.GoogleConnector.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;

namespace Adzu.GoogleConnector.Functions
{
    [Authorize]
    [ApiController]
    [Route("api")]
    public class GetAccountsFunction : ControllerBase
    {
        private IGoogleCustomersService _getAccountsService;
        private ILogger<GoogleGatewayService> _logger;
        public GetAccountsFunction(IGoogleCustomersService getAccountsService, ILogger<GoogleGatewayService> logger)
            => (_getAccountsService, _logger) = (getAccountsService, logger);

        [HttpPost("get-accounts")]
        public IActionResult GetAccounts(GetAccountsRequest request)
        {
            try
            {
                using var activity = LambdaEntryPoint.LambdaActivitySource.StartActivity("GetAccountsFunction.GetAccounts.HttpPost")
                                 .AddTag("ActionId", request.ActionId)
                                 .AddTag("CustomerId", request.Input.CustomerId)
                                 .AddTag("LoginCustomerId", request.Input.LoginCustomerId);

                var customers = _getAccountsService.GetAccessibleCustomers(request);

                var accounts = JsonConvert.SerializeObject(
                    new { accounts = customers },
                    new JsonSerializerSettings
                    {
                        ContractResolver = new CamelCasePropertyNamesContractResolver()
                    }
                    );
                _logger.LogInformation($"Accounts: {accounts}");
                return Ok(accounts);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Exception: {e.Message} trace {e.StackTrace}");
                return BadRequest(new
                {
                    Errors = e.ToErrorDetails("GetAccountsRequest"),
                    Status = PackageStatusEnum.Fail
                });
            }
        }
    }
}
