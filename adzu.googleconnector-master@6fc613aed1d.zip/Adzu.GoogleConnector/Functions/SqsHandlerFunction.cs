﻿using Adzu.GoogleConnector.DTO;
using Adzu.GoogleConnector.Helpers;
using Adzu.GoogleConnector.Services;
using Amazon.Lambda.Core;
using Amazon.Lambda.SQSEvents;
using Amazon.SQS;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using OpenTelemetry.Contrib.Instrumentation.AWSLambda.Implementation;
using System;
using System.Threading.Tasks;
using System.Diagnostics;
using OpenTelemetry.Trace;

namespace Adzu.GoogleConnector.Functions
{
    public class SqsHandlerFunction : BaseLambdaFunction
    {
        private ILogger<SqsHandlerFunction> _logger;
        private ITrafficPackageService _trafficPackageService;
        private IStatusService _statusService;
        public bool IsTestingMode { get; set; }

        public SqsHandlerFunction(IServiceProvider serviceProvider)
        {
            ServiceProvider = serviceProvider;
            ResolveServices();
            IsTestingMode = true;
            ((TrafficPackageService)_trafficPackageService).IsTestingMode = true;
        }
        public SqsHandlerFunction()
        {
            ResolveServices();
        }
        [LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]
        public async Task HandleEventAsync(SQSEvent @event, ILambdaContext lambdaContext)
        {
            using var activity = StartActivity("SqsHandler.HandleEvent");
            var isFailed = false;
            var folderPackageName = string.Empty;
            var eventType = string.Empty;
            IAmazonSQS sqsClient = ServiceProvider.GetService<IAmazonSQS>();
            foreach (var message in @event.Records)
            {
                try
                {
                    // Try to extract parent trace id from message attributes if it is populated by message sender
                    if (message.Attributes.TryGetValue("AWSTraceHeader", out string parentTraceId))
                    {
                        // Important: please note that approach with replacing environment variable value
                        // won't work when you need to process several messages in parallel

                        // Put found parent trace Id into specific environment variable
                        // It will be read by AWSLambdaWrapper.Trace method when creating Root activity to use as its parent context
                        Environment.SetEnvironmentVariable("_X_AMZN_TRACE_ID", parentTraceId);
                    }
                    _logger.LogInformation($"Event: {JsonConvert.SerializeObject(message)}");
                    var eventDTO = JsonConvert.DeserializeObject<EventDTO>(message.Body);
                    folderPackageName = eventDTO.FolderPackageName;
                    eventType = message.MessageAttributes["MessageType"].StringValue;
                    var lambdaHandler = await ResolveLambdaHandler(eventType, folderPackageName);
                    await Trace(lambdaHandler, new EventMessage
                    {
                        Body = message.Body,
                        Type = eventType
                    });

                    var queueName = message.MessageAttributes["QueueUrl"].StringValue;
                    await sqsClient.DeleteMessageAsync(queueName, message.ReceiptHandle);
                }
                catch (Exception e)
                {
                    _logger.LogError(e, $"SqsService.HandleMessages raised exception");

                    var errors = e.ToErrorDetails(eventType, folderPackageName);
                    await _statusService.SetErrors(errors, folderPackageName);

                    activity?.SetTag("otel.status_code", "ERROR");
                    activity?.SetTag("otel.status_description", e.Message);
                    isFailed = true;
                }
            }
            if (isFailed) throw new Exception("Failed to process one or more messages");
        }
        [LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]
        public async Task HandleDLQEventAsync(SQSEvent @event, ILambdaContext lambdaContext)
        {
            using var activity = StartActivity("SqsHandler.HandleDLQEvent");
            foreach (var message in @event.Records)
            {
                try
                {
                    if (message.Attributes.TryGetValue("AWSTraceHeader", out string parentTraceId))
                    {
                        Environment.SetEnvironmentVariable("_X_AMZN_TRACE_ID", parentTraceId);
                    }
                    _logger.LogInformation($"DLQEvent: {JsonConvert.SerializeObject(message)}");

                    await Trace(_trafficPackageService.NotificationFailTraffic, new EventMessage
                    {
                        Body = message.Body,
                        Type = message.MessageAttributes["MessageType"].StringValue
                    });
                }
                catch (Exception e)
                {
                    _logger.LogError(e, $"DLQSqsService.HandleMessages raised exception");
                    activity?.SetTag("otel.status_code", "ERROR");
                    activity?.SetTag("otel.status_description", e.Message);
                }
            }
        }
        private async Task<Func<EventMessage, Task>> ResolveLambdaHandler(string eventType, string folderPackageName)
        {
            if (eventType == typeof(TrafficPackageCompletedNotificationDTO).FullName)
            {
                return _trafficPackageService.NotificationTraffic;
            }
            if (eventType == typeof(ProcessPackage).FullName)
            {
                return _trafficPackageService.ProcessPackage;
            }
            if (eventType == typeof(DownloadPackage).FullName)
            {
                return _trafficPackageService.DownloadPackage;
            }

            var errors = new CustomException("UnknownEventType", null, PackageStatusEnum.Fail)
                .ToErrorDetails(eventType, folderPackageName);
            await _statusService.SetErrors(errors, folderPackageName);
            return _trafficPackageService.NotificationFailTraffic;
        }
        private void ResolveServices()
        {
            _trafficPackageService = ServiceProvider.GetService<ITrafficPackageService>();
            _logger = ServiceProvider.GetService<ILogger<SqsHandlerFunction>>();
            _statusService = ServiceProvider.GetService<IStatusService>();
        }
        private Activity? StartActivity(string name = "", ActivityKind kind = ActivityKind.Internal)
            => IsTestingMode ? null : LambdaEntryPoint.LambdaActivitySource.StartActivity(name, kind);
        private Task Trace(Func<EventMessage, Task> lambdaHandler, EventMessage eventMessage)
            => IsTestingMode ? lambdaHandler(eventMessage) : AWSLambdaWrapper.Trace(LambdaEntryPoint._tracerProvider, lambdaHandler, eventMessage);
    }
}
