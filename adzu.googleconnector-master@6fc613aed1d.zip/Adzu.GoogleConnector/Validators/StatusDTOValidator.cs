﻿using Adzu.GoogleConnector.DTO;
using FluentValidation;
using System;

namespace Adzu.GoogleConnector.Validators
{
    public class StatusDTOValidator :  AbstractValidator<TrafficPackageStatusDTO>
    {
        public StatusDTOValidator()
        {
            RuleFor(x => x.InternalStatus).NotEmpty();
        }
    }
}
