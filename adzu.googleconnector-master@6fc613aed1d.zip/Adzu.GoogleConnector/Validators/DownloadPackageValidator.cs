﻿using Adzu.GoogleConnector.DTO;
using Adzu.GoogleConnector.Helpers;
using FluentValidation;
using System;

namespace Adzu.GoogleConnector.Validators
{
    public class DownloadPackageValidator : AbstractValidator<DownloadPackage>
    {
        public DownloadPackageValidator()
        {           
            RuleFor(x => x.PackageUrl).Must(url => 
            {
                return Uri.TryCreate(url, UriKind.Absolute, out Uri uriResul)
                        && (uriResul.Scheme == Uri.UriSchemeHttp || uriResul.Scheme == Uri.UriSchemeHttps);
            })
                .WithErrorCode(ErrorCodes.InvalidDownloadURL)
                .WithMessage(mess => "Invalid Download URL. Package URL {0}");
                

        }
    }
}
