﻿using Adzu.GoogleConnector.DTO;
using FluentValidation;

namespace Adzu.GoogleConnector.Validators
{
    public class PackageRequestDTOValidator : AbstractValidator<RequestTrafficPackageDTO>
    {
        public PackageRequestDTOValidator()
        {
            RuleFor(x => x.ActionId).NotEmpty();
            RuleFor(x => x.Input)
                .Cascade(CascadeMode.Stop)
                .NotNull();            
                
        }
    }
}
