﻿using System;

namespace Adzu.GoogleConnector.Helpers
{
    public class CustomException : Exception
    {
        public CustomException(string? message, Exception? innerException, PackageStatusEnum failInternalStatus)
            : base(message, innerException)
        {
            FailInternalStatus = failInternalStatus;
        }
        public PackageStatusEnum FailInternalStatus { get; }
    }
}
