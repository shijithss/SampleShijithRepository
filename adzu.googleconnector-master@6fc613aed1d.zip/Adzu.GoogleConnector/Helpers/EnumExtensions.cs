﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Reflection;

namespace Adzu.GoogleConnector.Helpers
{
    public static class EnumExtensions
    {
        public static string GetDescription(this Enum value)
        {
            FieldInfo fi = value.GetType().GetField(value.ToString());
            DescriptionAttribute attr = (DescriptionAttribute)fi
                .GetCustomAttributes(typeof(DescriptionAttribute), false)
                .FirstOrDefault();

            return attr?.Description ?? string.Empty;
        }
    }
}
