﻿namespace Adzu.GoogleConnector.Helpers
{
    public static class HttpStatus
    {
        public static string Success = "Success";
    }
    public static class TrafficPackageConstants
    {
        public static string ActionName;
        public static string NotificationType => "TrafficPackageCompleted";
    }
    public static class ErrorCodes
    {
        public static string CorruptedFile => "CorruptedFile";
        public static string InvalidDownloadURL => "InvalidDownloadURL";
        public static string UnhandledError => "UnhandledError";

    }
}
