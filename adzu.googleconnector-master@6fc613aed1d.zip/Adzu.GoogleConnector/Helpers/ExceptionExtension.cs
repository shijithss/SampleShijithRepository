﻿using Adzu.GoogleConnector.DTO;
using System;
using System.Collections.Generic;
using System.IO;
using FluentValidation;
using System.Linq;
using System.Net.Http;

namespace Adzu.GoogleConnector.Helpers
{
    public static class ExceptionExtension
    {

        private static IDictionary<string, Func<Exception, string[], ErrorDetails[]>> ErrorsToActionMap; 

        static ExceptionExtension()
        {
            RegisterErrorsToActionMap();
        }        

        public static ErrorDetails[]  ToErrorDetails(this Exception exception, string exceptionSource, params string[] args)
        {
            Func<Exception, string[], ErrorDetails[]> handlerFunc;
            var registeredErrorKey = $"{exception.GetType().Name}_{exceptionSource}";
            ErrorsToActionMap.TryGetValue(registeredErrorKey, out handlerFunc );

            var result = handlerFunc?.Invoke(exception, args) ?? HandleDefaultError(exception, args);           

            return result;
        }

        private static ErrorDetails[] HandleCorruptedFileError(Exception exception, string[] args)
        {
            var code = ErrorCodes.CorruptedFile;
            var message = "The file is corrupted. File {0}";
            var details = $"Exception: {exception.Message} Trace: {exception.StackTrace}";
            var res = GetErrorDetails(code, message, details, args);

            return res;
        }

        private static ErrorDetails[] HandleValidationError(Exception exception, string[] args)
        {
            var validationException = exception as ValidationException;
            return  validationException.Errors.Select(validationError =>
            {
                return new ErrorDetails
                {
                    Code = validationError.ErrorCode,
                    Message = validationError.ErrorMessage,
                    Details = $"Exception: {exception.Message} Trace: {exception.StackTrace}",
                    Params = args
                };
            }).ToArray();
           
        }

        private static ErrorDetails[] HandleInvalidDownloadURLError(Exception exception, string[] args)
        {
            var code = ErrorCodes.InvalidDownloadURL;
            var message = "Invalid Download URL. Package URL {0}";
            var details = $"Exception: {exception.Message} Trace: {exception.StackTrace}";
            var res = GetErrorDetails(code, message, details, args);

            return res;
        }


        private static ErrorDetails[] HandleDefaultError(Exception exception, string[] args)
        {
            var code = ErrorCodes.UnhandledError;
            var message = exception.Message;
            var details = exception.StackTrace;
            var res = GetErrorDetails(code, message, details, args);

            return res;
        }

        private static ErrorDetails[] GetErrorDetails(string code, string message, string details, string[] args)
        {
           return new ErrorDetails[]
                {
                    new ErrorDetails
                    {
                        Code = code,
                        Message = message,
                        Params = args,
                        Details = details
                    }
                };           
        }

        private static void RegisterErrorsToActionMap()
        {
            ErrorsToActionMap =
            new Dictionary<string, Func<Exception, string[], ErrorDetails[]>>
            {
                { ExceptionTypeToKey<InvalidDataException>("PackageDownloadFunction"), HandleCorruptedFileError },
                { ExceptionTypeToKey<ArgumentNullException>("PackageDownloadFunction"), HandleCorruptedFileError },
                { ExceptionTypeToKey<ValidationException>("PackageDownloadFunction"), HandleValidationError },
                { ExceptionTypeToKey<HttpRequestException>("PackageDownloadFunction"), HandleInvalidDownloadURLError }                
            };
        }
        
        private static string ExceptionTypeToKey<T>(string exceptionSource)
        {
            return $"{typeof(T).Name}_{exceptionSource}";
        }
    }
}
