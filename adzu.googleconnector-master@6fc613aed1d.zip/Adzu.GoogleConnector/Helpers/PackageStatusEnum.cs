﻿using System.ComponentModel;

namespace Adzu.GoogleConnector.Helpers
{
    public enum PackageStatusEnum
    {
        Unknown,

        [Description("Request Created")]
        Created,

        [Description("Package Downloading")]
        Downloading,
        [Description("Package Download Failed")]
        DownloadFailed,
        [Description("Package Downloaded")]
        Downloaded,

        [Description("Package Extracting")]
        Extracting,
        [Description("Package Extraction Failed")]
        ExtractionFailed,
        [Description("Package Extracted")]
        Extracted,

        [Description("Package Processing")]
        Processing,
        [Description("Package Process Failed")]
        ProcessFailed,
        [Description("Package Processed")]
        Processed,

        [Description("Fail")]
        Fail,
        [Description("Success")]
        Success
    }
}
