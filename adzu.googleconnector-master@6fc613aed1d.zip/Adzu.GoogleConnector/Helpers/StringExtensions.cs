﻿using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace Adzu.GoogleConnector.Helpers
{
    public static class StringExtensions
    {
        public static string ToSHA256String(this string source)
        {
            string salt = "6F67F463A8440EEBE09289E673E8134";

            SHA256 sha256 = SHA256Managed.Create();
            byte[] bytes = Encoding.UTF8.GetBytes(source + salt);
            byte[] hash = sha256.ComputeHash(bytes);

            StringBuilder result = new StringBuilder();
            hash.ToList().ForEach(i => result.Append(i.ToString("X2")));

            return result.ToString();
        }
    }
}
