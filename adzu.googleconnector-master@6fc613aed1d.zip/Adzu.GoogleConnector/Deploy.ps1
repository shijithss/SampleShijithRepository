function runServerless($stage, $accessKey, $secretKey){
	Write-Host "Before runServerless deploy"

	serverless config credentials --provider aws --key $accessKey --secret $secretKey --profile $stage --overwrite
    $serverlessOutput = & serverless deploy -v --aws-profile $stage --stage $stage | Out-String

	Write-Host "ServerlessOutput: $serverlessOutput"

	return "OK"
}

function getOctoParam($octoParamName, $outputText) {
	$octopusParameterValue = $OctopusParameters[$octoParamName]
	Write-Host $outputText": "$octopusParameterValue

	return $octopusParameterValue
}


$stage = getOctoParam -octoParamName "AWSStage" -outputText "ReleaseStage" 
$accessKey = getOctoParam -octoParamName "AWSCreds.AccessKey" -outputText "AWSCreds.AccessKey"
$secretKey = getOctoParam -octoParamName "AWSCreds.SecretKey" -outputText "AWSCreds.SecretKey"

Write-Output "serverless.yml variables: "
$awsRegion = getOctoParam -octoParamName "AWSRegion" -outputText "AWS Region"
$platformManagerUrl =  getOctoParam -octoParamName "PTMBaseUrl" -outputText "Platform Manager Base URL"
$connectionManagerUrl =  getOctoParam -octoParamName "CNMBaseUrl" -outputText "Connection Manager Base URL"
$connectorHubBaseUrl = getOctoParam -octoParamName "CHBBaseUrl" -outputText "Connector Hub Base URL" 
$clientId = getOctoParam -octoParamName "PTMClientId" -outputText "PTM Client Id"
$clientSecret =  getOctoParam -octoParamName "PTMClientSecret" -outputText "PTM Client Secret"
$scope =  getOctoParam -octoParamName "PTMScope" -outputText "PTM Scope"
$DeveloperToken =  getOctoParam -octoParamName "GoogleConfigDeveloperToken" -outputText "Google DeveloperToken"

if (-NOT $awsRegion) { throw 'Region is empty' }
if (-NOT $stage) { throw 'Stage is empty' }
if (-NOT $accessKey) { throw 'AWSCreds.AccessKey is empty' }
if (-NOT $secretKey) { throw 'AWSCreds.SecretKey is empty' }
if (-NOT $platformManagerUrl) { throw 'Platform Manager URL is empty' }
if (-NOT $connectionManagerUrl) { throw 'Connection Manager URL is empty' }
if (-NOT $connectorHubBaseUrl) { throw 'Connector Hub Base UR is empty' }
if (-NOT $clientId) { throw 'Client Id is empty' }
if (-NOT $clientSecret) { throw 'Client Secret is empty' }
if (-NOT $scope) { throw 'Scope is empty' }


runServerless -stage $stage -accessKey $accessKey -secretKey $secretKey