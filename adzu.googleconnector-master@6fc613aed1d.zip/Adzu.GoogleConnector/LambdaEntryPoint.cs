using System;
using System.Diagnostics;
using System.Threading.Tasks;
using Amazon.Lambda.APIGatewayEvents;
using Amazon.Lambda.AspNetCoreServer;
using Amazon.Lambda.Core;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using OpenTelemetry.Contrib.Extensions.AWSXRay.Trace;
using OpenTelemetry.Contrib.Instrumentation.AWSLambda.Implementation;
using OpenTelemetry.Trace;

namespace Adzu.GoogleConnector
{
    public class LambdaEntryPoint : APIGatewayProxyFunction
    {
        public static readonly TracerProvider _tracerProvider;
        private const string _activitySource = "Adzu.GoogleConnector";

        public static readonly ActivitySource LambdaActivitySource = new ActivitySource(_activitySource);
        static LambdaEntryPoint()
        {
            AppContext.SetSwitch("System.Net.Http.SocketsHttpHandler.Http2UnencryptedSupport", true);

            _tracerProvider = global::OpenTelemetry.Sdk.CreateTracerProviderBuilder()
                .AddSource(_activitySource)
                .AddAspNetCoreInstrumentation() // optional - to instrument Asp.Net Core application
                .AddHttpClientInstrumentation() // optional - to instrument Http requests
                .AddAWSInstrumentation()        // optional - to instrument AWS SDK requests
                .AddXRayTraceId()               // required - to include X-Ray trace id into requests 
                .AddOtlpExporter()              // required - to send telemetry to collector
                .AddAWSLambdaConfigurations()   // required for Lambda
//#if DEBUG
//                .AddConsoleExporter()           // optional - to send trace messages to console, use only for debug purposes
//#endif                
                .Build();

            global::OpenTelemetry.Sdk.SetDefaultTextMapPropagator(new AWSXRayPropagator());
        }
        public override Task<APIGatewayProxyResponse> FunctionHandlerAsync(APIGatewayProxyRequest request, ILambdaContext lambdaContext) 
            => AWSLambdaWrapper.Trace(_tracerProvider, base.FunctionHandlerAsync, request, lambdaContext);

        protected override void Init(IWebHostBuilder builder)
        {
            builder.UseStartup<Startup>();
        }
        protected override void Init(IHostBuilder builder)
        {
        }
    }
}
