using adzu.connectorhub.sdk;
using Adzu.ConnectionManager.SDK;
using Adzu.GoogleConnector.DTO;
using Adzu.GoogleConnector.Helpers;
using Adzu.GoogleConnector.Services;
using Adzu.GoogleConnector.Services.Configuration;
using Adzu.GoogleConnector.Services.GoogleInheritors;
using Adzu.GoogleConnector.Validators;
using Adzu.Sdk;
using Adzu.Sdk.IdentityServer;
using Adzu.Sdk.Security;
using Amazon.S3;
using Amazon.SQS;
using FluentValidation;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.IO;

namespace Adzu.GoogleConnector
{
    public class Startup
    {
        public Startup()
        {
            var builder = new ConfigurationBuilder()
                            .SetBasePath(Directory.GetCurrentDirectory())
                            .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                            .AddEnvironmentVariables();

            Configuration = builder.Build();
        }
        public Startup(IConfiguration configuration):this(){}
        public static IConfiguration Configuration { get;  set; }
        // This method gets called by the runtime. Use this method to add services to the container
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddLogging(x =>
                x.AddLambdaLogger(new LambdaLoggerOptions
                {
                    IncludeCategory = true,
                    IncludeLogLevel = true,
                    IncludeNewline = true,
                    IncludeEventId = true,
                    IncludeException = true,
                    IncludeScopes = true
                }))
                .Configure<LoggerFilterOptions>(options => options.MinLevel = LogLevel.Information);

            services.Configure<QueueUrlsOptions>(Configuration.GetSection("QueueUrlsOptions"));
            services.Configure<GoogleConfigDTO>(Configuration.GetSection("GoogleConfig"));

            services.Configure<InfrastructureConfig>(Configuration.GetSection("InfrastructureConfig"));

            services.AddTransient<ISqsService, SqsService>();
            services.AddTransient<IGoogleServiceProvider, GoogleServiceProvider>();            
            services.AddTransient<IGoogleCustomersService, GoogleCustomersService>();            
            services.AddTransient<IFileAccessService, FileAccessService>();
            services.AddTransient<IHttpRequestService, HttpRequestService>();
            services.AddTransient<ITrafficPackageService, TrafficPackageService>();
            services.AddTransient<IAmazonS3, AmazonS3Client>();
            services.AddTransient<IAmazonSQS, AmazonSQSClient>();
            services.AddTransient<IStatusService, StatusService>();
            services.AddTransient<IGoogleAdsClient, CustomGoogleAdsClient>();
            services.AddTransient<IGoogleGatewayService, GoogleGatewayService>();
            services.AddTransient<IValidator<RequestTrafficPackageDTO>, PackageRequestDTOValidator>();
            services.AddTransient<IValidator<TrafficPackageStatusDTO>, StatusDTOValidator>();
            services.AddTransient<IValidator<DownloadPackage>, DownloadPackageValidator>();

            services.AddSingleton<IConnectionManagerClient>(serviceProvider => {
                var config = serviceProvider.GetService<IOptionsMonitor<InfrastructureConfig>>().CurrentValue;

                var sdkClientOptions = new SdkClientOptionsBuilder()
                   .WithCredentials(new ClientCredentials(config.PlatformManagerClientId, 
                            config.PlatformManagerClientSecret, config.PlatformManagerScope))
                   .WithBaseUrl(config.ConnectionManagerBaseUrl)
                   .BuildOptions()
                   .EnsureAuthorizationTokenHandler(
                       new IdentityServerClient(new SdkClientOptionsBuilder()
                           .WithBaseUrl(config.PlatformManagerBaseUrl)
                           .BuildOptions()));

                return new ConnectionManagerClient(sdkClientOptions);

            });

            services.AddSingleton<IConnectorHubClient>(serviceProvider => {
                var config = serviceProvider.GetService<IOptionsMonitor<InfrastructureConfig>>().CurrentValue;

                var sdkClientOptions = new SdkClientOptionsBuilder()
                    .WithBaseUrl(config.ConnectorHubBaseUrl)
                    .WithCredentials(new ClientCredentials(config.PlatformManagerClientId, 
                            config.PlatformManagerClientSecret, config.PlatformManagerScope))
                    .BuildOptions()
                    .EnsureAuthorizationTokenHandler(
                        new IdentityServerClient(new SdkClientOptionsBuilder()
                            .WithBaseUrl(config.PlatformManagerBaseUrl)
                            .BuildOptions()));

                return new ConnectorHubClient(sdkClientOptions);

            });

            services.AddControllers();

            services.AddAuthentication("BasicAuthentication")
                .AddScheme<AuthenticationSchemeOptions, BasicAuthenticationHandler>("BasicAuthentication", null);
        }
        protected virtual void UseHttpsRedirection(IApplicationBuilder app)
        {
            app.UseHttpsRedirection();
        }
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseRouting();
            UseHttpsRedirection(app);

            app.UseExceptionHandler(c => c.Run(async context =>
            {
                var exception = context.Features
                    .Get<IExceptionHandlerPathFeature>()
                    .Error;
                var response = new { error = exception.Message };
                var result = JsonConvert.SerializeObject(new { error = exception.Message });
                context.Response.ContentType = "application/json";
                await context.Response.WriteAsync(result);
            }));

            app.UseAuthentication(); 
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
