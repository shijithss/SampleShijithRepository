﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;

namespace Adzu.GoogleConnector
{
    public class LocalStartup : Startup
    {
        public LocalStartup(IConfiguration configuration) : base(configuration)
        {
        }

        protected override void UseHttpsRedirection(IApplicationBuilder app)
        {

        }
    }
}
