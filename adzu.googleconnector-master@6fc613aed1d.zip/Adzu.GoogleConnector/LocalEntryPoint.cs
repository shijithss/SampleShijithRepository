using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Adzu.GoogleConnector
{
    public class LocalEntryPoint
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<LocalStartup>();
                })
                .ConfigureServices((builderContext, services) =>
                {
                    services.AddLogging(x => x.AddConsole())
                            .Configure<LoggerFilterOptions>(options => options.MinLevel = LogLevel.Debug);

                });
    }
}
