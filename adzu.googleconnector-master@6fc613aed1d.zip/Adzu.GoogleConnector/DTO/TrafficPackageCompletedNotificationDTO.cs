﻿using System.Collections.Generic;

namespace Adzu.GoogleConnector.DTO
{
    public class TrafficPackageCompletedNotificationDTO : EventDTO
    {
        public string ExternalId { get; set; }
        public List<AssetUploadStatus> Assets { get; set; }
        public ErrorDetails[] Errors { get; set; }
    }
}
