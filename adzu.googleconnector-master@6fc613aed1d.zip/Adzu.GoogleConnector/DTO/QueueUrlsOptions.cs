﻿namespace Adzu.GoogleConnector.DTO
{
    public class QueueUrlsOptions
    {
        public string DownloadQueue { get; set; }
        public string NotificationQueue { get; set; }
        public string ProcessQueue { get; set; }
    }
}
