﻿namespace Adzu.GoogleConnector.DTO
{
    public class RequestTrafficPackageDTO
    {
        public string ActionId { get; set; }
        public string RequestToken { get; set; }
        public Input Input { get; set; }
    }
}
