﻿namespace Adzu.GoogleConnector.DTO
{
    public class EventMessage
    {
        public string Body { get; set; }
        public string Type { get; set; }
    }
}
