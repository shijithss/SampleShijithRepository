﻿using System;

namespace Adzu.GoogleConnector.DTO
{
    public class EventDTO
    {
        public string FolderPackageName { get; set; }
        public string ActionId { get; set; }
        public bool WithoutNotify { get; set; }
        public Guid RequestId { get; set; }
        public string PackageUrl { get; set; }
        public string ConnectionReference { get; set; }
        public string RequestToken { get; set; }
        public string ExternalCampaignId { get; set; }
    }
}
