﻿namespace Adzu.GoogleConnector.DTO
{
    public class GetAccountsRequest
    {
        public string ActionId { get; set; }
        public string RequestToken { get; set; }
        public GetAccountsInput Input { get; set; }
    }
}
