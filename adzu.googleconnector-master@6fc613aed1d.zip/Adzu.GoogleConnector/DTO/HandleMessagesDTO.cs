﻿using Adzu.GoogleConnector.Services;
using System.Collections.Generic;
using static Amazon.Lambda.SQSEvents.SQSEvent;

namespace Adzu.GoogleConnector.DTO
{
    public class HandleMessagesDTO
    {
        public List<SQSMessage> SqsMessages { get; set; }
        public IMessageHandler MessageHandler { get; set; }
        public string QueueUrl { get; set; }
    }
}
