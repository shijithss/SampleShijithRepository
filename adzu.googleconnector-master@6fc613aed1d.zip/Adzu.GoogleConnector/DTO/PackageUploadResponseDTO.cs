﻿namespace Adzu.GoogleConnector.DTO
{
    public class PackageUploadResponseDTO
    {
        public string ManifestFileLink { get; set; }        
    }
}
