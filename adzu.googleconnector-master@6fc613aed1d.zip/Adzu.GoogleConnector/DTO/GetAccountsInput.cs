﻿namespace Adzu.GoogleConnector.DTO
{
    public class GetAccountsInput
    {
        public string ConnectionReference { get; set; }
        public string CustomerId { get; set; }
        public string LoginCustomerId { get; set; }
    }
}
