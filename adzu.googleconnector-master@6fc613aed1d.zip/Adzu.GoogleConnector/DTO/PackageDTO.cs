﻿namespace Adzu.GoogleConnector.DTO
{
    public class PackageDTO
    {

    }
}
