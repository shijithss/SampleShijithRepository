﻿namespace Adzu.GoogleConnector.DTO
{
    public class InnerManifestDTO
    { 
        public File[] Files { get; set; }
    }
    public class File
    { 
        public string Type { get; set; }
        public string Path { get; set; }
    }
}
