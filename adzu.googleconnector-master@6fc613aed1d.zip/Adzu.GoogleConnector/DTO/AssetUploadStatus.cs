﻿namespace Adzu.GoogleConnector.DTO
{
    public class AssetUploadStatus
    {
        public string ExternalId { get; set; }
        public string AssetId { get; set; }
        public string Status { get; set; }
        public string Reason { get; set; }
        public string Errors { get; set; }
    }
}
