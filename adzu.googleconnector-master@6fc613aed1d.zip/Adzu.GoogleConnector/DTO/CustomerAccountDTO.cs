﻿namespace Adzu.GoogleConnector.DTO
{
    public class CustomerAccountDTO
    {
        public string CustomerId { get; set; }
        public string CurrencyCode { get; set; }
        public string DescriptiveName { get; set; }
        public string TimeZone { get; set; }
        public bool IsManager { get; set; }
        public bool HasManager { get; set; }
        public bool IsTestAccount { get; set; }
        public string LoginCustomerId { get; set; }
    }
}
