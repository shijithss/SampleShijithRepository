﻿namespace Adzu.GoogleConnector.DTO
{
    public class ProcessPackage : EventDTO
    {
        public string ManifestFileLink { get; set; }
    }
}
