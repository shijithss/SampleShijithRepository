﻿
using Adzu.GoogleConnector.Helpers;

namespace Adzu.GoogleConnector.DTO
{
    public class TrafficPackageStatusDTO
    {
        public PackageStatusEnum InternalStatus { get; set; }
        public string Message { get; set; }
        public string Reason { get; set; }
    }
}
