﻿namespace Adzu.GoogleConnector.DTO
{
    public class GoogleConfigDTO
    {
        public string UserAgent { get; set; }
        public string OAuth2Mode { get; set; }
        public string DeveloperToken { get; set; } 
        public string AuthorizationMethod { get; set; }
    }
}
