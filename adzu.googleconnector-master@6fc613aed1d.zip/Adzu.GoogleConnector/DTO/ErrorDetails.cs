﻿using System.Collections.Generic;

namespace Adzu.GoogleConnector.DTO
{
    public class ErrorDetails
    {
        public string Code { get; set; }
        public string Message { get; set; }
        public string[] Params { get; set; }
        public string Details { get; set; }
    }
}