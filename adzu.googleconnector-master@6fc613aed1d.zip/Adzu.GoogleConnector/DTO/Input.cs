﻿namespace Adzu.GoogleConnector.DTO
{
    public class Input
    {
        public string PackageUrl { get; set; }
        public string ConnectionReference { get; set; }
        public string RequestId { get; set; }
        public bool WithoutNotify { get; set; }
    }
}
