﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.DTO
{
    public class Campaign
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Objective { get; set; }
        public string Currency { get; set; }
    }

    public class PostCode
    {
        public string CountryCode { get; set; }
        public string CityName { get; set; }
        public string PostalCode { get; set; }
        public string Radius { get; set; }
        public string RadiusUnits { get; set; }
    }

    public class Geographic
    {
        public List<PostCode> PostCodes { get; set; }
    }

    public class BusinessUnit
    {
        public Geographic Geographic { get; set; }
    }

    public class Product
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }

    public class Audience
    {
        public string TBD { get; set; }
    }

    public class MediaEndpointData
    {
        public string CustomerId { get; set; }
        public string LoginCustomerId { get; set; }
        public string ClickThroughUrl { get; set; }
    }

    public class Cost
    {
        public string Code { get; set; }
        public double Value { get; set; }
    }
    public class Asset
    {
        public string Id { get; set; }
        public string Package { get; set; }
    }

    public class PackageManifestDTO
    {
        private string _startDate;
        private string _endDate;

        public string StartDateForGoogle()
           => DateTime.Parse(_startDate, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal).ToString("yyyyMMdd");
        public string EndDateForGoogle()
            => DateTime.Parse(_endDate, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal).ToString("yyyyMMdd");
        public string Id { get; set; }
        public string Code { get; set; }
        public Campaign Campaign { get; set; }
        public string PlacementDisplayName { get; set; }
        public List<BusinessUnit> BusinessUnits { get; set; }
        public List<Product> Products { get; set; }
        public string StartDate
        {
            get => _startDate;
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new Exception($"ErrorId:{Guid.NewGuid()}, Message: StartDate cannot be empty", null);
                }
                else { _startDate = value; }
            }
        }
        public string EndDate
        {
            get => _endDate;
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new Exception($"ErrorId:{Guid.NewGuid()}, Message: EndDate cannot be empty", null);
                }
                else { _endDate = value; }
            }
        }
        public List<Audience> Audiences { get; set; }
        public string UniqueReference { get; set; }
        public string MediaEndpointInstruction { get; set; }
        public MediaEndpointData MediaEndpointData { get; set; }
        public Cost PlannedMediaCost { get; set; }
        public Cost ProductionCost { get; set; }
        public Cost OtherCost { get; set; }
        public string OtherCostDescription { get; set; }
        public List<Asset> Assets { get; set; }

    }
}
