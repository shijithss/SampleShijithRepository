using adzu.connectorhub.sdk;
using Adzu.ConnectionManager.SDK;
using Adzu.GoogleConnector.DTO;
using Adzu.GoogleConnector.Functions;
using Adzu.GoogleConnector.Helpers;
using Adzu.GoogleConnector.Services;
using Adzu.GoogleConnector.Tests.Mocks;
using Adzu.GoogleConnector.Validators;
using Adzu.Sdk.IoC;
using FluentValidation;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Tests
{
    public class TrafficPackageServiceErrorsTests
    {
        private IServiceProvider _serviceProvider;
        private ITrafficPackageService _trafficService;
        private IStatusService _statusService;       
        private IServiceCollection _serviceCollection;
        private const string FolderPackageName = "Test";
        [SetUp]
        public void Setup()
        {
           _serviceCollection  = new ServiceCollection();

            var configBuilder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: true)
                .AddEnvironmentVariables()
                .AddCommandLine(Environment.GetCommandLineArgs());

            var config = configBuilder.Build();
            _serviceCollection.Configure<ClientConfigOptions>(config);
            _serviceCollection.AddLogging(x =>
               x.AddLambdaLogger(new LambdaLoggerOptions
               {
                   IncludeCategory = true,
                   IncludeLogLevel = true,
                   IncludeNewline = true,
                   IncludeEventId = true,
                   IncludeException = true,
                   IncludeScopes = true
               }))
               .Configure<LoggerFilterOptions>(options => options.MinLevel = LogLevel.Information);

            _serviceCollection.AddTransient<IValidator<RequestTrafficPackageDTO>, PackageRequestDTOValidator>();
            _serviceCollection.AddTransient<IValidator<TrafficPackageStatusDTO>, StatusDTOValidator>();
            _serviceCollection.AddTransient<IValidator<DownloadPackage>, DownloadPackageValidator>();
            _serviceCollection.AddScoped<ITrafficPackageService, TrafficPackageService>();
            _serviceCollection.AddTransient<IGoogleServiceProvider, GoogleServiceProvider>();
            _serviceCollection.AddScoped<IFileAccessService, MockFileAccessService>();
            _serviceCollection.AddScoped<ISqsService, MockSqsService>();
            _serviceCollection.AddScoped<IStatusService, StatusService>();
            _serviceCollection.AddScoped<IGoogleGatewayService, MockGoogleGatewayService>();
            _serviceCollection.AddScoped<IHttpRequestService, MockHttpRequestService>();
            _serviceCollection.AddScoped<IConnectorHubClient, MockConnectorHubClient>();
            _serviceCollection.AddScoped<IConnectionManagerClient, MockConnectionManagerClient>();
        }

        [Test]
        public async Task CorruptedFileErrorSentByPackagePackageDownloadFunction() 
        {
            _serviceCollection.AddTransient<IValidator<DownloadPackage>, DownloadPackageValidatorMock>();
            ResolveServices();
            var packageFileUrl = Path.Combine(Directory.GetCurrentDirectory(), "Mocks", "TestResources", "CorruptedTrafficPackage.zip");
           
            var downloadPackageEventBodyDto = new DownloadPackage
            {
                FolderPackageName = FolderPackageName,
                PackageUrl = packageFileUrl

            };
            var downloadPackageEventMessage = MockEventMessageDto(downloadPackageEventBodyDto);

            var ex = Assert.CatchAsync(async () => await PackageDownloadFunctionExecute(downloadPackageEventMessage));            

            var _sqsService = _serviceProvider.GetService<ISqsService>() as ISqsRead;

            var sendNotifyEventBodyDto = _sqsService.Read() as TrafficPackageCompletedNotificationDTO;

            var packageNotificationEventMessage = MockEventMessageDto(sendNotifyEventBodyDto);

            await PackageNotificationFunctionExecute(packageNotificationEventMessage);

            var statusDto = GetConnectorHubNotificationResponse();

            var actualNotificationType = statusDto["notificationType"].ToString();
            var actualStatus = statusDto["status"].ToString();
            var actualErrors = statusDto["errors"].ToObject<ErrorDetails[]>();
            

            Assert.AreEqual("TrafficPackageCompleted", actualNotificationType);
            Assert.AreEqual("Fail", actualStatus);
            Assert.AreEqual(1, actualErrors.Length, "Errors fail");

            var actualError = actualErrors[0];

            Assert.AreEqual("CorruptedFile", actualError.Code);
            Assert.AreEqual("The file is corrupted. File {0}", actualError.Message);
            Assert.AreEqual(1, actualError.Params.Length, "Params fail");
            Assert.AreEqual(packageFileUrl, actualError.Params[0]);
        }

        [Test]
        public async Task UnhandledErrorSentByPackageDownloadFunction()
        {
            _serviceCollection.AddTransient<IValidator<DownloadPackage>, DownloadPackageValidatorMock>();
            _serviceCollection.AddScoped<IHttpRequestService, MockHttpRequestServiceWithError>();
            ResolveServices();

            var packageFileUrl = Path.Combine(Directory.GetCurrentDirectory(), "Mocks", "TestResources", "SampleTrafficPackage.zip");

            var downloadPackageEventBodyDto = new DownloadPackage
            {
                FolderPackageName = FolderPackageName,
                PackageUrl = packageFileUrl

            };
            

            
            var downloadPackageEventMessage = MockEventMessageDto(downloadPackageEventBodyDto);

            var ex = Assert.CatchAsync(async () => await PackageDownloadFunctionExecute(downloadPackageEventMessage));

            var _sqsService = _serviceProvider.GetService<ISqsService>() as ISqsRead;

            var sendNotifyEventBodyDto = _sqsService.Read() as TrafficPackageCompletedNotificationDTO;

            var packageNotificationEventMessage = MockEventMessageDto(sendNotifyEventBodyDto);

            await PackageNotificationFunctionExecute(packageNotificationEventMessage);

            var statusDto = GetConnectorHubNotificationResponse();

            var actualNotificationType = statusDto["notificationType"].ToString();
            var actualStatus = statusDto["status"].ToString();
            var actualErrors = statusDto["errors"].ToObject<ErrorDetails[]>();


            Assert.AreEqual("TrafficPackageCompleted", actualNotificationType);
            Assert.AreEqual("Fail", actualStatus);
            Assert.AreEqual(1, actualErrors.Length, "Errors fail");

            var actualError = actualErrors[0];

            Assert.AreEqual("UnhandledError", actualError.Code);
            Assert.AreEqual("readfileError", actualError.Message);
            Assert.AreEqual(1, actualError.Params.Length, "Params fail");
            Assert.AreEqual(packageFileUrl, actualError.Params[0]);
        }

        [Test]
        public async Task EmptySreamErrorSentByPackageDownloadFunction()
        {
            _serviceCollection.AddScoped<IHttpRequestService, MockHttpRequestServiceWithNoResponse>();
            ResolveServices();
            var packageFileUrl = "https://requestedfilename";
            
            var downloadPackageEventBodyDto = new DownloadPackage
            {
                FolderPackageName = FolderPackageName,
                PackageUrl = packageFileUrl

            };
            var downloadPackageEventMessage = MockEventMessageDto(downloadPackageEventBodyDto);

            var ex = Assert.CatchAsync(async () => await PackageDownloadFunctionExecute(downloadPackageEventMessage));

            var _sqsService = _serviceProvider.GetService<ISqsService>() as ISqsRead;

            var sendNotifyEventBodyDto = _sqsService.Read() as TrafficPackageCompletedNotificationDTO;

            var packageNotificationEventMessage = MockEventMessageDto(sendNotifyEventBodyDto);

            await PackageNotificationFunctionExecute(packageNotificationEventMessage);

            var statusDto = GetConnectorHubNotificationResponse();

            var actualNotificationType = statusDto["notificationType"].ToString();
            var actualStatus = statusDto["status"].ToString();
            var actualErrors = statusDto["errors"].ToObject<ErrorDetails[]>();

            Assert.AreEqual("TrafficPackageCompleted", actualNotificationType);
            Assert.AreEqual("Fail", actualStatus);
            Assert.AreEqual("CorruptedFile", actualErrors[0].Code);
            Assert.AreEqual(packageFileUrl, actualErrors[0].Params[0]);
        }

        [Test]
        public async Task InvalidUrlErrorSentByPackageDownloadFunction()
        {
            ResolveServices();
           string packageFileUrl = "/dfdsfsdffdds\\f/sddsnvalidUrl.com/sdd?ss=sdsdsd";

            var downloadPackageEventBodyDto = new DownloadPackage
            {
                FolderPackageName = FolderPackageName,
                PackageUrl = packageFileUrl

            };
            var downloadPackageEventMessage = MockEventMessageDto(downloadPackageEventBodyDto);

            var ex = Assert.CatchAsync(async () => await PackageDownloadFunctionExecute(downloadPackageEventMessage));

            var _sqsService = _serviceProvider.GetService<ISqsService>() as ISqsRead;

            var sendNotifyEventBodyDto = _sqsService.Read() as TrafficPackageCompletedNotificationDTO;

            var packageNotificationEventMessage = MockEventMessageDto(sendNotifyEventBodyDto);

            await PackageNotificationFunctionExecute(packageNotificationEventMessage);

            var statusDto = GetConnectorHubNotificationResponse();

            var actualNotificationType = statusDto["notificationType"].ToString();
            var actualStatus = statusDto["status"].ToString();
            var actualErrors = statusDto["errors"].ToObject<ErrorDetails[]>();


            Assert.AreEqual("TrafficPackageCompleted", actualNotificationType);
            Assert.AreEqual("Fail", actualStatus);
            Assert.AreEqual(1, actualErrors.Length, "Errors fail");

            var actualError = actualErrors[0];

            Assert.AreEqual("InvalidDownloadURL", actualError.Code);
            Assert.AreEqual("Invalid Download URL. Package URL {0}", actualError.Message);
            Assert.AreEqual(1, actualError.Params.Length, "Params fail");
            Assert.AreEqual(packageFileUrl, actualError.Params[0]);
        }


        private async Task PackageDownloadFunctionExecute(EventMessage eventMessage)
        {
            TrafficPackageConstants.ActionName = typeof(SqsHandlerFunction).Name;
            await _trafficService.DownloadPackage(eventMessage);
        }

        private async Task PackageNotificationFunctionExecute(EventMessage eventMessage)
        {
            TrafficPackageConstants.ActionName = typeof(SqsHandlerFunction).Name;
            await _trafficService.NotificationTraffic(eventMessage);
        }
        private async Task ProcessPackageFunctionExecute(EventMessage eventMessage)
        {
            TrafficPackageConstants.ActionName = typeof(SqsHandlerFunction).Name;
            await _trafficService.ProcessPackage(eventMessage);
        }
        private EventMessage MockEventMessageDto(EventDTO bodyDto)
        {
            return new EventMessage { Body = JsonConvert.SerializeObject(bodyDto) };
        }

        private JToken GetConnectorHubNotificationResponse()
        {
            var _connectorHubClient = _serviceProvider.GetService<IConnectorHubClient>();
            var connectorHubresponse = _connectorHubClient.Notifications.ListAll().Result;
            var notificationResponse = connectorHubresponse.Items.FirstOrDefault();
            var statusDto = notificationResponse.Notification;

            return statusDto;
        }

        private void ResolveServices()
        {           
            _serviceProvider = _serviceCollection.BuildServiceProvider();

            _trafficService = _serviceProvider.GetService<ITrafficPackageService>();
            ((TrafficPackageService)_trafficService).IsTestingMode = true;

            _statusService = _serviceProvider.GetService<IStatusService>();
            ((StatusService)_statusService).IsTestingMode = true;
           
        }

        
    }
}