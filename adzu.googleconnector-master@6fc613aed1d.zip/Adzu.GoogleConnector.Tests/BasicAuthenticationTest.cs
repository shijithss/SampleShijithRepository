﻿using Adzu.GoogleConnector.Helpers;
using Amazon.Lambda.Core;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Primitives;
using Microsoft.Net.Http.Headers;
using Moq;
using NUnit.Framework;
using System;
using System.IO;
using System.Text;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
namespace Adzu.GoogleConnector.Tests
{
    class BasicAuthenticationTest
    {
        private  BasicAuthenticationHandler _handler;

        [SetUp]
        public void Setup()
        {
            var configBuilder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: true)
                .AddEnvironmentVariables()
                .AddCommandLine(Environment.GetCommandLineArgs());

            var config = configBuilder.Build();
            Startup.Configuration = config;

            var _optionsMock = new Mock<IOptionsMonitor<AuthenticationSchemeOptions>>();
            _optionsMock.Setup(x => x.Get(It.IsAny<string>()))
                .Returns(new AuthenticationSchemeOptions());

            var loggerMock = new Mock<ILogger<BasicAuthenticationHandler>>();

            var _loggerFactoryMock = new Mock<ILoggerFactory>();
            _loggerFactoryMock.Setup(x => x.CreateLogger(It.IsAny<String>()))
                .Returns(loggerMock.Object);

            var _encoderMock = new Mock<UrlEncoder>();
            var _clockMock = new Mock<ISystemClock>();

            _handler = new BasicAuthenticationHandler(_optionsMock.Object, _loggerFactoryMock.Object, _encoderMock.Object, _clockMock.Object);           
        }



        [Test]
        public async Task BasicAuthenticationSuccessTest()
        {
            //given
            HttpContext context = new DefaultHttpContext();
            var name = Startup.Configuration["ClientName"];
            var secret = Startup.Configuration["ClientSecret"];
            SetAuthorizationHeader(context, name, secret);

            await _handler.InitializeAsync(
              new AuthenticationScheme("BasicAuthentication", null, typeof(BasicAuthenticationHandler)),
              context);

            //when
            AuthenticateResult result = await _handler.AuthenticateAsync();

            //then
            Assert.IsTrue(result.Succeeded);
            Assert.IsNull(result.Failure);
        }

        [Test]
        public async Task BasicAuthenticationFailTest()
        {
            //given
            HttpContext context = new DefaultHttpContext();           
            SetAuthorizationHeader(context, "userName", "userSecrest");

            await _handler.InitializeAsync(
              new AuthenticationScheme("BasicAuthentication", null, typeof(BasicAuthenticationHandler)),
              context);

            //when
            AuthenticateResult result = await _handler.AuthenticateAsync();

            //then
            Assert.IsFalse(result.Succeeded);
            Assert.IsNotNull(result.Failure);
        }

        [Test]
        public async Task BasicAuthenticationAllowAnonymousSuccessTest()        
        {
            //given
            HttpContext context = new DefaultHttpContext();

            Endpoint endpoint = new Endpoint(
                (x) =>  Task.CompletedTask,
                new EndpointMetadataCollection(new object[] { new AllowAnonymousAttribute() }),
                "name");

            context.SetEndpoint(endpoint);

            await _handler.InitializeAsync(
              new AuthenticationScheme("BasicAuthentication", null, typeof(BasicAuthenticationHandler)),
              context);

            //when
            AuthenticateResult result = await _handler.AuthenticateAsync();

            //then
            Assert.IsTrue(result.None);
            Assert.IsNull(result.Failure);
        }

        [Test]
        public async Task BasicAuthenticationAllowAnonymousFailTest()
        {
            //given
            HttpContext context = new DefaultHttpContext();
            SetAuthorizationHeader(context, "userName", "userSecrest");

            Endpoint endpoint = new Endpoint(
                (x) => Task.CompletedTask,
                new EndpointMetadataCollection(new object[] { new AuthorizeAttribute() }),
                "name");

            context.SetEndpoint(endpoint);
                      
            await _handler.InitializeAsync(
              new AuthenticationScheme("BasicAuthentication", null, typeof(BasicAuthenticationHandler)),
              context);

            //when
            AuthenticateResult result = await _handler.AuthenticateAsync();

            //then
            Assert.IsFalse(result.Succeeded);
            Assert.IsNotNull(result.Failure);
        }

        private void SetAuthorizationHeader(HttpContext context, string name, string secret)
        {
            string hashUser = Convert.ToBase64String(Encoding.ASCII.GetBytes($"{name}:{secret}"));
            context.Request.Headers.Add(HeaderNames.Authorization, new StringValues($"Basic {hashUser}"));
        }
    }   

}

