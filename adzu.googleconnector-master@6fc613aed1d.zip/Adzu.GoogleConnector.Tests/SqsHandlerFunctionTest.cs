﻿using Adzu.GoogleConnector.Functions;
using Adzu.GoogleConnector.Tests.Mocks;
using Amazon.SQS;
using Amazon.Lambda.SQSEvents;
using Microsoft.Extensions.DependencyInjection;
using NUnit.Framework;
using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using static Amazon.Lambda.SQSEvents.SQSEvent;
using Newtonsoft.Json;
using Adzu.GoogleConnector.DTO;
using Adzu.GoogleConnector.Services;
using Adzu.GoogleConnector.Helpers;
using Adzu.GoogleConnector.Validators;
using FluentValidation;
using Microsoft.Extensions.Logging;
using adzu.connectorhub.sdk;
using Adzu.ConnectionManager.SDK;
using System.IO;
using System.Linq;
using Newtonsoft.Json.Linq;

namespace Adzu.GoogleConnector.Tests
{
    class SqsHandlerFunctionTest
    {
        private IServiceProvider _serviceProvider;
        private string MessageQueueUrl = "Test";
        private const string FolderPackageName = "Test";
        [SetUp]
        public void Setup()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddLogging(x =>
                x.AddLambdaLogger(new LambdaLoggerOptions
                {
                    IncludeCategory = true,
                    IncludeLogLevel = true,
                    IncludeNewline = true,
                    IncludeEventId = true,
                    IncludeException = true,
                    IncludeScopes = true
                }))
                .Configure<LoggerFilterOptions>(options => options.MinLevel = LogLevel.Information);

            serviceCollection.AddScoped<IAmazonSQS, MockAmazonSQSClient>();
            serviceCollection.AddScoped<ITrafficPackageService, TrafficPackageService>();
            serviceCollection.AddScoped<IStatusService, StatusService>();
            serviceCollection.AddScoped<IFileAccessService, MockFileAccessService>();
            serviceCollection.AddTransient<IValidator<TrafficPackageStatusDTO>, StatusDTOValidator>();
            serviceCollection.AddTransient<IValidator<RequestTrafficPackageDTO>, PackageRequestDTOValidator>();
            serviceCollection.AddTransient<IValidator<DownloadPackage>, DownloadPackageValidatorMock>();
            serviceCollection.AddScoped<ISqsService, MockSqsService>();
            serviceCollection.AddScoped<IHttpRequestService, MockHttpRequestService>();
            serviceCollection.AddScoped<IConnectorHubClient, MockConnectorHubClient>();
            serviceCollection.AddScoped<IGoogleServiceProvider, GoogleServiceProvider>();
            serviceCollection.AddScoped<IGoogleGatewayService, MockGoogleGatewayService>();
            serviceCollection.AddScoped<IConnectionManagerClient, MockConnectionManagerClient>();

            _serviceProvider = serviceCollection.BuildServiceProvider();
        }
        [Test]
        public async Task HandleEventAsyncTestNotificationEvent()
        {
            //given
            var statusService = _serviceProvider.GetService<IStatusService>();
            var sqsService = new SqsHandlerFunction(_serviceProvider);
            var messageBody = JsonConvert.SerializeObject(new TrafficPackageCompletedNotificationDTO {
                FolderPackageName = FolderPackageName
            });
            var @event = CreateEvents(messageBody, typeof(TrafficPackageCompletedNotificationDTO).FullName);
            //when
            await sqsService.HandleEventAsync(@event, null);
            var status = await statusService.GetStatus(FolderPackageName);
            //then
            Assert.AreEqual(PackageStatusEnum.Fail,status.InternalStatus);
        }
        [Test]
        public async Task HandleEventAsyncTestUnknownEvent()
        {
            //given
            var statusService = _serviceProvider.GetService<IStatusService>();
            var connectorHubService = _serviceProvider.GetService<IConnectorHubClient>();
            var sqsService = new SqsHandlerFunction(_serviceProvider);
            var messageBody = JsonConvert.SerializeObject(new EventDTO
            {
                FolderPackageName = FolderPackageName
            });
            var @event = CreateEvents(messageBody, typeof(EventDTO).FullName);
            //when
            await sqsService.HandleEventAsync(@event, null);
            var status = await statusService.GetStatus(FolderPackageName);
            var notifications = await connectorHubService.Notifications.ListAll();
            var notification = notifications.Items.First().Notification["status"].ToString();
            //then
            Assert.AreEqual(PackageStatusEnum.Fail, status.InternalStatus);
            Assert.AreEqual(PackageStatusEnum.Fail.GetDescription(), notification);
        }
        [Test]
        public async Task HandleDLQEventAsync()
        {
            //given
            var exceptionMessage = "TestDLQHandler";
            var statusService = _serviceProvider.GetService<IStatusService>();
            var connectorHubService = _serviceProvider.GetService<IConnectorHubClient>();
            var sqsService = new SqsHandlerFunction(_serviceProvider);
            var messageBody = JsonConvert.SerializeObject(new DownloadPackage
            {
                FolderPackageName = FolderPackageName
            });
            var @event = CreateEvents(messageBody, typeof(DownloadPackage).FullName);

            var errors = new CustomException(exceptionMessage, null, PackageStatusEnum.Fail)
                            .ToErrorDetails("Test", FolderPackageName);
            await statusService.SetErrors(errors, FolderPackageName);
            //when
            await sqsService.HandleDLQEventAsync(@event, null);
            var status = await statusService.GetStatus(FolderPackageName);
            var notifications = await connectorHubService.Notifications.ListAll();
            var notification = notifications.Items.First().Notification["status"].ToString();
            var error = notifications.Items.First().Notification["errors"].ToObject<ErrorDetails[]>().First();
            //then
            Assert.AreEqual(PackageStatusEnum.Fail, status.InternalStatus);
            Assert.AreEqual(PackageStatusEnum.Fail.GetDescription(), notification);
            Assert.AreEqual(exceptionMessage, error.Message);
        }
        [Test]
        public async Task HandleEventAsyncTestDownloadPackageEvent()
        {
            //given
            var statusService = _serviceProvider.GetService<IStatusService>();
            var sqsService = new SqsHandlerFunction(_serviceProvider);
            var messageBody = JsonConvert.SerializeObject(new DownloadPackage
            {
                FolderPackageName = FolderPackageName,
                PackageUrl = Path.Combine(Directory.GetCurrentDirectory(), "Mocks", "TestResources", "DummyTrafficPackage.zip")
            });
            var @event = CreateEvents(messageBody, typeof(DownloadPackage).FullName);
            //when
            await sqsService.HandleEventAsync(@event, null);
            var status = await statusService.GetStatus(FolderPackageName);
            //then
            Assert.AreEqual(PackageStatusEnum.Extracted, status.InternalStatus);
        }
        [Test]
        public async Task HandleEventAsyncTestProcessPackageEvent()
        {
            //given
            var fileAccessService = _serviceProvider.GetService<IFileAccessService>();
            var statusService = _serviceProvider.GetService<IStatusService>();
            var sqsService = new SqsHandlerFunction(_serviceProvider);
            var messageBody = JsonConvert.SerializeObject(new ProcessPackage
            {
                FolderPackageName = FolderPackageName,
                ManifestFileLink = "ManifestFileTest"
            });
            var manifestDto = new PackageManifestDTO
            {
                StartDate = DateTime.Now.AddDays(4).ToString("o"),
                EndDate = DateTime.Now.AddDays(5).ToString("o"),
                MediaEndpointData = new MediaEndpointData(),
                Assets = new List<Asset>()
            };

            await fileAccessService.CreateFile(JsonConvert.SerializeObject(manifestDto), "ManifestFileTest");
            var @event = CreateEvents(messageBody, typeof(ProcessPackage).FullName);
            //when
            await sqsService.HandleEventAsync(@event, null);
            var status = await statusService.GetStatus(FolderPackageName);
            //then
            Assert.AreEqual(PackageStatusEnum.Processed, status.InternalStatus);
        }
        private SQSEvent CreateEvents(string messageBody, string typeFullName)
        => new SQSEvent
        {
            Records = new List<SQSMessage>
                {
                    new SQSMessage {
                        Body = messageBody,
                        MessageAttributes = new Dictionary<string, MessageAttribute>
                        {
                            {
                                "MessageType",
                                new MessageAttribute {
                                    DataType = "String",
                                    StringValue = typeFullName
                                }
                            },
                            {
                                "QueueUrl",
                                new MessageAttribute {
                                    DataType = "String",
                                    StringValue = MessageQueueUrl
                                }
                            }
                        },
                        Attributes = new Dictionary<string,string>()
                    }
                }
        };
    }
}
