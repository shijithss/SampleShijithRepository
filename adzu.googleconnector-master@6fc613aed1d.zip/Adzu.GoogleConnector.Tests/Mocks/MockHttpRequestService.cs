﻿using Adzu.GoogleConnector.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Tests.Mocks
{
    public class MockHttpRequestService : IHttpRequestService
    {
        Task IHttpRequestService.PostRequest(string callbackUrl, string body) => throw new NotImplementedException();
        Task<Stream> IHttpRequestService.ReadFile(string fileUrl)
        {
            var memoryStream = new MemoryStream();
            using (var fileStream = new FileStream(fileUrl, FileMode.Open))
            {
                fileStream.Seek(0, SeekOrigin.Begin);
                fileStream.CopyTo(memoryStream);
                memoryStream.Seek(0, SeekOrigin.Begin);
            }          

            return Task.FromResult<Stream>(memoryStream);
        }
       
    }

    public class MockHttpRequestServiceWithError : IHttpRequestService
    {
        Task IHttpRequestService.PostRequest(string callbackUrl, string body) => throw new NotImplementedException();
        Task<Stream> IHttpRequestService.ReadFile(string fileUrl)
        {
            throw new Exception("readfileError");
        }

    }

    public class MockHttpRequestServiceWithNoResponse : IHttpRequestService
    {        
        Task IHttpRequestService.PostRequest(string callbackUrl, string body) => throw new NotImplementedException();
        public async Task<Stream> ReadFile(string fileUrl) => null;
        

    }
}
