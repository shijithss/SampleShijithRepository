﻿using Adzu.GoogleConnector.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Tests.Mocks
{
    public class MockFileAccessService : IFileAccessService
    {
        private Dictionary<string, Stream> _mockS3Stream = new Dictionary<string, Stream>();
        public async Task CreateFile(Stream data, string path)
        {
            var streamToSave = new MemoryStream();
            data.Seek(0, SeekOrigin.Begin);
            data.CopyTo(streamToSave);
            streamToSave.Seek(0, SeekOrigin.Begin);
            _mockS3Stream[path] = streamToSave;
        }

        public async Task CreateFile(string data, string path) {
            _mockS3Stream[path] = new MemoryStream(Encoding.UTF8.GetBytes(data));
        }

        public async Task<Stream> GetObject(string key)
        {            
            _mockS3Stream.TryGetValue(key, out Stream data);
            if (data == null) throw new IndexOutOfRangeException();
            var resultStream = new MemoryStream();
            data.Seek(0, SeekOrigin.Begin);
            data.CopyTo(resultStream);
            resultStream.Seek(0, SeekOrigin.Begin);
            return resultStream;
        }

        Task IFileAccessService.RemoveObject(string key) => throw new NotImplementedException();

        public async Task<IList<string>> GetFileNameList(string key) {
            return _mockS3Stream.Where(f=>f.Key.Contains(key)).Select(f => f.Key).ToList();
        }
    }
}
