﻿using Google.Ads.GoogleAds.V9.Services;
using System;
using System.Collections.Generic;
using System.Text;

namespace Adzu.GoogleConnector.Tests.Mocks
{
    public class MockCustomerServiceClient: CustomerServiceClient
    {
        public virtual new string[] ListAccessibleCustomers()
        {
            return new string[] { };
        }   
    }
}
