﻿using Adzu.GoogleConnector.DTO;
using Adzu.GoogleConnector.Services;
using Amazon.Lambda.Core;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Tests.Mocks
{
    public class MockSqsService : ISqsService, ISqsRead
    {
        private EventDTO _requestDTO;
        
        public async Task SendMessage(EventDTO requestDTO, string messageQueueUrl) 
        {
            _requestDTO = requestDTO;
        }

        EventDTO ISqsRead.Read()
        {
            return _requestDTO;
        }
    }

    public interface ISqsRead
    {
        EventDTO Read();
    }
}
