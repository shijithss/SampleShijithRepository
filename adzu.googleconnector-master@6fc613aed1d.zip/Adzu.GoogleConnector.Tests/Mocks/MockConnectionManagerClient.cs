﻿using Adzu.ConnectionManager.Contracts.Requests;
using Adzu.ConnectionManager.Contracts.Responses;
using Adzu.ConnectionManager.SDK;
using Adzu.ConnectionManager.SDK.V2;
using System;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Tests.Mocks
{
    class MockConnectionManagerClient : IConnectionManagerClient
    {
        IConnectionClientV2 IConnectionManagerClient.Connection => throw new NotImplementedException();

        IConnectionClientV3 IConnectionManagerClient.ConnectionV3 => throw new NotImplementedException();

        ITenantAccountClient IConnectionManagerClient.TenantAccount => throw new NotImplementedException();

        IServiceProviderClient IConnectionManagerClient.ServiceProvider => throw new NotImplementedException();

        ITokenClient IConnectionManagerClient.Token => throw new NotImplementedException();

        IOAuth2Client IConnectionManagerClient.OAuth2 => new OAuth2Client();
    }

    class OAuth2Client : IOAuth2Client
    {
        Task<CreateOAuth2ConnectionResponse> IOAuth2Client.CreateConnection(CreateOAuth2ConnectionRequest request)
        {
            throw new NotImplementedException();
        }

        Task<string> IOAuth2Client.GetInitAuthFlowRedirectUrl(string serviceProviderId)
        {
            throw new NotImplementedException();
        }

        Task<string> IOAuth2Client.GetToken(string code, string state, string error)
        {
            throw new NotImplementedException();
        }

         Task<AccessTokenResponse> IOAuth2Client.RetrieveAccessToken(AccessTokenRequest request)
        {
           return  Task.FromResult<AccessTokenResponse>(new AccessTokenResponse());
           
        }
    }
}
