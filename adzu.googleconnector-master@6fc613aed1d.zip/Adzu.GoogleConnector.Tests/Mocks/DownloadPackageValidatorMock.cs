﻿using Adzu.GoogleConnector.DTO;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace Adzu.GoogleConnector.Tests.Mocks
{
    class DownloadPackageValidatorMock : AbstractValidator<DownloadPackage>
    {
        public DownloadPackageValidatorMock()
        {
            RuleFor(x => x.PackageUrl).NotEmpty();
        }
    }
}
