﻿using Amazon.Runtime;
using Amazon.Runtime.SharedInterfaces;
using Amazon.SQS;
using Amazon.SQS.Model;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Tests.Mocks
{
    public class MockAmazonSQSClient : IAmazonSQS
    {
        private SendMessageRequest _savedRequest;
        public async Task<SendMessageResponse> SendMessageAsync(SendMessageRequest request, CancellationToken cancellationToken)
        {
            _savedRequest = request;
            return new SendMessageResponse();
        }
        public async Task<ReceiveMessageResponse> ReceiveMessageAsync(string queueUrl, CancellationToken cancellationToken)
        {
            return new ReceiveMessageResponse
            {
                Messages = new List<Message>
                {
                    new Message {
                        Body = _savedRequest.MessageBody,
                        MessageAttributes = _savedRequest.MessageAttributes
                    }
                }
            };
        }
        public async Task<DeleteMessageResponse> DeleteMessageAsync(string queueUrl, string receiptHandle, CancellationToken cancellationToken)
        {
            return new DeleteMessageResponse();
        }
        ISQSPaginatorFactory IAmazonSQS.Paginators => throw new NotImplementedException();
        IClientConfig IAmazonService.Config => throw new NotImplementedException();
        Task<AddPermissionResponse> IAmazonSQS.AddPermissionAsync(string queueUrl, string label, List<string> awsAccountIds, List<string> actions, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<AddPermissionResponse> IAmazonSQS.AddPermissionAsync(AddPermissionRequest request, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<string> IAmazonSQS.AuthorizeS3ToSendMessageAsync(string queueUrl, string bucket) => throw new NotImplementedException();
        Task<ChangeMessageVisibilityResponse> IAmazonSQS.ChangeMessageVisibilityAsync(string queueUrl, string receiptHandle, int visibilityTimeout, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<ChangeMessageVisibilityResponse> IAmazonSQS.ChangeMessageVisibilityAsync(ChangeMessageVisibilityRequest request, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<ChangeMessageVisibilityBatchResponse> IAmazonSQS.ChangeMessageVisibilityBatchAsync(string queueUrl, List<ChangeMessageVisibilityBatchRequestEntry> entries, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<ChangeMessageVisibilityBatchResponse> IAmazonSQS.ChangeMessageVisibilityBatchAsync(ChangeMessageVisibilityBatchRequest request, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<CreateQueueResponse> IAmazonSQS.CreateQueueAsync(string queueName, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<CreateQueueResponse> IAmazonSQS.CreateQueueAsync(CreateQueueRequest request, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<DeleteMessageResponse> IAmazonSQS.DeleteMessageAsync(DeleteMessageRequest request, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<DeleteMessageBatchResponse> IAmazonSQS.DeleteMessageBatchAsync(string queueUrl, List<DeleteMessageBatchRequestEntry> entries, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<DeleteMessageBatchResponse> IAmazonSQS.DeleteMessageBatchAsync(DeleteMessageBatchRequest request, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<DeleteQueueResponse> IAmazonSQS.DeleteQueueAsync(string queueUrl, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<DeleteQueueResponse> IAmazonSQS.DeleteQueueAsync(DeleteQueueRequest request, CancellationToken cancellationToken) => throw new NotImplementedException();
        void IDisposable.Dispose() => throw new NotImplementedException();
        Task<Dictionary<string, string>> ICoreAmazonSQS.GetAttributesAsync(string queueUrl) => throw new NotImplementedException();
        Task<GetQueueAttributesResponse> IAmazonSQS.GetQueueAttributesAsync(string queueUrl, List<string> attributeNames, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<GetQueueAttributesResponse> IAmazonSQS.GetQueueAttributesAsync(GetQueueAttributesRequest request, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<GetQueueUrlResponse> IAmazonSQS.GetQueueUrlAsync(string queueName, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<GetQueueUrlResponse> IAmazonSQS.GetQueueUrlAsync(GetQueueUrlRequest request, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<ListDeadLetterSourceQueuesResponse> IAmazonSQS.ListDeadLetterSourceQueuesAsync(ListDeadLetterSourceQueuesRequest request, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<ListQueuesResponse> IAmazonSQS.ListQueuesAsync(string queueNamePrefix, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<ListQueuesResponse> IAmazonSQS.ListQueuesAsync(ListQueuesRequest request, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<ListQueueTagsResponse> IAmazonSQS.ListQueueTagsAsync(ListQueueTagsRequest request, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<PurgeQueueResponse> IAmazonSQS.PurgeQueueAsync(string queueUrl, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<PurgeQueueResponse> IAmazonSQS.PurgeQueueAsync(PurgeQueueRequest request, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<ReceiveMessageResponse> IAmazonSQS.ReceiveMessageAsync(ReceiveMessageRequest request, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<RemovePermissionResponse> IAmazonSQS.RemovePermissionAsync(string queueUrl, string label, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<RemovePermissionResponse> IAmazonSQS.RemovePermissionAsync(RemovePermissionRequest request, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<SendMessageResponse> IAmazonSQS.SendMessageAsync(string queueUrl, string messageBody, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<SendMessageBatchResponse> IAmazonSQS.SendMessageBatchAsync(string queueUrl, List<SendMessageBatchRequestEntry> entries, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<SendMessageBatchResponse> IAmazonSQS.SendMessageBatchAsync(SendMessageBatchRequest request, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task ICoreAmazonSQS.SetAttributesAsync(string queueUrl, Dictionary<string, string> attributes) => throw new NotImplementedException();
        Task<SetQueueAttributesResponse> IAmazonSQS.SetQueueAttributesAsync(string queueUrl, Dictionary<string, string> attributes, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<SetQueueAttributesResponse> IAmazonSQS.SetQueueAttributesAsync(SetQueueAttributesRequest request, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<TagQueueResponse> IAmazonSQS.TagQueueAsync(TagQueueRequest request, CancellationToken cancellationToken) => throw new NotImplementedException();
        Task<UntagQueueResponse> IAmazonSQS.UntagQueueAsync(UntagQueueRequest request, CancellationToken cancellationToken) => throw new NotImplementedException();
    }
}
