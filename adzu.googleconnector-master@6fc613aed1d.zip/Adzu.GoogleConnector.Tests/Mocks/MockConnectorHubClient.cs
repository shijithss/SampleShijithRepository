﻿using adzu.connectorhub.contracts.Model;
using adzu.connectorhub.sdk;
using adzu.connectorhub.sdk.Clients;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Tests.Mocks
{
    class MockConnectorHubClient : IConnectorHubClient
    {
        private List<NotificationResponse> NotificatioResponse = new List<NotificationResponse>();


        public IConnectorClient Connectors => throw new System.NotImplementedException();

        public ITenantAccountClient TenantAccounts => throw new System.NotImplementedException();

        public IRequestClient Requests => throw new System.NotImplementedException();

        public INotificationsClient Notifications => new MockNotificationsClient(this.NotificatioResponse);
    }

    public class MockNotificationsClient : INotificationsClient
    {
        private List<NotificationResponse> _response { get; set; }
        public MockNotificationsClient(List<NotificationResponse> response)
        {
            _response = response;
        }
        Task<Page<NotificationResponse>> INotificationsClient.ListAll()
        {
            return Task.FromResult<Page<NotificationResponse>>(new Page<NotificationResponse>
            {
                Items = _response
            });
        }

        Task INotificationsClient.Notify(string requestToken, NotificationRequest request)
        {
            _response.Add(new NotificationResponse
            {
                Notification = request.Notifications[0]
            });           

            return Task.FromResult<string>("result");
        }
    }
}
