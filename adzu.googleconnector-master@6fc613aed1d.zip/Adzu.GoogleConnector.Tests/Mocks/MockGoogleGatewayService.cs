﻿using Adzu.GoogleConnector.DTO;
using Adzu.GoogleConnector.Services;
using Google.Ads.GoogleAds.Lib;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Tests.Mocks
{
    public class MockGoogleGatewayService : IGoogleGatewayService
    {
        public async Task<TrafficPackageCompletedNotificationDTO> SendAdToGoogle(PackageManifestDTO packageManifest, string prefixDownloadPackageUrl, Func<string, Task<byte[]>> downloadCallback)
        {
            return new TrafficPackageCompletedNotificationDTO();
        }
        public List<CustomerAccountDTO> GetNodeAccessibleCustomers(string loginCustomerId, string customerId)
        {
            throw new NotImplementedException();
        }

        public List<CustomerAccountDTO> GetRootAccessibleCustomers()
        {
            throw new NotImplementedException();
        }
        public IGoogleGatewayService SetParameters(string accessToken)
        {
            return this;
        }

        public void SetGoogleClient(GoogleAdsClient client)
        {
            throw new NotImplementedException();
        }
    }
}
