using adzu.connectorhub.sdk;
using Adzu.ConnectionManager.SDK;
using Adzu.GoogleConnector.DTO;
using Adzu.GoogleConnector.Functions;
using Adzu.GoogleConnector.Helpers;
using Adzu.GoogleConnector.Services;
using Adzu.GoogleConnector.Tests.Mocks;
using Adzu.GoogleConnector.Validators;
using Adzu.Sdk.IoC;
using Amazon.SQS;
using FluentValidation;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Tests
{
    public class TrafficPackageServiceTests
    {
        private IServiceProvider _serviceProvider;
        private ITrafficPackageService _trafficService;
        private IStatusService _statusService;
        private IFileAccessService _fileAccessService;       
        private const string FolderPackageName = "Test";
        [SetUp]
        public void Setup()
        {
            var serviceCollection = new ServiceCollection();

            var configBuilder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: true)
                .AddEnvironmentVariables()
                .AddCommandLine(Environment.GetCommandLineArgs());

            var config = configBuilder.Build();
            serviceCollection.Configure<ClientConfigOptions>(config);
            serviceCollection.AddLogging(x =>
            x.AddLambdaLogger(new LambdaLoggerOptions
            {
                IncludeCategory = true,
                IncludeLogLevel = true,
                IncludeNewline = true,
                IncludeEventId = true,
                IncludeException = true,
                IncludeScopes = true
            }))
                .Configure<LoggerFilterOptions>(options => options.MinLevel = LogLevel.Information);

            serviceCollection.AddTransient<IValidator<RequestTrafficPackageDTO>, PackageRequestDTOValidator>();
            serviceCollection.AddTransient<IValidator<TrafficPackageStatusDTO>, StatusDTOValidator>();
            serviceCollection.AddTransient<IValidator<DownloadPackage>, DownloadPackageValidatorMock>();
            serviceCollection.AddScoped<ITrafficPackageService, TrafficPackageService>();
            serviceCollection.AddScoped<IFileAccessService, MockFileAccessService>();
            serviceCollection.AddScoped<ISqsService, MockSqsService>();
            serviceCollection.AddScoped<IAmazonSQS, MockAmazonSQSClient>();
            serviceCollection.AddScoped<IStatusService, StatusService>();
            serviceCollection.AddScoped<IGoogleGatewayService, MockGoogleGatewayService>();
            serviceCollection.AddTransient<IGoogleServiceProvider, GoogleServiceProvider>();

            serviceCollection.AddScoped<IHttpRequestService, MockHttpRequestService>();
            serviceCollection.AddScoped<IConnectorHubClient, MockConnectorHubClient>();
            serviceCollection.AddScoped<IConnectionManagerClient, MockConnectionManagerClient>();

            _serviceProvider = serviceCollection.BuildServiceProvider();

            _trafficService = _serviceProvider.GetService<ITrafficPackageService>();
            ((TrafficPackageService)_trafficService).IsTestingMode = true;

            _statusService = _serviceProvider.GetService<IStatusService>();
            ((StatusService)_statusService).IsTestingMode = true;

            _fileAccessService = _serviceProvider.GetService<IFileAccessService>();
        }

        [Test]
        public void RequestTrafficValidateRequestDTOFailureTest()
        {
            //given
            var tracingId = Guid.NewGuid().ToString();
            var dto = new RequestTrafficPackageDTO { };

            //when
            var ex = Assert.CatchAsync(async () => await _trafficService.RequestTraffic(tracingId, dto));

            //then
            Assert.IsTrue(ex.Message.StartsWith("Validation failed"));
        }
        [Test]
        public void RequestTrafficValidateRequestDTOPassedTest()
        {
            //given
            var tracingId = Guid.NewGuid().ToString();
            var dto = new RequestTrafficPackageDTO
            {
                ActionId = "Some action",
                Input = new Input
                {
                    PackageUrl = "https://test.co.uk"
                }
            };

            //when
            Assert.DoesNotThrowAsync(async () => await _trafficService.RequestTraffic(tracingId, dto));

            //then
        }
        [Test]
        [TestCase("ExistInnerManifest.zip")]
        [TestCase("NotExistInnerManifest.zip")]
        public async Task GetPackageZipGetAssetTest(string assetFileName)
        {
            //given
            var assetFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Mocks", "TestResources", assetFileName);
            MethodInfo methodInfo = typeof(TrafficPackageService).GetMethod("GetPackageZip", BindingFlags.NonPublic | BindingFlags.Instance);
            object[] parameters = { assetFileName };
            await _fileAccessService.CreateFile(System.IO.File.Open(assetFilePath,FileMode.Open), assetFileName);
            //when
            var resultTask = await (Task<byte[]>)methodInfo.Invoke(_trafficService, parameters);

            //then
            Assert.DoesNotThrow(() =>
            {
                var zipByte = resultTask;
                using (var stream = new MemoryStream(zipByte))
                {
                    var archive = new ZipArchive(stream, ZipArchiveMode.Read);
                    var inneManifestFile = archive.GetEntry("index.html");
                }
            });
        }

        [Test]
        public async Task InternalStatusGetTheLastStatusSingleLambdaSuccessTest()
        {
            //given
            MockStatuses(new[] { PackageStatusEnum.Downloading, PackageStatusEnum.Downloaded});
            TrafficPackageConstants.ActionName = typeof(SqsHandlerFunction).Name;
            //when
            var lastStatus = await _statusService.GetStatus(FolderPackageName);

            //then
            Assert.AreEqual(PackageStatusEnum.Downloaded, lastStatus.InternalStatus);
        }
        [Test]
        public async Task InternalStatusGetTheLastStatusMultiLambdaSuccessTest()
        {
            //given
            MockStatuses(new[] { PackageStatusEnum.Created,
                PackageStatusEnum.Downloading, PackageStatusEnum.Downloaded,
                PackageStatusEnum.Extracting,PackageStatusEnum.Extracted,
                PackageStatusEnum.Processing,PackageStatusEnum.Processed
            });
            TrafficPackageConstants.ActionName = typeof(SqsHandlerFunction).Name;
            //when
            var lastStatus = await _statusService.GetStatus(FolderPackageName);

            //then
            Assert.AreEqual(PackageStatusEnum.Processed, lastStatus.InternalStatus);
        }

        [Test]
        public async Task InternalStatusSetByPackageProcessFunction()
        {
            //given
            TrafficPackageConstants.ActionName = typeof(SqsHandlerFunction).Name;
          
            string ManifestFileLink = "ManifestFileLink";
            string PackageFileLink = "PackageFileLink";

            var bodyDto = new ProcessPackage 
            {
                FolderPackageName = FolderPackageName,
                ManifestFileLink = ManifestFileLink
            };

            var dto = MockEventMessageDto(bodyDto);

            var manifestDto = new PackageManifestDTO
            {
                StartDate = DateTime.Now.AddDays(4).ToString("o"),
                EndDate = DateTime.Now.AddDays(5).ToString("o"),
                MediaEndpointData = new MediaEndpointData(),
                Assets = new List<Asset>()
            };
                        
            await _fileAccessService.CreateFile(JsonConvert.SerializeObject(manifestDto), ManifestFileLink);
            await _fileAccessService.CreateFile("data", PackageFileLink);
            await _trafficService.ProcessPackage(dto);

            //when
            var lastStatus = await _statusService.GetStatus(FolderPackageName);

            //then
            Assert.AreEqual(PackageStatusEnum.Processed, lastStatus.InternalStatus);
        }

        [Test]
        public async Task InternalStatusSetByPackageDownloadFunction()
        {
            //given
            TrafficPackageConstants.ActionName = typeof(SqsHandlerFunction).Name;

            var bodyDto = new DownloadPackage
            {
                FolderPackageName = FolderPackageName,
                PackageUrl = Path.Combine(Directory.GetCurrentDirectory(), "Mocks", "TestResources", "DummyTrafficPackage.zip")
            };

            var dto = MockEventMessageDto(bodyDto);            

            await _trafficService.DownloadPackage(dto);

            //when
            var lastStatus = await _statusService.GetStatus(FolderPackageName);

            //then
            Assert.AreEqual(PackageStatusEnum.Extracted, lastStatus.InternalStatus);
        }

        [Test]
        public async Task ExternalSuccessStatusSentByPackageNotificationFunction()
        {
            //given
            TrafficPackageConstants.ActionName = typeof(SqsHandlerFunction).Name;
            var bodyDto = new TrafficPackageCompletedNotificationDTO
            {
                FolderPackageName = FolderPackageName               
               
            };

            MockStatuses(new[] { PackageStatusEnum.Processed });

            var dto = MockEventMessageDto(bodyDto);
            await _trafficService.NotificationTraffic(dto);

            //when
            var statusDto = GetConnectorHubNotificationResponse();

            var actualNotificationType = statusDto["notificationType"].ToString();
            var actualStatus = statusDto["status"].ToString();

            //then
            Assert.AreEqual("TrafficPackageCompleted", actualNotificationType);
            Assert.AreEqual("Success", actualStatus);
        }

        [Test]
        public async Task ExternalFailStatusSentByPackageNotificationFunction()
        {
            //given
            TrafficPackageConstants.ActionName = typeof(SqsHandlerFunction).Name;
            var bodyDto = new TrafficPackageCompletedNotificationDTO
            {
                FolderPackageName = FolderPackageName                              
            };

            MockStatuses(new[] { PackageStatusEnum.ProcessFailed });
            var dto = MockEventMessageDto(bodyDto);
            await _trafficService.NotificationTraffic(dto);

            //when
            var statusDto = GetConnectorHubNotificationResponse();

            var actualNotificationType = statusDto["notificationType"].ToString();
            var actualStatus = statusDto["status"].ToString();

            //then
            Assert.AreEqual("TrafficPackageCompleted", actualNotificationType);
            Assert.AreEqual("Fail", actualStatus);
        }

        [Test]
        public async Task ReadTrafficPackageFileByPackageDownloadFunction()
        {
            //given
            TrafficPackageConstants.ActionName = typeof(SqsHandlerFunction).Name;

            string expectedSavedZipFileLink = "Test/TrafficPackage/BTQA33100C0045306-LinkedInSingleImageAdSocialMCLinkedInSingleImageAd320x578px18May21144PM.zip";
            string expectedSavedManifestFileLink = "Test/TrafficPackage/manifest.json";

            var bodyDto = new DownloadPackage
            {
                FolderPackageName = FolderPackageName,
                PackageUrl = Path.Combine(Directory.GetCurrentDirectory(), "Mocks", "TestResources", "SampleTrafficPackage.zip")
            };

            var dto = MockEventMessageDto(bodyDto);

            await _trafficService.DownloadPackage(dto);

            //when
            var _sqsService = _serviceProvider.GetService<ISqsService>() as ISqsRead; 

            var sqsMessage = _sqsService.Read() as ProcessPackage;

            var actualManifestFileLink = sqsMessage.ManifestFileLink;

            var actualSavedZipFile = await _fileAccessService.GetObject(expectedSavedZipFileLink);
            var actualSavedManifestFile = await _fileAccessService.GetObject(expectedSavedManifestFileLink);

            //then
            Assert.AreEqual(expectedSavedManifestFileLink, actualManifestFileLink);
            Assert.AreEqual(304201, actualSavedZipFile.Length);
            Assert.AreEqual(1238, actualSavedManifestFile.Length);
        }

        [Test]
        public async Task ReadEmptyTrafficPackageFileByPackageDownloadFunction()
        {
            //given
            TrafficPackageConstants.ActionName = typeof(SqsHandlerFunction).Name;

            string expectedSavedManifestFileLink = null;

            var bodyDto = new DownloadPackage
            {
                FolderPackageName = FolderPackageName,
                PackageUrl = Path.Combine(Directory.GetCurrentDirectory(), "Mocks", "TestResources", "DummyTrafficPackage.zip")
            };

            var dto = MockEventMessageDto(bodyDto);

            await _trafficService.DownloadPackage(dto);

            var _sqsService = _serviceProvider.GetService<ISqsService>() as ISqsRead;

            //when
            var sqsMessage = _sqsService.Read() as ProcessPackage;

            var actualManifestFileLink = sqsMessage.ManifestFileLink;

            //then
            Assert.AreEqual(expectedSavedManifestFileLink, actualManifestFileLink);
        }

        private void MockStatuses(PackageStatusEnum[] statuses)
        {
            statuses.ToList().ForEach(async status =>
            {
                await _statusService.SetStatus(new TrafficPackageStatusDTO
                {
                    InternalStatus = status
                }, FolderPackageName);
            });
        }

        private EventMessage MockEventMessageDto(EventDTO bodyDto)
        {
            return new EventMessage { Body = JsonConvert.SerializeObject(bodyDto) };
        }

        private  JToken GetConnectorHubNotificationResponse()
        {
            var _connectorHubClient = _serviceProvider.GetService<IConnectorHubClient>();
            var connectorHubresponse =  _connectorHubClient.Notifications.ListAll().Result;
            var notificationResponse = connectorHubresponse.Items.FirstOrDefault();
            var statusDto = notificationResponse.Notification;

            return statusDto;
        }
    }
}