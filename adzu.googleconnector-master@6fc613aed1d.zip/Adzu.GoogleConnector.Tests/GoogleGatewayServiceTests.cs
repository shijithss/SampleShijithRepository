﻿using adzu.connectorhub.sdk;
using Adzu.ConnectionManager.SDK;
using Adzu.GoogleConnector.DTO;
using Adzu.GoogleConnector.Helpers;
using Adzu.GoogleConnector.Services;
using Adzu.GoogleConnector.Services.GoogleInheritors;
using Adzu.GoogleConnector.Tests.Mocks;
using Adzu.Sdk.IoC;
using Google.Ads.GoogleAds.V9.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using static Google.Ads.GoogleAds.V9.Enums.CampaignStatusEnum.Types;

namespace Adzu.GoogleConnector.Tests
{
    class GoogleGatewayServiceTests
    {
        private IServiceProvider _serviceProvider;
        private IGoogleGatewayService _googleGatewayService;
        public static IConfiguration Configuration { get; set; }
        [SetUp]
        public void Setup()
        {
            var serviceCollection = new ServiceCollection();

            var configBuilder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: true)
                .AddEnvironmentVariables()
                .AddCommandLine(Environment.GetCommandLineArgs());

            Configuration = configBuilder.Build();

            var config = configBuilder.Build();
            serviceCollection.Configure<ClientConfigOptions>(config);
            serviceCollection.AddLogging(x =>
               x.AddLambdaLogger(new LambdaLoggerOptions
               {
                   IncludeCategory = true,
                   IncludeLogLevel = true,
                   IncludeNewline = true,
                   IncludeEventId = true,
                   IncludeException = true,
                   IncludeScopes = true
               }))
               .Configure<LoggerFilterOptions>(options => options.MinLevel = LogLevel.Information);

            serviceCollection.AddScoped<ITrafficPackageService, TrafficPackageService>();
            serviceCollection.AddScoped<IFileAccessService, MockFileAccessService>();
            serviceCollection.AddScoped<ISqsService, MockSqsService>();
            serviceCollection.AddScoped<IStatusService, StatusService>();
            serviceCollection.AddTransient<IGoogleAdsClient, CustomGoogleAdsClient>();
            serviceCollection.Configure<GoogleConfigDTO>(Configuration.GetSection("GoogleConfig"));
            serviceCollection.AddTransient<IGoogleGatewayService, GoogleGatewayService>();

            serviceCollection.AddScoped<IHttpRequestService, MockHttpRequestService>();
            serviceCollection.AddScoped<IConnectorHubClient, MockConnectorHubClient>();
            serviceCollection.AddScoped<IConnectionManagerClient, MockConnectionManagerClient>();

            _serviceProvider = serviceCollection.BuildServiceProvider();


            _googleGatewayService = _serviceProvider.GetService<IGoogleGatewayService>();


        }

        [Test]
        public void TestGetRootAccessibleCustomers()
        {
            var mockAdsClient = new Mock<IGoogleAdsClient>();

            var listCustomers = new List<CustomerAccountDTO>()
            {
                new CustomerAccountDTO
                {
                    CurrencyCode="KYD",
                    CustomerId="123",
                    DescriptiveName="test customer 1",
                    HasManager=false,
                    IsManager=true,
                    IsTestAccount=false,
                    LoginCustomerId="123",
                    TimeZone="PT"
                },
                new CustomerAccountDTO()
                {
                    CurrencyCode="AUD",
                    CustomerId="333",
                    DescriptiveName="test customer 2",
                    HasManager=false,
                    IsManager=true,
                    IsTestAccount=false,
                    LoginCustomerId="333",
                    TimeZone="AU"
                }
            };

            mockAdsClient.Setup(x => x.GetListAccessibleCustomers()).Returns(listCustomers);

            ((GoogleGatewayService)_googleGatewayService).SetClient(mockAdsClient.Object);
            var customersResponce = _googleGatewayService.GetRootAccessibleCustomers();
            Assert.IsFalse(customersResponce.Count() == 0);
            Assert.IsTrue(customersResponce == listCustomers);
            Assert.IsTrue(customersResponce.Any(x => x.CustomerId == "123"));
        }

        [Test]
        public void TestGetNodeAccessibleCustomers()
        {
            var mockAdsClient = new Mock<IGoogleAdsClient>();
            var listCustomers = new List<CustomerAccountDTO>()
            {
                new CustomerAccountDTO
                {
                    CurrencyCode="KYD",
                    CustomerId="999",
                    DescriptiveName="test customer 1 of node 1",
                    HasManager=true,
                    IsManager=false,
                    IsTestAccount=false,
                    LoginCustomerId="123",
                    TimeZone="PT"
                },
                new CustomerAccountDTO()
                {
                    CurrencyCode="AUD",
                    CustomerId="555",
                    DescriptiveName="test customer 2 of node 1",
                    HasManager=true,
                    IsManager=false,
                    IsTestAccount=false,
                    LoginCustomerId="123",
                    TimeZone="AU"
                }
            };
            mockAdsClient.Setup(x => x.GetNodeAccessibleCustomers("123", "111")).Returns(listCustomers);
            ((GoogleGatewayService)_googleGatewayService).SetClient(mockAdsClient.Object);
            string loginCustomerId = "123";
            var customersResponce = _googleGatewayService.GetNodeAccessibleCustomers(loginCustomerId, "111");
            Assert.IsFalse(customersResponce.Count() == 0);
            Assert.IsTrue(customersResponce.All(x => x.LoginCustomerId == loginCustomerId));
            Assert.IsTrue(customersResponce.Count() == 2);
            customersResponce = _googleGatewayService.GetNodeAccessibleCustomers("666", "111");
            Assert.IsNull(customersResponce);
        }

        [Test]
        public async Task TestCorrectSendAdToGoogle()
        {
            var mockAdsClient = new Mock<IGoogleAdsClient>();
            PackageManifestDTO packageManifest = new PackageManifestDTO()
            {
                Code = "Guiness unit test",
                Campaign = new Campaign
                {
                    Id = "campaignId",
                    Name = "CampaighName"
                },
                StartDate = DateTime.Now.AddDays(4).ToString("o"),
                EndDate = DateTime.Now.AddDays(5).ToString("o"),
                ProductionCost = new Cost
                {
                    Code = "GBR",
                    Value = 50
                },
                PlannedMediaCost = new Cost
                {
                    Code = "GBR",
                    Value = 50
                },
                MediaEndpointData = new MediaEndpointData
                {
                    CustomerId = "3941125176",
                    LoginCustomerId = "8963272431",
                    ClickThroughUrl = "http://google.com"
                },
                Assets = new List<Asset>
                {
                    new Asset
                    {
                        Id = $"CustomisationId0",
                        Package = $"BTQA33100C0045306-EmptyGoogleAds.zip"
                    }
                },
                BusinessUnits = new List<BusinessUnit>
                {
                    new BusinessUnit
                    {
                        Geographic = new Geographic
                        {
                            PostCodes = new List<PostCode>
                            {
                                new PostCode
                                {
                                    CountryCode= "GB",
                                    CityName="London",
                                    PostalCode = "B9 5QB",
                                    Radius="10",
                                    RadiusUnits = "Miles"
                                },
                                new PostCode
                                {
                                    CountryCode= "GB",
                                    CityName="London",
                                    PostalCode = "B15 2PH",
                                    Radius="5",
                                    RadiusUnits = "Miles"
                                }
                            }
                        }
                    }
                }
            };
            var budgetResourceName = "budgetResourceName";
            var campaignResourceName = "campaignResourceName/123456789";
            long campaignId = 123456789;
            var adGroupResourceName = "adGroupResourceName/987654321";
            long adGroupId = 987654321;
            var uploadedAssetResourceNames =new List<string> { "asset/5588773311" };
            var displayUploadAdResourceName = new List<string> { "ad/7733114499" };
            var geoTargetingResponseResourceNames = new List<string> { "resource1", "resource2" };
            mockAdsClient.Setup(x => x.CreateBudget(packageManifest)).Returns(budgetResourceName);
            mockAdsClient.Setup(x => x.CreateCampaign(packageManifest,budgetResourceName)).Returns(campaignResourceName);
            mockAdsClient.Setup(x => x.AddAdGroup(campaignId, packageManifest)).Returns(adGroupResourceName);
            mockAdsClient.Setup(x => x.CreateMediaBundleAsset(It.IsAny<List<Google.Ads.GoogleAds.V9.Resources.Asset>>(), packageManifest.MediaEndpointData.CustomerId
                )).Returns(uploadedAssetResourceNames);
            mockAdsClient.Setup(x => x.CreateDisplayUploadAdGroupAd(adGroupId, uploadedAssetResourceNames, packageManifest)).Returns(displayUploadAdResourceName);
            mockAdsClient.Setup(x => x.SetGeoTargetingForCampaign(It.IsAny<string>(), It.IsAny<List<CampaignCriterionOperation>>())).Returns(geoTargetingResponseResourceNames);
            ((GoogleGatewayService)_googleGatewayService).SetClient(mockAdsClient.Object);

            var response = await _googleGatewayService.SendAdToGoogle(packageManifest, string.Empty, null);

            Assert.AreEqual(response.ExternalCampaignId, campaignId.ToString());
            Assert.AreEqual(response.ExternalId, $"{campaignId}//{packageManifest.MediaEndpointData.CustomerId}//{packageManifest.MediaEndpointData.LoginCustomerId}");
            Assert.AreEqual(response.Assets.Count, packageManifest.Assets.Count);
            Assert.IsTrue(response.Assets.All(x => x.Status == PackageStatusEnum.Success.ToString()));
            Assert.AreEqual(response.Assets[0].ExternalId, uploadedAssetResourceNames[0]);
            var uploadedAssetResponse = response.Assets.FirstOrDefault(x => x.AssetId == packageManifest.Assets[0].Id);
            Assert.IsNotNull(uploadedAssetResponse);
        }


        [Test]
        public async Task TestSendAdToGoogle_Fail_CustomerId_Not_Set()
        {
            var mockAdsClient = new Mock<IGoogleAdsClient>();
            PackageManifestDTO packageManifest = new PackageManifestDTO()
            {
                Code = "Guiness unit test",
                Campaign = new Campaign
                {
                    Id = "campaignId",
                    Name = "CampaighName"
                },
                StartDate = DateTime.Now.AddDays(4).ToString("o"),
                EndDate = DateTime.Now.AddDays(5).ToString("o"),
                ProductionCost = new Cost
                {
                    Code = "GBR",
                    Value = 50
                },
                PlannedMediaCost = new Cost
                {
                    Code = "GBR",
                    Value = 50
                },
                MediaEndpointData = new MediaEndpointData
                {
                    LoginCustomerId = "8963272431",
                    ClickThroughUrl = "http://google.com"
                },
                Assets = new List<Asset>
                {
                    new Asset
                    {
                        Id = $"CustomisationId0",
                        Package = $"BTQA33100C0045306-EmptyGoogleAds.zip"
                    }
                }
            };
            ((GoogleGatewayService)_googleGatewayService).SetClient(mockAdsClient.Object);

            var ex = Assert.ThrowsAsync<NullReferenceException>(() => _googleGatewayService.SendAdToGoogle(packageManifest, string.Empty, null));
        }

        [Test]
        public async Task TestSendAdToGoogle_Fail_Campaign_Not_Created()
        {
            var mockAdsClient = new Mock<IGoogleAdsClient>();
            PackageManifestDTO packageManifest = new PackageManifestDTO()
            {
                Code = "Guiness unit test",
                Campaign = new Campaign
                {
                    Id = "campaignId",
                    Name = "CampaighName"
                },
                StartDate = DateTime.Now.AddDays(4).ToString("o"),
                EndDate = DateTime.Now.AddDays(5).ToString("o"),
                ProductionCost = new Cost
                {
                    Code = "GBR",
                    Value = 50
                },
                PlannedMediaCost = new Cost
                {
                    Code = "GBR",
                    Value = 50
                },
                MediaEndpointData = new MediaEndpointData
                {
                    CustomerId = "3941125176",
                    LoginCustomerId = "8963272431",
                    ClickThroughUrl = "http://google.com"
                },
                Assets = new List<Asset>
                {
                    new Asset
                    {
                        Id = $"CustomisationId0",
                        Package = $"BTQA33100C0045306-EmptyGoogleAds.zip"
                    }
                }
            };
            var budgetResourceName = "budgetResourceName";
            mockAdsClient.Setup(x => x.CreateBudget(packageManifest)).Returns(budgetResourceName);
            mockAdsClient.Setup(x => x.CreateCampaign(packageManifest, budgetResourceName)).Returns("0");
            ((GoogleGatewayService)_googleGatewayService).SetClient(mockAdsClient.Object);

            var ex = Assert.ThrowsAsync<Exception>(() => _googleGatewayService.SendAdToGoogle(packageManifest, string.Empty, null));

            //Check is exception contains GUID for OpenTelemetry (OTel) in Lambda
            StringAssert.IsMatch(@"(([0-9A-Fa-f]{8}[-][0-9A-Fa-f]{4}[-][0-9A-Fa-f]{4}[-][0-9A-Fa-f]{4}[-][0-9A-Fa-f]{12})*)", ex.Message);
        }
    }
}
