﻿using adzu.connectorhub.sdk;
using Adzu.ConnectionManager.SDK;
using Adzu.GoogleConnector.DTO;
using Adzu.GoogleConnector.Functions;
using Adzu.GoogleConnector.Helpers;
using Adzu.GoogleConnector.Services;
using Adzu.GoogleConnector.Tests.Mocks;
using Adzu.GoogleConnector.Validators;
using Adzu.Sdk.IoC;
using Amazon.S3;
using FluentValidation;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Adzu.GoogleConnector.Tests
{
    class FileAccessServiceTests
    {

        private IServiceProvider _serviceProvider;
        private IFileAccessService _fileAccessService;
        private const string dataToSave = "some data";
        private const string folderKey = "testKey";
        [SetUp]
        public void Setup()
        {
            var serviceCollection = new ServiceCollection();

            var configBuilder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: true)
                .AddEnvironmentVariables()
                .AddCommandLine(Environment.GetCommandLineArgs());

            var config = configBuilder.Build();
            serviceCollection.Configure<ClientConfigOptions>(config);
           
            serviceCollection.AddScoped<IFileAccessService, FileAccessService>();
            serviceCollection.AddTransient<IAmazonS3, MockAmazonS3>();
            _serviceProvider = serviceCollection.BuildServiceProvider();

            _fileAccessService = _serviceProvider.GetService<IFileAccessService>();
        }

        [Test]
        public async Task CreateFileFromStreamTest()
        {
            //given
            await _fileAccessService.CreateFile(new MemoryStream(Encoding.UTF8.GetBytes(dataToSave)), folderKey);

            string expectedObjectResult = string.Empty;

            //when
            using (var reader = new StreamReader(await _fileAccessService.GetObject(folderKey)))
            {
                expectedObjectResult = await reader.ReadToEndAsync();
            }

            //then
            Assert.AreEqual(expectedObjectResult, dataToSave);
        }

        [Test]
        public async Task CreateFileFromStringTest()
        {
            //given
            await _fileAccessService.CreateFile(dataToSave, folderKey);

            string expectedObjectResult = string.Empty;

            //when
            using (var reader = new StreamReader(await _fileAccessService.GetObject(folderKey)))
            {
                expectedObjectResult = await reader.ReadToEndAsync();
            }

            //then
            Assert.AreEqual(expectedObjectResult, dataToSave);
        }
        
         [Test]
        public async Task RemoveFileTest()
        {
            //given
            await _fileAccessService.CreateFile(dataToSave, folderKey);

            //when
            await _fileAccessService.RemoveObject(folderKey);

            //then
            Assert.CatchAsync(async () => await _fileAccessService.GetObject(folderKey));           

        }

        [Test]
        public async Task ReadFileListTest()
        {
            //given
            string[] fileNameList = new[]
            {
                 $"{folderKey}/file1",
                 $"{folderKey}/file2",
                 $"{folderKey}/file3",
                 "folder/file4"
            };

            foreach (var fileName in fileNameList)
            {
                await _fileAccessService.CreateFile(dataToSave, fileName);
            }

            //when
            var fileListResult = await _fileAccessService.GetFileNameList(folderKey);

            //then
            Assert.AreEqual(3, fileListResult.Count);
            Assert.AreEqual("testKey/file1", fileListResult[0]);
            Assert.AreEqual("testKey/file2", fileListResult[1]);
            Assert.AreEqual("testKey/file3", fileListResult[2]);

        }

    }
}
