﻿using Adzu.GoogleConnector.DTO;
using Adzu.GoogleConnector.Services;
using Adzu.GoogleConnector.Tests.Mocks;
using Amazon.SQS;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adzu.GoogleConnector.Tests
{
    public class SqsServiceTest
    {
        private IServiceProvider _serviceProvider;
        private string MessageQueueUrl = "Test";
        [SetUp]
        public void Setup()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ISqsService, SqsService>();
            serviceCollection.AddScoped<IAmazonSQS, MockAmazonSQSClient>();

            _serviceProvider = serviceCollection.BuildServiceProvider();
        }
        [Test]
        public async Task SendMessageTestBody()
        {
            //given
            var sqsService = _serviceProvider.GetService<ISqsService>();
            var amazonSqs = _serviceProvider.GetService<IAmazonSQS>();
            var dto = new EventDTO { };

            //when
            await sqsService.SendMessage(dto, MessageQueueUrl);

            //then
            var events = await amazonSqs.ReceiveMessageAsync(MessageQueueUrl);
            var message = events.Messages.First().Body;

            Assert.AreEqual(message, JsonConvert.SerializeObject(dto));
        }
        [Test]
        public async Task SendMessageCheckTestAttributes()
        {
            //given
            var sqsService = _serviceProvider.GetService<ISqsService>();
            var amazonSqs = _serviceProvider.GetService<IAmazonSQS>();
            var dto = new EventDTO { };

            //when
            await sqsService.SendMessage(dto, MessageQueueUrl);

            //then
            var events = await amazonSqs.ReceiveMessageAsync(MessageQueueUrl);
            var attributes = events.Messages.First().MessageAttributes;

            Assert.AreEqual(2, attributes.Count);
            Assert.IsTrue(attributes.ContainsKey("MessageType"));
            Assert.IsTrue(attributes.ContainsKey("QueueUrl"));
        }
    }
}
